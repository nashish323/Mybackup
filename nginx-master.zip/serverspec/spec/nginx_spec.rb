# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe group('appuser') do
  it { should exist }
end

describe user('appuser') do
  it { should exist }
  it { should belong_to_group 'appuser' }
end

describe package('nginx') do

  it { should be_installed }

  it {
      cmd = Serverspec::Type::Command.new('curl http://localhost:80/index.html')
      expect(cmd.return_exit_status?(0)).to be_true
  }

end

describe process("nginx") do
  it { should be_running }
end

describe port(80) do
  it { should be_listening.with('tcp') }
end

