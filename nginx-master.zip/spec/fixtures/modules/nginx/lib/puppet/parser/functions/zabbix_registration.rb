Puppet::Parser::Functions.newfunction(:zabbix_registration) do |args|
  # stub
end
