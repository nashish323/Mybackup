#!/bin/bash

# ##################################################################################################
#
# FILE:         backUpMaster Ver: 1.6 10/08/14
# OTIGINAL:			Ver: 1: released 03/27/14
# AUTHOR:       Albert Aguirre
# DESC:         This script launches the back up process on all cassandra cluster nodes simultaneously
# USAGE:        backUpMaster.sh
#
# To Do list    
#               
# Revisions:    alberta 04/17/14 - corrected start of log minor bug
#               alberta 08/01/14 - support for new cong file / support local backup storage
#               alberta 10/08/14 - corrected log removal glitch
#               alberta 10/08/14 - added new conf file for dynamic hosts file creation
#               alberta 11/14/14 - corrected filehosts and dynamicHosts logic
#
# Limitations:  alberta:03/21/14 - can only be run on servers with ONE cassandra instance running. 
#																	 Later versions will handle multiple instances
#               
# ##################################################################################################

## START LOCAL LOGGING
# define local daily log
localLog="/tmp/backUpMaster_daily.log"
echo "==========================================================" >> $localLog
echo "`date`	Starting back up master process"  >> $localLog

# init vars
uniquetag=`date +%Y%m%d%H%M%S`

# include global vars file
varsFile="/opt/nosql/includes/backUpVars.sh"
if [ ! -f $varsFile ]
  then
  echo "ERROR: Cannot find $varsFile !" >> $localLog
  echo "Aborting!" >> $localLog 
  exit 1
fi
. $varsFile

## INCLUDE REQUIRED FILES
# include utilities file
if [ ! -f $utilsFile ]
  then
  echo "ERROR: Cannot find $utilsFile !" >> $localLog 1
  echo "Aborting!" >> $localLog 
  exit 1
fi
. $utilsFile

# include conf file
verifyFile "f" $confFile $localLog
. $confFile

# source vars security file
if [ -f $secVars ]
  then
  writeToLog "Security file found" $localLog
  . $secVars
  if [ ! -z $cassandraUser ] && [ ! -z $cassandraPass ]
    then
    creds="-u $cassandraUser -p $cassandraPass"
  else
    creds=""
  fi
else
  writeToLog "Cannot find security file. Assuming this instance is NOT authenticated" $localLog
  creds=''
fi

## VALIDATE REQUIRED CONFIG FILE PARAMETERS
if [ -z $backUpLocation ] || [ -z $freeSpaceThreshold ] || [ -z $s3BucketOrNFS ] || [ -z $storageType ]
  then
  writeToLog "ERROR: Required values in $confFile are missing" $localLog 1
fi

# shell check
if [ $thisShell != "bash" ]
  then
  writeToLog "ERROR: You must run this script using bash. Aborting" $localLog 1
fi

# check if back up already running
procCnt=`ps -ef | grep $thisScript | grep -v grep | grep -v $$ | wc -l`
if [ $procCnt -gt 0 ]
  then
  writeToLog "ERROR: $thisScript process already running" $localLog 1
fi

# check that nodetool exists
if [ ! -f $nodetool ]
  then
  writeToLog "WARNING: The nodetool script is missing or not in the standard location: $nodetool - attempting to locate it" $localLog
  cnt=`find / -name nodetool | wc -l` || writeToLog "ERROR: There was an error trying to find the nodetool count." $localLog 1
  if [ $cnt -eq 1 ]
    then
    nodetool=`find / -name nodetool` || writeToLog "ERROR: There was an error trying to find the nodetool." $localLog 1
  else
    writeToLog "ERROR: having difficulty finding the nodetool sctipt" $localLog 1
  fi
  writeToLog "nodetool found: $nodetool " $localLog
fi
clusterName=`$nodetool describecluster $creds | grep Name | awk '{print $2}'`

# initialize vars
logLocation="${backUpLocation}/logs"
ssherr="${logLocation}/${uniquetag}_ssherr"
log="${logLocation}/cass${thisScript}.log"

writeToLog "Basic checks passed." $localLog

## CREATE REQUIRED DIRECTORIES
if [ ! -d $rootLocation ]
  then
  writeToLog "Directory $rootLocation not found. Attempting to create it." $log
  mkdir -p $rootLocation
  if [ $? -gt 0 ]
    then
    writeToLog "ERROR: Creation of $rootLocation for back up process logs failed. Aborting back up" $log 1
  else
    writeToLog "$rootLocation created" $log
  fi
fi
if [ ! -d $logLocation ]
  then
  writeToLog "Directory $logLocation not found. Attempting to create it." $localLog
  mkdir -p $logLocation &>> $localLog
  if [ $? -gt 0 ]
    then
    writeToLog "ERROR: Creation of $logLocation for back up process logs failed. Aborting back up" $localLog 1
  else
    writeToLog "$logLocation created" $localLog
  fi
fi

#
# MAIN
#

# start permanent logging
echo "==========================================================" >> $log
writeToLog "Starting master backup process" $log

# read yaml file, get data dir
findYaml=0
if [ ! -z $yamlFile ] 
  then
  if [ ! -f $yamlFile ] 
    then
    writeToLog "WARNING: Optional parameter 'yamlFile' is not valid - attempting to find it" $log
    findYaml=1
  fi
else
    writeToLog "WARNING: Optional parameter 'yamlFile' is not set in config file $confFile - attempting to find it" $log
    findYaml=1
fi
if [ $findYaml -eq 1 ]
  then
  cnt=`find / -name cassandra.yaml | wc -l`
  if [ $cnt -eq 1 ]
    then
    yamlFile=`find / -name cassandra.yaml`
    writeToLog "Optional parameter 'yamlFile' has been found" $log
  else
    writeToLog "ERROR: Cant find cassndra yaml file" $log 1
  fi
else
  writeToLog "Optional parameter 'yamlFile' has been provided in config file $confFile and is valid" $log
fi

## DYNAMICALLY OBTAIN CLUSTER HOST LIST
if [ ! -z "$dynamicHosts" ]
  then
  if [ "$dynamicHosts" = "true" ]
    then
    writeToLog "Retrieving node list" $log
    if [ -f $filehosts ]
      then
      rm $filehosts &>> $log || writeToLog "Unable to remove the hosts file" $log 1
    fi
    for host in `$nodetool status $creds`
      do
      if [ ${#host} -le 6 ]
        then
        continue
      fi
      ping -c1 $host 1>/dev/null 2>/dev/null
      if [ $? -eq 0 ]
        then
        echo $host >> $filehosts
      fi
    done
  else
    writeToLog "Parameter dynamicHosts is not set to true. Assuming a static hosts.txt file has been set. Only the nodes in the hosts file will be backed up" $log
    if [ ! -f $filehosts ]
      then
      writeToLog "Cannot find hosts file $filehosts" $log 
      writeToLog "	- dynamicHosts in the configuration file should be set to 'true;. If not, backups will fail" $log 1
    fi
  fi
else
  writeToLog "Parameter dynamicHosts is not set. This must be set to 'true' or 'false'" $log 1
fi

## ELECT A BACK UP MASTER NODE
firstHost=`cat $filehosts | grep -v "^#" | sort -u | sort | head -1`
if [ `dnsdomainname -i` = "$firstHost" ] || [ `dnsdomainname -f` = "$firstHost" ]
  then
  writeToLog "Looks like this is the backup node - $firstHost" $log
else
  rm $localLog
  rm $log
  exit 1
fi

## EXECUTE BACKUP SLAVE SCRIPT ON ALL NODES SIMULTANEOUSLY
parallel-ssh --hosts=$filehosts --timeout -1 --par 100 --errdir=$ssherr "/bin/bash $backUpSlave $uniquetag $thisHost" &>>$log || writeToLog "ERROR: snapshot backup failed" $log

# concat ssh errors into base log
for row in `ls $ssherr`
  do
  writeToLog "$row ssh errors:" $log
  cat $ssherr/$row >> $log
done

# remove ssh errors
rm -rf $ssherr || writeToLog "WARNING: Could not delete snapshot error directory" $log

# truncate local log
writeToLog "Truncating local log $localLog" $log 
tail -2000 $localLog > /tmp/localLog.tmp
mv /tmp/localLog.tmp $localLog

# rotate permanent logs
if [ ! -z $keepCount ]
  then
  writeToLog "Rotating permanent logs" $log 
  rotate $keepCount "$logLocation" "$thisScript" "log"
fi

# LOG DATE AND TIME OF THE END OF THE BACK UP
writeToLog "Done!" $log 
