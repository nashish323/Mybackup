# The Cassandra Backup Solution Proof of Concept
## Also known as "Eletto"

Please read Eletto documentation here:
https://docs.google.com/a/pearson.com/document/d/15Y7mp6jE8rjYzHb2HiOFW3LMmW5ZyTyv8T20fBChpU4
