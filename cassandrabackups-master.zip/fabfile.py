
# This is a basic, brute force fabfile.  Edit the variables and execute:
# Example: fab deploy


from os import system
from os.path import basename
from fabric.api import env
from fabric.decorators import task
from fabric.operations import put, run, sudo

# Edit environment and S3 settings here...
env.hosts = ["<cadb 01 IP>", "<cadb 02 IP>", "<cadb 03 IP>", "<cadb 04 IP>", "<cadb 05 IP>"]
env.user = "ubuntu"
env.key_filename = "/path/to/team.pem"  # path to SSH key file
key_basename = basename(env.key_filename)

s3_bucket_url = "s3://<team backup bucket>"
s3_access_key = "<S3 bucket Access Key>"
s3_secret_key = "<S3 bucket Secret Key>"

# This is for encrypting the backups before sending to S3.  It needs to be the same across the cluster and stored
# elsewhere. Lose this... lose the backups.
backup_encryption_key = "<random whatever>"

@task
def deploy():
    """This will run the install.sh script and then copy/configure SSH keys, and configure s3cmd"""
    # Package and copy to host
    system("tar czf cassandrabackups.tar.gz *.sh")
    put("cassandrabackups.tar.gz", "/tmp/")
    sudo("rm -fr /tmp/cassandrabackups")
    sudo("mkdir /tmp/cassandrabackups")
    sudo("tar xzf /tmp/cassandrabackups.tar.gz -C /tmp/cassandrabackups")
    # Run install script and configure SSH
    sudo("cd /tmp/cassandrabackups; /bin/bash install.sh " + s3_bucket_url + " " + backup_encryption_key)
    sudo("cp /home/ubuntu/.ssh/authorized_keys /root/.ssh/")
    put(env.key_filename, "/tmp/")
    sudo("cat /tmp/" + key_basename + " > /root/.ssh/id_rsa")
    sudo("chmod 0600 /root/.ssh/id_rsa")
    sudo("sed -i 's/#   StrictHostKeyChecking ask/StrictHostKeyChecking no/g' /etc/ssh/ssh_config")
    # Write S3 config file for root
    sudo("echo '[default]' > /root/.s3cfg")
    sudo("echo 'access_key = " + s3_access_key + "' >> /root/.s3cfg")
    sudo("echo 'secret_key = " + s3_secret_key + "' >> /root/.s3cfg")
    sudo("echo 'use_https = True' >> /root/.s3cfg")
    # Do Cleanup
    system("rm -fr cassandrabackups.tar.gz")
    sudo("rm -fr /tmp/cassandrabackups.tar.gz")
    sudo("rm -fr /tmp/" + key_basename)
    sudo("rm -fr /tmp/cassandrabackups")