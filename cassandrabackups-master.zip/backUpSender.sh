#!/bin/bash

# ##################################################################################################
#
# FILE:         backUpSender.sh Ver: 1.5: 10/27/14
# VERSION:      Ver: 1: 10/10/14
# AUTHOR:       Albert Aguirre
# DESC:         Executes a nodetool snapshot backup and sends to a remote host for compression, excryption and transfer to S3
#								This script allows a backup WITHOUT using filesystem space for compression, encryption and transfer to s3
#								useful for cassandra clusters with limited filesystem space
# USAGE:        backUpSender.sh
#
# To Do list		add logging
#								add more checks
#								NOTE TO FUTURE DEVELOPERS working on this project:
#									This code was written quickly to resolve the space issues that the servers were experiencing. Much of the 
#									code is "hard coded" for speed in development. Recommendations:
#									- dynamically get working dirs (such as data dir), previously I parsed the cassandra yaml to accomplish this
#									- should add yaml and working dir verification/checks
#									- add more user configured vars, such as reciever host ($recieverHost) or anything hard coded under the comment # init vars
#
# Revisions:    10/27/14:v1.5:alberta - Added snapshot dir removal
#
# Limitations:  alberta:03/21/14 - can only be run on servers with ONE cassandra instance running.
#
# ##################################################################################################

# init vars
log="/var/log/backupRemote.log"

# start loggin
echo "====================================================" &>> $log
date &>> $log

# required params
if [ -z "$1" ]
  then
  echo "First param required: [snapshot unique tag]" &>> $log
  exit
fi

# init vars
uniquetag="$1"
senderHost=`hostname`
recieverHost="10.198.4.245"             # verify reachable
recieverUser="root"
recieverDir="/data/backups/novatin"
recieverTarget="${recieverDir}/${uniquetag}_${senderHost}.tar"
varsTarget="${recieverDir}/${uniquetag}_${senderHost}.var"
nodetool="/usr/bin/nodetool"            # add existing file check
dataDir="/data/cassandra/data"          # add existing dir check
key="/opt/nosql/keys/Team34Key.ppk"     # add existing file check
vars="/etc/nosql/vars.sh"

# back up data
##echo "`date`	Starting remote backup process" &>> $log
$nodetool snapshot -t $uniquetag  &>> $log

# tar offline
echo "`date`	Sending backups to remote storage server $recieverHost"  &>> $log
for row in `find $dataDir -name $uniquetag`
  do
  tar cvzf - $row | ssh ${recieverUser}@${recieverHost} "mkdir -p $recieverDir &>/dev/null; cat >> $recieverTarget"  &>> $log
done

# send credentials
cat $vars | ssh ${recieverUser}@${recieverHost} "cat >> $varsTarget" &>>$log

# remove snapshot dir
echo "`date`	Removing snapshot directory $uniquetag" &>> $log
for row in `find $dataDir -name $uniquetag`
  do
  rm -rf $row &>> $log || echo "`date`	WARNING: There was a problem removing the snapshot dir $uniquetag" >> $log
done
