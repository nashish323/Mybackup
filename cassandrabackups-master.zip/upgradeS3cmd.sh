# init vars
uniqueTag=`date +%Y%m%d%H%M%S`

# functions
display () {
  if [ -z $2 ]
    then
    exitStat=0
  else
    exitStat=1
  fi
  echo "$1"
  if [ $exitStat -gt 0 ]
    then
    echo "Aborting"
    exit
  fi
}

# version check
thisVersion=`s3cmd --version | awk '{print $3}'`
if [ "$thisVersion" = "1.5.0-beta1" ]
  then
  display "s3cmd upgrade not needed"
  exit
fi
if [ "$thisVersion" != "1.0.0" ]
  then
  display "Cannot determine version" 1
fi

# get s3cmd location
type s3cmd &>/dev/null || display "Cannot determine s3cmd location" 1
s3cmdFile=`type -p s3cmd`
linkFile=`readlink $s3cmdFile`
linkLocation=`dirname $s3cmdFile`/`dirname $linkFile`

# upgrade s3cmd to multi-part
display "Updating packages"

apt-get -y update || display "Failure updating packages" 1

apt-get -y install python-setuptools || display "Failure updating packages" 1

apt-get -y install python-pkg-resources || display "Failure updating packages" 1

apt-get -y install python-magic || display "Failure installing python-magic" 1

apt-get -y install python-dateutil || display "Failure installing python-dateutil" 1

git clone git://github.com/s3tools/s3cmd.git || display "Failure cloning the upgraded s3cmd package" 1

display "Moving files to working locations"

# is the new s3cmd here?
cd ./s3cmd || display "Cannot find the newly installed s3cmd version" 1

## back up files first
mv ${linkLocation}/s3cmd ${linkLocation}/s3cmd.v1.$uniqueTag || display "Could not back up old s3cmd. Continuing"
mv ${linkLocation}/S3 ${linkLocation}/S3.v1.$uniqueTag || display "Could not back up old S3 dir. Continuing"

# copy files
cp s3cmd ${linkLocation}
cp -r S3 ${linkLocation}

echo "Done!"

s3cmd --version
