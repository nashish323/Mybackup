#!/bin/bash

# ##################################################################################################
#
# FILE:         backUpSlave released 03/27/14
# VERSION:      Ver: 3: 06/03/14
# AUTHOR:       Albert Aguirre
# DESC:         part of the cassandra back up system. Called remotely from another node in the ring by backUpMaster.sh
# USAGE:        backUpSlave.sh [unique_tag] [calling_server]
#
# To Do list
#
# Revisions:	alberta:04/22/14 - added snapshot removal
#             	alberta:04/23/14 - corrected proc count check
#             	alberta:05/21/14 - added multipart option to s3cmd transfer for large backup files
#             	alberta:05/29/14 - added log path creation for new installs. Added larger log truncation number of lines - from 2000 to 20000
#             	alberta:06/03/14 - added check for backup node flag
#             	alberta:06/03/14 - reduced s3cmd multipart to 2000 from 5000
#             	alberta:08/01/14 - added support for non S3 storage
#
# Limitations:  alberta:03/21/14 - can only be run on servers with ONE cassandra instance running.
#                                  Later versions will handle multiple instances
#
# ##################################################################################################

## START LOCAL LOGGING 
# define log
localLog="/tmp/backUpSlave_daily.log"
echo "==========================================================" >> $localLog
echo "`date`	Starting back up master process"  >> $localLog

## CHECK COMMAND LINE PARAMS
if [ -z "$1" ] || [ -z "$2" ]
  then
  echo "`date` Command line parameters missing. Aborting" >> $localLog
  exit 1
fi

# include global vars file
varsFile="/opt/nosql/includes/backUpVars.sh"
if [ ! -f $varsFile ]
  then
  echo "`date` ERROR: Cannot find $varsFile !" >> $localLog
  echo "`date` Aborting!" >> $localLog
  exit 1
fi
. $varsFile

# verify this is a back up node
if [ ! -f $nodeFlag ]
  then
  echo "`date` This node is not marked as a back up node! Aborting" >> $localLog
  exit
else
  echo "`date` Looks like this node is the back up node!" >> $localLog
fi

## INCLUDE REQUIRED FILES
# include utilities file
if [ ! -f $utilsFile ]
  then
  echo "`date` ERROR: Cannot find $utilsFile !" >> $localLog 
  echo "`date` Aborting!" >> $localLog
  exit 1
fi
. $utilsFile

# include conf file
verifyFile "f" $confFile $localLog
. $confFile

# source vars security file
if [ -f $secVars ]
  then
  writeToLog "Security file found" $localLog
  . $secVars
  if [ ! -z $cassandraUser ] && [ ! -z $cassandraPass ]
    then
    creds="-u $cassandraUser -p $cassandraPass"
  else
    creds=""
  fi
else
  writeToLog "Cannot find security file. Assuming this instance is NOT authenticated" $localLog
  creds=''
fi

## VALIDATE REQUIRED CONFIG FILE PARAMETERS
if [ -z $backUpLocation ] || [ -z $freeSpaceThreshold ] || [ -z $s3BucketOrNFS ] || [ -z $storageType ]
  then
  writeToLog "ERROR: Required values in $confFile are missing" $localLog 1
fi

# shell check
if [ $thisShell != "bash" ]
  then
  writeToLog "ERROR: You must run this script using bash. Aborting" $localLog 1
fi

# check if back up already running
procCnt=`ps -ef | grep ${rootLocation}/${thisScript} | egrep -v "grep|python|ssh|SendEnv|bash -c" | wc -l`
if [ $procCnt -gt 2 ]  # alberta - 2 processes are running via parallel-ssh
  then
  writeToLog "ERROR: $thisScript process already running" $localLog 1
fi

# check that nodetool exists
if [ ! -f $nodetool ]
  then
  writeToLog "WARNING: The nodetool script is missing or not in the standard location: $nodetool - attempting to locate it" $localLog
  cnt=`find / -name nodetool | wc -l` || writeToLog "ERROR: There was an error trying to find the nodetool count." $localLog 1
  if [ $cnt -eq 1 ]
    then
    nodetool=`find / -name nodetool` || writeToLog "ERROR: There was an error trying to find the nodetool." $localLog 1
  else
    writeToLog "ERROR: having difficulty finding the nodetool sctipt" $localLog 1
  fi
  writeToLog "nodetool found: $nodetool " $localLog
fi
clusterName=`$nodetool describecluster $creds | grep Name | awk '{print $2}'`

# init local vars
uniquetag=$1
callingServer=$2
logLocation="${backUpLocation}/logs"
tarFile="${clusterName}_${thisHost}_${uniquetag}.tar"
tarBall="${backUpLocation}/${tarFile}"
log="${logLocation}/cass${thisScript}.log"

# create log path
if [ ! -d $logLocation ]
  then
  mkdir -p $logLocation || writeToLog "ERROR: Cannot create the path to the back up log!" $localLog 1
fi

# start permanent logging
writeToLog "Basic checks passed." $localLog
echo "========================================================" >> $log
writeToLog "Starting slave backup process called from $callingServer" $log

# read yaml file, get data dir
findYaml=0
if [ ! -z $yamlFile ]
  then
  if [ ! -f $yamlFile ]
    then
    writeToLog "WARNING: Optional parameter 'yamlFile' is not valid - attempting to find it" $log
    findYaml=1
  fi
else
    writeToLog "WARNING: Optional parameter 'yamlFile' is not set in config file $confFile - attempting to find it" $log
    findYaml=1
fi
if [ $findYaml -eq 1 ]
  then
  cnt=`find / -name cassandra.yaml | wc -l`
  if [ $cnt -eq 1 ]
    then
    yamlFile=`find / -name cassandra.yaml`
    writeToLog "Optional parameter 'yamlFile' has been found" $log
  else
    writeToLog "ERROR: Cant find cassndra yaml file" $log 1
  fi
else
  writeToLog "Optional parameter 'yamlFile' has been provided in config file $confFile and is valid" $log
fi

## calculate approximate space left AFTER backup is completed to avoid filling the loca filesystem
pos=`cat -n $yamlFile | grep -v "^#" | grep data_file_directories | awk '{print $1}'`
pos=`expr $pos + 1`
dataDir=`head -$pos $yamlFile | tail -1 | awk '{print $2}'`
if [ ! -d $dataDir ]
  then
  writeToLog "Cannot determine the data directory" >> $log 1
fi
dataPartition="/`echo $dataDir | tr "/" " " | awk '{print $1}'`"
dataPartitionAvailSpace=`df -BK | grep "/data" | awk '{print $4}' | tr "K" " "`
dataPartitionAvailSpace=`expr $dataPartitionAvailSpace \* 1000`
dataDirUsedSpace=`du -sbx /data/cassandra/ | awk '{print $1}'`
percAvailAfterBackup=`echo "scale=10; (($dataPartitionAvailSpace - $dataDirUsedSpace) / $dataPartitionAvailSpace)*100" | bc | cut -d"." -f1`
if [ $percAvailAfterBackup -lt $freeSpaceThreshold ]
  then
  writeToLog "ERROR: There will be less than the configured minimum space requirement of ${freeSpaceThreshold}% available after back up!" $log 1
fi

# if successful
writeToLog "Space requirements checked and passed: " $log
writeToLog "		Data dir: $dataDir, " $log
writeToLog "		Data dir used space: $dataDirUsedSpace, " $log
writeToLog "		Data partition: $dataPartition, " $log
writeToLog "		Data Partition Avail Space: $dataPartitionAvailSpace, " $log
writeToLog "		Space available AFTER backup: ${percAvailAfterBackup}%" $log

# execute back up
writeToLog "Starting snapshot backup" $log
$nodetool snapshot -t "$uniquetag" $creds &>>$log || writeToLog "ERROR: snapshot backup failed. Aborting the backup process" $log 1
writeToLog "Backup successful!" $log

# compress files
writeToLog "Compressing backup files" $log
for row in `find $dataDir -name $uniquetag`
  do
  tar -rvf $tarBall $row &>>$log || writeToLog "ERROR: There was a problem creating the back up tarball" $log 1
done

# if successful then log i
writeToLog "tar archive creation successful" $log 

# check for encryption password
writeToLog "Encrypting" $log 
if [ -z $encryptPass ]
  then
  writeToLog "ERROR: Encryption passphrase not found!" >> $log 1
  exit  
  #encryptPass="$RANDOM$RANDOM"
  #echo "encryptPass=$encryptPass 		# AUTO GENERATED BY backUpSlave.sh. DO NOT CHANGE OR REMOVE" >> $secVars || writeToLog "ERROR: Could not set encryption password" $log 1
  #writeToLog "Encryption password has been set and stored" >> $log
else
  writeToLog "Encryption password found" $log
fi

## encrypt tarball
openssl aes-256-cbc -salt -in $tarBall -out ${tarBall}.enc -k "$encryptPass" || writeToLog "ERROR: backup encryption backup failed" $log 1
writeToLog "Encryption successful" $log

# store the back up
if [ -z "$storageType" ] 
  then
  writeToLog "ERROR: Could not determine the storage type" $log 1
fi
case "$storageType" in
   "S3") writeToLog "Sending to the configured S3 bucket with the multipart option" $log;
         s3cmd --multipart-chunk-size-mb=2000 put ${tarBall}.enc  $s3BucketOrNFS &>> $log || writeToLog "ERROR: Could not transfer to the configured s3 Bucket!" $log 1;
         writeToLog "S3 transfer complete" $log ;
         # rotate s3 backups on Amazon s3
         if [ -z $keepCount ]
           then
           writeToLog "Config file option 'keepCount' not set. Assuming all backups are to be kept" $log
         else
           writeToLog "Rotating backups on s3. Keeping $keepCount files." $log
           s3rotate $keepCount $s3BucketOrNFS ${clusterName}_${thisHost}_ $log
         fi;;

  "NFS") writeToLog "Moving to the configured NFS mount" $log;
         cp ${tarBall}.enc  $s3BucketOrNFS &>> $log || writeToLog "ERROR: Could not move the backup to the configured NFS mount!" $log 1;
         writeToLog "Move successful" $log ;
         if [ -z $keepCount ]
           then
           writeToLog "Config file option 'keepCount' not set. Assuming all backups are to be kept" $log
         else
           writeToLog "Rotating backups on the configured NFS mount. Keeping $keepCount files." $log
           rotate $keepCount $s3BucketOrNFS ${clusterName}_${thisHost}_ 
         fi;;
       
      *) writeToLog "ERROR: Cannot determine storage type due to an invalid value in your configuration file for variable: storageType. Valid entries are 'S3' or 'NFS'" $log 1
esac

## remove local back up snaps
writeToLog "Removing archives from the local filesystem" $log
rm $tarBall &>> $log
rm ${tarBall}.enc &>> $log
$nodetool clearsnapshot -t "$uniquetag" $creds &>>$log || writeToLog "WARNING: There was an error removing the snapshot files" $log 1
writeToLog "Snapshot and backup files removed from the local filesystem" $log

## truncate log
writeToLog "Truncating logs" $log
tail -20000 $localLog 1>/tmp/tmp.log || writeToLog "WARNING: Could not truncate local logs" $localLog
mv /tmp/tmp.log $localLog ||  writeToLog "WARNING: Could not move truncated local logs" $localLog
tail -20000 $log 1>/tmp/tmp.log || writeToLog "WARNING: Could not truncate local logs" $localLog
mv /tmp/tmp.log $log ||  writeToLog "WARNING: Could not move truncated local logs" $localLog

# Fin
writeToLog "Done!" $localLog
writeToLog "Done!" $log
