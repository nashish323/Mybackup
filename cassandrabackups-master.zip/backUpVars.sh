#
# alberta - 03/31/14
# GLOBAL VARIABLES DEFINITION FILE
# Version 1.5 - 06/03/2014
#

# cassandra code location
rootLocation="/opt/nosql/cassandra"
incLocation="/opt/nosql/includes"

# hists file used for parallel-ssh for simultaneous execution of backups
filehosts="${rootLocation}/hosts.txt"

# cassandra tool
nodetool="/usr/bin/nodetool"

# back up file names
backUpMaster="${rootLocation}/backUpMaster.sh"
backUpSlave="${rootLocation}/backUpSlave.sh"
utilsFile="${incLocation}/backUpUtils.sh"
confFile="/etc/backUpCassandra.conf"
#varsFile="${incLocation}/backUpVars.sh"
varsDir="/etc/nosql"
secVars="${varsDir}/vars.sh"

# dynamic variables
thisHost=`hostname`
thisIp=`dnsdomainname -i`
thisFQDN=`dnsdomainname -f`
thisShell=`ps -p $$ | awk '{print $4}' | tail -1`
thisScript=`basename $0 | cut -d"." -f1`

# node flag
nodeFlag="${rootLocation}/backUp_this_node.enabled"
