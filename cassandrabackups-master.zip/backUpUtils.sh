#
# aaguirre - 01/14/13 - writes to log, creates log if it doesnt exist
# parameters:   REQUIRED: $1(string):any string encapsulated with "quotes"
#               REQUIRED: $2(string): log filename
#               OPTIONAL: $3(int): 1 = error out and exit
writeToLog (){
  # test for req params
  if [ -z "$1" ] || [ -z "$2" ]
    then
    return
  fi

  if [ -z "$3" ]
    then
    err=2
  else
    err=$3
  fi

  # if all well then continue
  echo "`date` $1" >> $2
  if [ $err -eq 1 ]
    then
    echo "`date` Aborting" >> $2
    exit
  fi
}

# aaguirre - 01/14/13 - check param $1 is integer
# parameters:   REQUIRED: $1(int):any number
is_int(){
  # test for req params
  if [ -z "$1" ]
    then
    return
  fi

  test "$1" -eq "$1" 1>/dev/null 2>/dev/null
}

# aaguirre - 01/14/13 - rotates any files = $1 must be integer, if not then nothing will happen
# parameters:   REQUIRED: $1(int):number of files to keep
#               REQUIRED: $2(string):location of files
#               REQUIRED: $3(string):filename prefix
rotate(){
  # test for req params
  if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]
    then
    return
  fi
  if $(is_int $1)
     then
     i=0
     for row in `ls -t $2/$3*$4 2>/dev/null`
       do
       i=`expr $i + 1`
       if [ $i -gt $1 ]
         then
         rm $row
       fi
     done
  fi
}

# chrisro - 10/08/13 - rotates any files on s3 = $1 must be integer, if not then nothing will happen
# parameters:   REQUIRED: $1(int):number of files to keep
#               REQUIRED: $2(string):location of files
#               REQUIRED: $3(string):filename suffix
#               REQUIRED: $4(string):log
s3rotate(){
  # test for req params
  if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ] || [ -z "$4" ]
    then
    return 1
  fi
  delCnt=0
  if $(is_int $1)
     then
     i=0
     for row in `s3cmd ls $2/$3* | sort -r | tr -s ' ' | cut -d ' ' -f4 2>>/dev/null`
       do
       i=`expr $i + 1`
       if [ $i -ge $1 ]
         then
         delCnt=`expr $delCnt + 1`
         s3cmd del $row &>> $4
       fi
     done
  fi
  writeToLog "$delCnt records deleted from s3" $4
}

#
# aaguirre - 05/20/13 - intelligent prompt
# function: prompt
# parameters:   $1(string): prompt text
#               $2(string): dynamic variable to be assigned
#               $3(string): default value. If blank, then response is required
#               $4(string): valid responses
#               $5(string): value: "exit" - exit if bad response
prompt () {

  # define prompt labels
  if [ $3 ]
    then
    defaultLabel="($3)"
  else
    defaultLabel='(required)'
  fi

  # while loop used for required prompts
  while [ 1 ]
    do
    # display the passed prompt and $3 label
    echo -n "$1 $defaultLabel: "
    read ans

    # if no response and no default param, then prompt reply is required, repeat loop
    if [ ! $ans ] && [ ! $3 ]
      then
      continue
    fi

    # if no response but a default param exists, then assign the default to response var
    if [ ! $ans ] && [ $3 ]
      then
      ans=$3
    fi

    # evaluate valid answers
    validResponse="false"
    if [ "$4" ]
      then
      validResponses=`echo $4 | tr "," " "`
      for row in $validResponses
        do
        if [ "$row" = "$ans" ]
          then
          validResponse="true"
          break
        fi
      done
    fi
    if [ "$validResponse" = "false" ]
      then
      if [ $5 ]
        then
        if [ "$5" = "exit" ]
          then
                  exit
        else
          echo "Invalid response"
          continue
        fi
      fi
    fi

    # if second parameter (dynamic variable) exists
    if [ $2 ]
      then
        # assign the response to the dynamic variable
        eval ${2}="$ans"  # assign dynamic variable
        break
    else
      echo "second parameter missing from function prompt(). Aborting."
      exit
    fi
  done

}

#
# aaguirre - 05/20/13 - intelligent prompt
# function: verifyFile
# parameters:   $1(string): type (f = file, d = directory)
#               $2(string): file or directory
#               $3(string): log file
verifyFile () {
  if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]
    then
    return 1
  fi
  type="$1"
  fileOrDir="$2"
  log="$3"
  
  if [ "$type" = "d" ]
    then
    label="directory"
  else
    label="file"
  fi
 
  if [ ! -${type} $fileOrDir ]
    then
    writeToLog "ERROR: $label $fileOrDir is invalid" $log 1
  else
    return 0
  fi
}
