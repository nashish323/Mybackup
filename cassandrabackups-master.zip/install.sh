#!/bin/bash
# ##################################################################################################
#
# FILE:         install.sh released 03/24/14
# VERSION:      Ver: 3.1:  08/04/14
# AUTHOR:       Albert Aguirre
# DESC:         Installs the Cassandra back up solution created by the NOSQL team
# USAGE:        bash install.sh [s3 bucket or NFS mount] [encryption passphrase]
#
# Revisions:	alberta - 03/26/14 - 	1.5: added installation of s3cmd
# 					     added installation of python tools
# 					     added installation of awscli
#
#           		alberta - 04/10/14 - 2.1: added s3 bucket parameter
#           		alberta - 04/18/14 - 2.2: added encryption passphrase
#           		alberta - 05/08/14 - 2.3: fixed passphrase bug
#           		alberta - 05/29/14 - 2.4: added logic for existing installations
#           		alberta - 06/03/14 - 2.5: added nodeFlag to install. Allows only chosen nodes to be backed up
#           					  added check for "/" at the end of the provided s3 bucket address
#           		alberta - 06/04/14 - 2.6: added check for existing cron job for reinstalls
#           		alberta - 07/31/14 - 3.0: added support for non cloud clusters
#           		alberta - 08/04/14 - 3.1: added NFS mount dir creation
#
# To Do list    alberta - add CLI config for s3cmd then  cp /home/ubuntu/.s3cfg /root
#
# Limitations:  Authentication not supported
#
# ##################################################################################################

#
# INIT VARS
nosqlDir="/opt/nosql" 
includesDir="${nosqlDir}/includes"
rootLocation="${nosqlDir}/cassandra"
backUpMaster="backUpMaster.sh"
backUpSlave="backUpSlave.sh"
backUpUtils="backUpUtils.sh"
confFile="backUpCassandra.conf"
backUpVars="backUpVars.sh"
confDir="/etc"
tmpLog="/tmp/backUpInstallation.log"
varsDir="/etc/nosql"
varsFile="${varsDir}/vars.sh"
reqFiles="$backUpMaster $backUpSlave $backUpUtils $backUpVars"
nodeFlag=""

## check required files
for row in $reqFiles
  do
  if [ ! -f $row ]
    then
    echo "File $row is missing. Cannot install."
    exit 1 
  fi
done

#
# FUNCTIONS
#

# help text
function helpText () {
  echo "Usage:"
  echo "bash install.sh [s3 bucket or NFS mount] [encryption passphrase]"
  echo 
  exit
}

# check return code of a command
function check () {
  retStat=$1
  msg=$2
  exitStatus=$3
  if [ $retStat -gt 0 ]
    then
    echo "$2"
    if [ ! -z $exitStatus ]
      then
      echo "Aborting"
      exit 1
    else
      echo "Proceeding"
    fi
  fi
}

# END FUNCTIONS #

#
# PRE CHECKS
#

# check for existing conf
if [ -f "${confDir}/${confFile}" ]
  then
  echo "Looks like you have an existing configuration file."
  echo -n "Would you like to keep your existing configuration? (y/n): "
  read keepConfig
else
  keepConfig="n"
fi

# keep config? and assign command line params
if [ "$keepConfig" = "y" ] || [ "$keepConfig" = "Y" ]
  then
  . ${confDir}/${confFile}
else
  ## check command line parameters
  if [ $# -ne 2 ]
    then
    helpText
  else
    s3BucketOrNFS="$1"
    encryptPass="$2"
  fi
fi

echo

# check for existing passphrase
if [ -f $varsFile ]
  then
  echo "Looks like you have an existing passphrase already installed on this server."
  echo -n "Would you like to keep your existing passphrase? (y/n): "
  read keepPass
else
  keepPass="n"
fi

# keep pass?
if [ "$keepPass" = "y" ] || [ "$keepPass" = "Y" ]
  then
  . $varsFile
else
  ## check command line parameters
  if [ $# -ne 2 ]
    then
    helpText
  else
    s3BucketOrNFS="$1"
    encryptPass="$2"
  fi
fi

# cloud or physical prompt
echo
echo "Please choose one:"
echo "1) This is a cloud cluster (AWS/Nibiru) or backups will be stored on an S3 bucket"
echo "2) This is physical cluster or backups will be stored on an NFS mount"
echo -n "Please choose one (q): "
read clusterType
echo
if [ "$clusterType" != "1" ] && [ "$clusterType" != "2" ]
  then
  echo "Aborting"
  exit 1
fi
echo

# check for existing crontab
cronCnt=`crontab -l | grep backUpMaster.sh | wc -l 2>/dev/null`
if [ $cronCnt -gt 0 ]
  then
  echo "Looks like you have an existing cron job already set up"
  echo -n "Would you like to keep your existing cronjob? (y/n): "
  read keepCron
else
  keepCron="n"
fi

echo

lastChar=`echo $s3BucketOrNFS | sed -e "s/^.*\(.\)$/\1/"`
if [ "$lastChar" != "/" ]
  then
  s3BucketOrNFS="${s3BucketOrNFS}/"
fi

# confirm start
case "$clusterType" in
  "1") clusterLabel="S3 bucket storage"; storageType="S3";;
  "2") clusterLabel="NFS mount storage"; storageType="NFS";;
esac

echo "Storage type: $clusterLabel"
echo "S3Bucket: $s3BucketOrNFS"
echo "Passphrase: $encryptPass"
echo -n "Continue? (y/n): "
read ans
if [ "$ans" != "y" ]
  then
  echo "Installation aborted"
  exit
fi

## create a default conf file
if [ "$keepConfig" != "y" ] || [ "$keepConfig" != "Y" ]
  then
  echo "# REQUIRED
backUpLocation=/data/backups												# location of logs and backup files
freeSpaceThreshold=20																# limit on available space left after backup in percentage
s3BucketOrNFS=$s3BucketOrNFS													# s3Bucket or NFS mount
storageType=$storageType												# storage type flag

# OPTIONAL
keepCount=30 																				# if not provided then backups will not be deleted
yamlFile=/etc/cassandra/cassandra.yaml							# cassandra config file. If not provided, the back up script will attempt to find it" > $confFile
fi

#
# MAIN
#

## install pssh for the parallel-ssh
apt-get update -y
 check $? "There was a problem updating packages prior to installation" 1

apt-get -y install pssh
 check $? "There was a problem installing the required package 'pssh'. The back up CANNOT run without this package" 1

if [ "$clusterType" = "1" ]
  then
  ## install s3cmd
  apt-get -y install s3cmd
   check $? "There was a problem installing the required package 's3cmd'. Backups cannot be archived without this package" 1
fi

## install python
apt-get -y install python-pip
 check $? "There was a problem installing the required package 's3cmd'. Backups cannot be archived without this package" 1
  
## install AWS CLI tools
if [ "$clusterType" = "1" ]
  then
  pip install awscli
   check $? "There was a problem installing the required package 'awscli'. Backups cannot be archived without this package" 1
fi

## create working directories
mkdir -p $rootLocation
 check $? "Could not create the nosql working directory" 1

mkdir -p $includesDir
 check $? "Could not create the includes directories" 1

## create internal security file
mkdir -p $varsDir
 check $? "Could not create the directory for vars" 1

## create NFS mount dir if not exists and if NFS option chosen
if [ "$clusterType" = "2" ]
  then
  if [ ! -d "$s3BucketOrNFS" ]
    then
    mkdir -p $s3BucketOrNFS
     check $? "Could not create the directory on the NFS mount to store backups" 1
  fi
fi

## create cron job
if [ "$keepCron" != "y" ] || [ "$keepCron" != "Y" ]
  then
  echo "00 00 * * * /bin/bash ${rootLocation}/$backUpMaster &> /tmp/backUpMasterCron.log" | crontab
fi

## move backup script files into working directories
cp ./$backUpMaster $rootLocation
	check $? "Could not copy backup master file to the working directory" 1

cp ./$backUpSlave $rootLocation
	check $? "Could not copy backup slave file to the working directory" 1

cp ./$backUpUtils "$includesDir"
	check $? "Could not copy backup utils file to the working directory" 1

cp ./$confFile $confDir
	check $? "Could not copy configuration file to $confDir" 1

cp ./$backUpVars $includesDir
	check $? "Could not copy backup vars file to the working directory" 1

if [ "$keepPass" != "y" ] || [ "$keepPass" != "Y" ]
  then
  # create vars.sh for passphrase storage
  cp $varsFile ${varsFile}.back.`date +%Y%m%d%H%M%S` &>/dev/null
  echo "encryptPass=${encryptPass}		# USER DEFINED. DO NOT REMOVE" > $varsFile
fi

# set node flag
date  > ${rootLocation}/backUp_this_node.enabled
if [ $? -ne 0 ]
  then
  echo "Unable to mark this node as a backup node. Aborting"
  exit
fi
echo "Created by the cassandra back up installation. Do not remove" >> ${rootLocation}/backUp_this_node.enabled
echo "This file must exist in order for this node to be backed up." >> ${rootLocation}/backUp_this_node.enabled
echo "The contents of this file are irrelevant." >> ${rootLocation}/backUp_this_node.enabled
echo "If you would like to disable backups on this node, simply rename this file." >> ${rootLocation}/backUp_this_node.enabled
echo "Example:" >> ${rootLocation}/backUp_this_node.enabled
echo "mv backUp_this_node.enabled backUp_this_node.disabled" >> ${rootLocation}/backUp_this_node.enabled

# s3cmd upgrade
if [ "$clusterType" = "1" ]
  then
  echo "Upgrading s3cmd"
  /bin/bash upgradeS3cmd.sh
fi

# clean up
rm $confFile
echo 
echo "Done!"
echo 
