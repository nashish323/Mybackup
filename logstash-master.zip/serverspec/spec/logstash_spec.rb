# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

pkgs = ['openjdk-7-jdk', 'logstash']
pkgs.each do |pkg|
  describe package("#{pkg}") do
    it { should be_installed }
  end
end

# test that jdk 7 is the system default
#The matcher 'return_stderr' does not handle multiline. Changing the command to output to stdout allows for 'match'
describe command('java -version 2>&1') do
  # java -version returns version number on std_err not std_out.
  it{ expect(subject.stdout).to match /.*java version.*1.7.*/ }
end

describe file("/etc/default/logstash") do
  it { expect(subject.content).to match 'START=no' }
end
describe file("/etc/default/logstash-web") do
  it { expect(subject.content).to match 'START=no' }
end

describe file("/etc/init/logstash.conf") do
  it { should_not be_file }
end
describe file("/etc/init/logstash-web.conf") do
  it { should_not be_file }
end

ls_agents = ['test1', 'test2']
ls_agents.each do |agent|

  etc_dirs = ['/etc/logstash', "/etc/logstash/#{agent}", "/etc/logstash/#{agent}/config"]
  etc_dirs.each do |dir|

    describe file("#{dir}") do
      it { should be_directory }
      it { should be_mode '755' }
    end

  end

  describe file("/etc/init.d/logstash-#{agent}") do
    it { should be_file }
    it { should be_mode '755' }
    it { expect(subject.content).to match "NAME=logstash-#{agent}" }
  end

  describe file("/etc/default/logstash-#{agent}") do
    it { should be_file }
    it { should be_mode '644' }
    it { expect(subject.content).to match 'START=yes' }
    it { expect(subject.content).to match "NAME=logstash-#{agent}" }
    it { expect(subject.content).to match "DESC=\"Logstash Daemon #{agent}\"" }
    it { expect(subject.content).to match "LS_USER=root" }
    it { expect(subject.content).to match "CONF_DIR=/etc/logstash/#{agent}/config" }
    it { expect(subject.content).to match 'PIDFILE=/var/run/\$NAME.pid' }
  end

  describe file('/var/log/logstash') do
    it { should be_directory }
    it { should be_owned_by 'logstash' }
    it { should be_grouped_into 'logstash' }
  end

  describe file("/var/log/logstash/logstash-#{agent}.log") do
    it { should be_file }
    it { should be_owned_by 'logstash' }
    it { should be_grouped_into 'logstash' }
  end

  describe service("logstash-#{agent}") do
    it { should_not be_running }
  end

  if agent.eql?('test1')
    describe file("/etc/default/logstash-#{agent}") do
      it { expect(subject.content).to match '-Xmx256m' }
    end

  elsif agent.eql?('test2')
      describe file("/etc/default/logstash-#{agent}") do
      it { expect(subject.content).to match '-Xmx64m' }
    end

  end

end
