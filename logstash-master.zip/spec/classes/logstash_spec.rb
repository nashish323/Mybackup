#Logstash is a define type module and does not need a class spec test
#this file is a stub to prevent doozer from creating the this file
