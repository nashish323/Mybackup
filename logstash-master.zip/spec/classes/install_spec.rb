# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

pkgs = ['logstash']

describe 'logstash::install' do

  it { should contain_class('logstash::params') }

  pkgs.each do |pkg|
    it { should contain_package("#{pkg}") }
  end

  it do
    should contain_file('/etc/logstash').with(
      'ensure'  => 'directory',
      'purge'   => true,
      'recurse' => true,
      'force'   => true,
      )
  end

  it do
    should contain_file('/var/log/logstash').with(
      'ensure' => 'directory',
      'owner'  => 'logstash',
      'group'  => 'logstash',
    )
  end
  it do
    should contain_file('/etc/init/logstash.conf').with(
      'ensure' => 'absent',
    )
    should contain_file('/etc/init/logstash-web.conf').with(
      'ensure' => 'absent',
    )
  end
  it do
    should contain_file_line('disable_core_logstash').with(
      'path' => '/etc/default/logstash',
      'line' => 'START=no',
    )
    should contain_file_line('disable_web_logstash').with(
      'path' => '/etc/default/logstash-web',
      'line' => 'START=no',
    )
  end

end
