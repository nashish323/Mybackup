# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'logstash::service' do
  
  let(:title) { 'foo' }

  it { should contain_service("logstash-#{title}").with_ensure('running') }
  
end
