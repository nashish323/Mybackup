# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'logstash' do
  
  agent = 'fooBarIndexer'
  jvm_size = '9999'

  let(:title) { "#{agent}" }
  let(:params) { {:java_max_heap_size_mb => "#{jvm_size}"} }

  it { should contain_class('logstash::install') }
  it { should contain_logstash__config("#{agent}") }

end
