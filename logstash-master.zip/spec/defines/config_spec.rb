require_relative '../spec_helper'

describe 'logstash::config' do

  agent = 'fooBarIndexer'
  jvm_size = '9999'

  context 'In all contexts' do

    let(:title) { "#{agent}" }
    let(:params) { {:java_max_heap_size_mb => "#{jvm_size}"} }

    it do
      should contain_file("logstash-#{agent}-dir").with(
        'ensure' => 'directory',
        'path'   => "/etc/logstash/#{agent}",
      )
    end

    it do
      should contain_file("logstash-#{agent}-conf-dir").with(
        'ensure'  => 'directory',
        'path'    => "/etc/logstash/#{agent}/config",
      )
    end

    it { should contain_file("/etc/init.d/logstash-#{agent}").with_mode('0755') }
    it { should contain_file("/etc/init.d/logstash-#{agent}").with_content(/^NAME=logstash-#{agent}.*$/) }

    it { should contain_file("/etc/default/logstash-#{agent}").with_mode('0644') }
    it { should contain_file("/etc/default/logstash-#{agent}").with_content(/^NAME=logstash-#{agent}.*$/) }
    it { should contain_file("/etc/default/logstash-#{agent}").with_content(/^DESC="Logstash Daemon #{agent}.*$/) }
    it { should contain_file("/etc/default/logstash-#{agent}").with_content(/^LS_USER=root.*$/) }
    it { should contain_file("/etc/default/logstash-#{agent}").with_content(/^LS_JAVA_OPTS="-Xmx#{jvm_size}m.*$/) }
    it { should contain_file("/etc/default/logstash-#{agent}").with_content(/^CONF_DIR=\/etc\/logstash\/#{agent}\/config.*$/) }

    it do
      should contain_file("logstash-#{agent}-log").with(
        'ensure' => 'present',
        'owner'  => 'logstash',
        'group'  => 'logstash',
        'path'   => "/var/log/logstash/logstash-#{agent}.log",
      )
    end

  end

  context 'manage_config true' do

    let(:title) { "#{agent}" }
    let(:params) { { :java_max_heap_size_mb => "#{jvm_size}",
      :manage_config => true } }

    it do
      should contain_file("logstash-#{agent}-conf-dir").with(
        'purge'   => true,
        'recurse' => true,
      )
    end

  end

  context 'manage_config false' do

    let(:title) { "#{agent}" }
    let(:params) { { :java_max_heap_size_mb => "#{jvm_size}",
      :manage_config => false } }

    it do
      should contain_file("logstash-#{agent}-conf-dir").with(
        'purge'   => false,
        'recurse' => false,
      )
    end

  end


end
