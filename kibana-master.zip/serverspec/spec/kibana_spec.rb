# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'kibana' do
  describe package('apache2') do
    it { should be_installed }
  end

  dirs = ['/var/www','/var/www/kibana']

  dirs.each do |dir|
    describe file("#{dir}") do
      it { should be_directory }
    end
  end

  describe file('/var/www/kibana/src/config.js') do
    it { should be_file }
  end

  describe service('apache2') do
    it { should be_running }
  end
end
