# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'kibana' do
  let :facts do
    {
      :lsbdistrelease => '12.04',
      :osfamily => 'Debian',
      :operatingsystem => 'Ubuntu',
      :operatingsystemrelease => '12.04',
      :hostname => 'dev',
      :concat_basedir => '/dne',
    }
  end

  it { should contain_class('kibana::install') }
  it { should contain_class('kibana::config') }
  it { should contain_class('kibana::service') }

end
