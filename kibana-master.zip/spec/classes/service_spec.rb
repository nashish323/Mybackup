# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'kibana::service' do

  context 'kibana 2' do
    let :params do 
      {
        :version => '2',
      }
    end

    it do
      should contain_file('kibana-init-upstart-link').with(
        'ensure'  => 'link',
        'path'    => '/etc/init.d/kibana',
        'target'  => '/lib/init/upstart-job',
      )
    end

    it do
      should contain_file('kibana-init-config').with(
        'ensure'  => 'present',
        'path'    => '/etc/init/kibana.conf',
        'content' => /chdir \/opt\/kibana/,
        'content' => /exec ruby kibana.rb/,
      )
    end

    it do
      should contain_service('kibana').with(
        'enable'     => true,
        'hasstatus'  => true,
        'hasrestart' => true,
        'provider'   => 'upstart',
      )
    end
  end

  context 'kibana 3' do
    let :facts do
      {
        :lsbdistrelease => '12.04',
        :osfamily => 'Debian',
        :operatingsystem => 'Ubuntu',
        :operatingsystemrelease => '12.04',
        :concat_basedir => '/dne',
      }
    end

  end

end
