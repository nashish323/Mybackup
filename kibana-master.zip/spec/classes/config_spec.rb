# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'kibana::config' do

  context 'kibana 2' do
    let :params do 
      {
        :version => '2',
        :elasticsearch_cluster_nodes_with_port => 'localhost:9200'
      }
    end

    it do
      should contain_file('kibana-config').with(
        'ensure'  => 'present',
        'path'    => '/opt/kibana/KibanaConfig.rb',
        'content' => /Elasticsearch = localhost:9200/,
        'content' => /KibanaPort = 5601/
      )
    end
  end

  context 'kibana 3' do
    let :facts do
      {
        :lsbdistrelease => '12.04',
        :osfamily => 'Debian',
        :operatingsystem => 'Ubuntu',
        :operatingsystemrelease => '12.04',
        :concat_basedir => '/dne',
      }
    end

    let :params do
      {
        :version => '3',
        :elasticsearch_cluster_nodes_with_port => 'localhost:9200',
      }
    end

    it do
      should contain_file('kibana-config').with(
        'ensure'  => 'present',
        'path'    => '/var/www/kibana/src/config.js',
        'content' => /kibana_index: "kibana-int"/,
        'content' => /elasticsearch: "localhost:9200"/
      )
    end
  end

end
