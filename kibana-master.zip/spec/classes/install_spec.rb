# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'kibana::install' do

  context 'kibana 2' do
    let :params do 
      {
        :version => '2'
      }
    end

    packages = ['git', 'rubygems', 'tzinfo', 'sinatra', 'fastercsv',
              'ruby-bundler', 'bundler']

    packages.each do |package|
      it { should contain_package("#{package}").with_ensure('installed') }
    end

    it do
      should contain_vcsrepo('kibana-vcsrepo').with(
        'ensure'   => 'present',
        'path'     => '/opt/kibana',
        'provider' => 'git',
        'source'   => 'git://github.com/rashidkpc/Kibana.git',
        'revision' => 'kibana-ruby',
      )
    end

    it do
      should contain_exec('create-kibana-bundle').with(
        'command' => 'bundle install kibana',
        'cwd'     => '/opt/kibana/',
        'unless'  => 'bundle show kibana | grep kibana',
        'path'    => ['/usr/bin', '/sbin', '/bin', '/usr/sbin'],
      )
    end
  end

  context 'kibana 3' do
    let :facts do
      {
        :lsbdistrelease => '12.04',
        :osfamily => 'Debian',
        :operatingsystem => 'Ubuntu',
        :operatingsystemrelease => '12.04',
        :concat_basedir => '/dne',
      }
    end

    let :params do
      {
        :version => '3'
      }
    end

    it { should contain_package("git").with_ensure('installed') }

    it do
      should contain_vcsrepo('kibana-vcsrepo').with(
        'ensure'   => 'present',
        'path'     => '/var/www/kibana',
        'provider' => 'git',
        'source'   => 'git://github.com/elasticsearch/kibana.git',
        'revision' => 'v3.1.0'
      )
    end
    
  end
end
