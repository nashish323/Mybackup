# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# modified by rajao to delete nextext nodes in batch

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def delete_instance(hostname):
    '''Function to create tomcat instance'''    
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = "fb4ef7b4-7547-4f39-aa4a-133a6ea65430"
    nib = Nibiru(nibiruHost, bearer_token=token);

    print("Zone info and env is" , hostname)
    print("deleting app node instance...")
    try:
        response = nib.under('instances').delete("https://nibiru-prod.prsn.us/api/async/instances/"+hostname)
	#instance_url = HalResource(response).get_self_link()
	#print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deleting the node! ", err)
    return hostname;

    
###############################
########   INSTANCES   ########
###############################

if __name__ == '__main__':

    #_version = "1.1.0" # instance version tag
    _env = "stg" # prd, stg or dev
    _appname = "las"
    _hosts = ["prd-use1b-pr-55-dragon-01x01x00-0001",
"prd-use1b-pr-55-dragon-01x01x00-0002",
"prd-use1b-pu-55-dragonb-hapy-0001",
"prd-use1c-pu-55-dragonb-hapy-0002",
"prd-use1c-pr-55-dragon-01x01x00-0001",
"prd-use1c-pr-55-dragon-01x01x00-0002",
"prd-use1b-pr-55-paper-01x01x00-0001",
"prd-use1b-pr-55-paper-01x01x00-0002","prd-use1b-pu-55-paperb-hapy-0001",
"prd-use1c-pu-55-paperb-hapy-0001","prd-use1c-pr-55-paper-01x01x00-0001","prd-use1c-pr-55-paper-01x01x00-0002"]

    #LOOPS THROUGH ENTIRE LIST OF ITEMS IN _HOSTS AND UPDATE BASED ON ANY CHANGES TO JSON ABOVE
    for i in range(len(_hosts)):
        delete_instance(_hosts[i])





