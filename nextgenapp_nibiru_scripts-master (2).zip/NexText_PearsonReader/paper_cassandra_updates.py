# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# use for seeding cassandra nodes once the nodes have been created

# UPDATE TEAM ID & TOKEN

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def update_cassandra(env, appname, _region, seedip1, seedip2, casdb_host):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Input is ", env, appname, _region, seedip1, seedip2, casdb_host)

    cas_info= {
        "_links": {
        "owner": {
        "href": teamid_url
                 }
                },
        "environment": env,
        "app_name": appname,
        "app_type": "cadb",
         "puppet": {
         "classes": {
                "cassandra": {
                    "cluster_name": appname,
                    "version": "2.0.5",
                    "endpoint_snitch": "Ec2Snitch",
                    "rpc_address": "0.0.0.0",
                    "seeds": [
                        seedip1,
                        seedip2
			]
                    }
                 }
                }
	     }
	 
    print("Data to send...", cas_info)
    print("Updating cassandra instance with seeds...")
    
    try:
        response = nib.under('applications').under('cassandra').update(casdb_host, cas_info)
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        
    return cas_info;


###############################
########   INSTANCES   ########
###############################
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':

    #UPDATE THIS SECTION FIRST
    _appname = "paper"
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/55"
    teamtoken = "fb4ef7b4-7547-4f39-aa4a-133a6ea65430" # 55 NEXTEXT
    _env = "stg" # prd, stg or dev
    #NEW SERVER - 10.199.10.142 stg-use1b-pr-55-dragon-cadb-0004
    #  replacing stg-use1b-pr-55-dragon-cadb-0002 - 10.199.0.208
    stg_dbhosts = ["stg-use1b-pr-55-paper-cadb-0002","stg-use1b-pr-55-paper-cadb-0003","stg-use1c-pr-55-paper-cadb-0002","stg-use1c-pr-55-paper-cadb-0003","stg-use1d-pr-55-paper-cadb-0002"]
    #NEW SERVER - prd-use1c-pr-42-las-cadb-0012 - 10.198.8.58 | replacing prd-use1c-pr-42-las-cadb-0010 - 10.198.2.217
    ###### end of environment specific vars#########

    #LOOPS THROUGH ENTIRE LIST OF ITEMS IN _HOSTS AND UPDATE BASED ON ANY CHANGES TO JSON ABOVE
    # STAGING
    for i in range(len(stg_dbhosts)):
    #env, appname, _region, seedip1, seedip2, casdb_host
        update_cassandra(_env, _appname, "us-east-1", "10.199.10.215", "10.199.8.242",'https://nibiru-prod.prsn.us/api/instances/'+stg_dbhosts[i])
