# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# modified by rajao for NextText/Reader and Paper api tomcat and cassandra node creation

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def create_tomcat_instance_async(zoneinfo, env, thal_host, appname, version, syncstatus):
    '''Function to create tomcat instance asynchronously'''
    
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    print("Zone info and env is" , zoneinfo, env, appname, thal_host, version, syncstatus)
    instance_info = {
        "environment": env,
        "app_name": appname,
	"_links" : {
	    "owner": {
	    "href": teamid_url,
	             },
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "tomcat": {},
                "thalassa::client": {
                      "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  },
                  "storage_type": "remote"
        }    

    print("Creating app node instance...")
    #print("Data to send...", instance_info)
    try:
        response = nib.under('instances').create(instance_info, async=syncstatus)
        '''while not nib.async_is_ready(response):
            time.sleep(10)'''
        #result = nib.async_get_result(response)
        #print("result is..", result)
        #print('Actually going to update instances....')
        #use below to update existing instances open                                        
        #response = nib.under('instances').update("https://nibiru-prod.prsn.us/api/instances/dev-use1b-pr-53-las-01x00x00-0005",instance_info)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


def createhaproxy_async(zoneinfo, env, appname, syncstatus):
    '''Function to create haproxy'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    print("Parameters" , zoneinfo, env, appname, syncstatus)
    print("env is" , env)

    haproxy_def= {
        "_links": {
        "owner": {
        "href": teamid_url,
                 }
                },
        "environment": env,
        "app_name": appname,
        "privacy": "pub",
        "aws": {
        "zone": zoneinfo
                },
            }

    print("Creating haproxy instance...")
    
    try:
        response = nib.under('applications').under('haproxy').create(haproxy_def, async=syncstatus)
    	instance_url = response['_links']['self']['href']
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        return haproxy_def;


def create_cassandra_cluster(env, _region, appname, syncstatus):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    print("Parameters" , env, appname, syncstatus)
    print("env is" , env)

    cas_info= {
        "_links": {
        "owner": {
        "href": teamid_url,
                 }
                },
        "environment": env,
        "app_name": appname,
        "app_type": "cadb",
         "puppet": {
                    "classes": {
                        "cassandra": {
                             "cluster_name": appname,
                             "version": "2.0.5"
                            }
                        }
                    },
        "aws": {
            "size": "m1.xlarge",
            "region": _region  # - will do multiregion if not specified
                },
        "storage_type": "local"
                }
    print("Data to send...", cas_info)
    print("Creating cassandra instance...")
    
    try:
        response = nib.under('applications').under('cassandra').create(cas_info, async=syncstatus)
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        
    return cas_info;


def create_cassandra_single(env, appname, zoneinfo, syncstatus):
    '''Function to create cassandra node''' #create_basic_elasticsearch_cluster(_env, _appname, "us-east-1", "True")
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    print("env, appname & region is" , env, appname, zoneinfo, syncstatus)

    cas_info={ "_links" : {
        "owner": {
            "href": teamid_url
            }
        },
        "app_name": appname,
        "app_type": "cadb",
               "aws": {
                   "size": "m1.xlarge",
                   "zone": zoneinfo    #"us-east-1b"
                   },
               "environment": env,
               "privacy": "priv",
               "puppet":
                   {
                       "classes":
                       {
                           "cassandra":
                           {
                                "cluster_name": appname,
                                "version": "2.0.5"
                               }
                           }
                       },
               "storage_type": "local"
               }

    print("Data to send...", cas_info)
    print("Creating single cassandra instance...")
    
    try:
        response = nib.under('instances').create(cas_info, async=syncstatus)
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)

    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return cas_info;

###############################
########   INSTANCES   ########
###############################
# Loop through and create # of nodes specifed with maxnodes and call function to create node for zones needed
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':

    nodecounter = 1
    # variables that get changed depending on # of nodes, version # and environment
    maxnodes = 2  #number of nodes I want to create per cluster per zone, used to terminate while loop when that value is reached.
    _version = "1.1.0" # instance version tag
    #_env = "prd" # prd, stg or dev
    _appname = "paper"  #reader or paper
    ###### end of environment specific vars#########
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/55"
    teamtoken = "fb4ef7b4-7547-4f39-aa4a-133a6ea65430"
    ##TODO make prompts for things like env specific vars and ask what kind of DB is needed or if DB needed
    ######################## end of variables to change#########################################

    environments = {'dev', 'stg', 'prd'}
    _env = raw_input('What environment are you working in: |dev|stg|prd| ? ')
    print("You have entered", _env)
    if _env not in environments:
        print("You have entered incorrect environment")
        exit

    # _version = raw_input('What version number are you tagging the app nodes with: must be x.x.x format ? ')
    # print("You have entered", _version)
    #
    #_appname = raw_input('What is your app name: should be lower case & no longer than 6 chars ? ')
    #print("You have entered", _appname)
    #
    #maxnodes = raw_input('How many app nodes do you want per zone. Only stg & prd will use 2 zones? ')
    #print("You have entered", maxnodes)

    #print("If this was true I would create a cassandra cluster")
    #create_cassandra_cluster(_env, "us-east-1", _appname, "True") 

    #call func to create sdk haproxy in each zone, this is not part of while loop......
    #2 haproxies total for proda nd pqa since dual zone. Only 1 for DEV.
    #if _env |= ("dev"|"qa"):
    #     createhaproxy_async("us-east-1b", _env, _appname, "True") # use hapybname for B stack instead of appname
    #     createhaproxy_async("us-east-1c", _env, _appname, "True")
    #else:
    # 1 HAPROXY for DEV or QA
    #    print("If this was true I'd be haproxies for B stack")
    #    createhaproxy_async("us-east-1b", _env, hapybname, "True")


    while True:
        nodecounter += 1
        print("If this was true I would create instances for", _env)
        create_tomcat_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com",_appname,_version, "True")
        create_tomcat_instance_async("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com",_appname,_version, "True")
        if nodecounter > maxnodes:
            break






