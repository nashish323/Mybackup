round #!bin/env python
# If you don't already have the requests module installed, install it using:
# pip install requests
# pip install argparse
# rajao 1/29/2014 - This script is to register BE servers to the Bluesky or cutover stacks& also does ELB configuration
# NOTE can be run standlaone with the nibiru imports anywhere
from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import time
import requests
import argparse
import json

def register_backends_with_natives(host, app_name, the_version):
    '''register backend services to haproxy'''
		    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                #"keepalive": "close", we dont need forceclose option as we do http-server-close below
                "rules": [],
                "natives": ["option http-server-close", "option forwardfor"]
        }
    print("Configuring Haproxy frontend")
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
                "natives": ["appsession JSESSIONID len 250 timeout 3h request-learn"]
    }
    
    print haproxy_backend
    print("Registering backends to HAProxy")
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

def register_backends(host, app_name, the_version):
    '''register backend services to haproxy'''
		    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": []
        }
    print("Configuring Haproxy frontend")
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version
                }
    
    print haproxy_backend
    print("Registering backends to HAProxy")
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

def create_elb(env, appname, region, haproxyhost1, haproxyhost2, action):
    '''function to create ELB instance and add haproxies to it'''
    print ("Arguments passed..", env, appname, region, haproxyhost1, haproxyhost2, action)
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = "24b621ff-9d3a-4012-873d-fe40506f2182"
    nib = Nibiru(nibiruHost, bearer_token=token);

    elb_data = {
                "environment": env,
                "_links": {
                    "owner": {
                    "href": "https://nibiru-prod.prsn.us/api/teams/40",
                 }
                },
                "app_name": appname,
                "privacy": "pub",
                "aws": {
                    "region": region
                },
                "frontend": {
                "listeners": [
                    {
                        "protocol": "HTTP",
                        "loadbalancer_port": 80,
                        "instance_port": 80
                    },
                  ]
                },
                "backend": {
                    "health_check": {
                        "path": "/index.html",
                        "protocol": "HTTP",
                        "port": 80
                }
                },
                "_embedded": {
                "backend_instances": [
                    {
                        "id": haproxyhost1
                    },
                       {
                        "id": haproxyhost2
                        },
                    ]
                   }
                }
    print ("Data passed is ", elb_data)

    try:
        if (action == "create"):
            print("Creating ELB...")
            response = nib.under('loadbalancers').create(elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "update"):
            #to update - use this to add 2nd haproxy server as well or any other updates needed to ELB.
            print("Updating ELB resource...")
            response = nib.under('loadbalancers').update('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-40-'+appname+'-0',elb_data)

        if (action == "delete"):
            print("Deleting an ELB resource...")
            response = nib.under('loadbalancers').delete('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-40-'+appname+'-0')

    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return elb_data;


if __name__ == '__main__':
#TODO Seperate out script for cutover only and it just prompts for version
    environments = {'dev', 'stg', 'prd'}
    _env = raw_input('What environment are you working in: |dev|stg|prd| ? ' )
    print("You have entered", _env)
    
    if _env not in environments:
        print("You have entered incorrect environment")
        exit
    
    #_env = dev|stg|prd 
    currentver = "1.0.0"
    bskyapp = "blueskypqa"
    csgapp = "csgpqa"
    bskyappb = ""
    csgappb =""

    haproxyStackA_bsky_zoneb = _env+'-use1b-pu-40-'+bskyapp+'-hapy-0001'
    haproxyStackA_csg_zoneb = _env+'-use1b-pu-40-'+csgapp+'-hapy-0001'
    haproxyStackA_bsky_zonec = _env+'-use1d-pu-40-'+bskyapp+'-hapy-0001' # STG-0002, PROD-0001
    haproxyStackA_csg_zonec = _env+'-use1d-pu-40-'+csgapp+'-hapy-0001'

    haproxyStackB_bsky_zoneb = _env+'-use1b-pu-40-'+bskyappb+'-hapy-0001'
    haproxyStackB_csg_zoneb = _env+'-use1b-pu-40-'+csgappb+'-hapy-0001'
    haproxyStackB_bsky_zonec = _env+'-use1c-pu-40-'+bskyappb+'-hapy-0001' # STG-0002, PROD-0001
    haproxyStackB_csg_zonec = _env+'-use1c-pu-40-'+csgappb+'-hapy-0001'
    
    # Registering main zone A nodes
    
    # register_backends_with_natives(haproxyStackA_bsky_zoneb+'.prv-openclass.com','bluesky',currentver)
    # register_backends_with_natives(haproxyStackA_bsky_zonec+'.prv-openclass.com','bluesky',currentver)
    #register_backends(haproxyStackA_csg_zoneb+'.prv-openclass.com','csg',currentver)
    #register_backends(haproxyStackA_csg_zonec+'.prv-openclass.com','csg',currentver)

    #create_elb(_env, "csgpqa", "us-east-1", haproxyStackA_csg_zoneb, haproxyStackA_csg_zonec, "create")
    create_elb(_env, "blueskypqa", "us-east-1", haproxyStackA_bsky_zoneb, haproxyStackA_bsky_zonec, "create")

    ## ELB UPDATES
    # create_elb(_env, "bskyb", "us-east-1", haproxyStackB_bsky_zoneb, haproxyStackB_bsky_zonec, "update")

    # To Cutover and Swap out instance nodes, switch out versions below..
    # cutover_backends('stg-use1b-pu-40-bluesky-hapy-0001.prv-openclass.com','bluesky','1.0.0')
    # cutover_backends('stg-use1b-pu-40-bluesky-hapy-0002.prv-openclass.com','bluesky','1.1.0') 

