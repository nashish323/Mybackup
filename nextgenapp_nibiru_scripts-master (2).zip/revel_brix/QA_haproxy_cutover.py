#!bin/env python
# If you don't already have the requests module installed, install it using:
# pip install requests
# pip install argparse
# rajao 2/03/2014 - This script is to register BE servers to the Brix  haproxies and also cutover if needed.
# rajao 3/6/2015 - Updated script so that there's no need to edit, it will just flip instance stacks each time accross A & B
# via the haproxy using thalassa

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import time
import requests
import argparse
import json
import string

def register_backends(host, app_name, the_version):
    '''register backend services to haproxy'''
    print("Using data..", host, app_name, the_version)
    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
		#"keepalive": "close",
                "rules": [],
                "natives": []
                    }

    print("Configuring Haproxy frontend")
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
    }
    

    print haproxy_backend
    print("Registering backends to HAProxy")
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

def delete_backends(host, app_name, the_version):
    '''delete backend services from haproxy'''
    print("Using data..", host, app_name, the_version)
    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "keepalive": "close",
                "rules": [],
                "natives": []
                    }

    print("Deleting Haproxy frontend")
    print haproxy_frontend
    response = requests.delete('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
    }
    

    print haproxy_backend
    print("Deleting backends to HAProxy")
    response = requests.delete('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

if __name__ == '__main__':    
    _env = "stg"

    current_ver = "1.0.0"
    test_ver = "1.1.0"

    appname_ce = "qabrixce"
    appname_ips = "qaips"

    haproxyStackA_ce_zoneb = _env+'-use1b-pu-11-'+appname_ce+'-hapy-0001'
    haproxyStackA_ips_zoneb = _env+'-use1b-pu-11-'+appname_ips+'-hapy-0001'
    
    haproxyStackB_ips_zoneb = _env+'-use1b-pu-11-qaipsb-hapy-0001'
    haproxyStackB_ce_zoneb = _env+'-use1b-pu-11-qabrixceb-hapy-0001'

    answer = raw_input('Would you like the livestack to be 1.0.0 or 1.1.0? Enter 110 or 100: ')
    print("You have entered", answer)
    if answer == "110":
        current_ver = current_ver.replace("1.0.0", "1.1.0")
        test_ver = test_ver.replace("1.1.0", "1.0.0")
        print("This will switch the live instances to nodes tagged version 1.1.0")
    elif answer == "100":
        current_ver = current_ver.replace("1.1.0", "1.0.0")
        test_ver = test_ver.replace("1.0.0", "1.1.0")
        print("This will switch the live instances to nodes tagged version 1.0.0")
            
    else:
        print("no cutover, so nothing will change. HAPROXY will just reregister itself to existing instances")


#########################END OF VARIABLES#######################################
    ## TODO - make ce and ips string in haproxy names variable for appname instead? and add +b for bstack?

    print ('Updating HAPROXY Live Stack First................................')
    register_backends(haproxyStackA_ips_zoneb+'.prv-openclass.com',appname_ips,current_ver)
    register_backends(haproxyStackA_ce_zoneb+'.prv-openclass.com',appname_ce,current_ver)

    print ('Updating HAPROXY NON Live Stack Now................................')
    register_backends(haproxyStackB_ips_zoneb+'.prv-openclass.com',appname_ips,test_ver)
    register_backends(haproxyStackB_ce_zoneb+'.prv-openclass.com',appname_ce,test_ver)
 

