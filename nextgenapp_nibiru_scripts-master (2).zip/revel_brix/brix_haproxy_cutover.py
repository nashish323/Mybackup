#!bin/env python
# If you don't already have the requests module installed, install it using:
# pip install requests
# pip install argparse
# rajao 2/03/2014 - This script is to register BE servers to the Brix  haproxies and also cutover if needed.
from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import time
import requests
import argparse
import json

#TODO - ADD seperate function for ELB update or use same function with extra action string and conditional statement

def register_backends(host, app_name, the_version):
    '''register backend services to haproxy'''
    print("Using data..", host, app_name, the_version)
    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
		#"keepalive": "close",
                "rules": [],
                "natives": []
                    }

    print("Configuring Haproxy frontend")
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
    }
    

    print haproxy_backend
    print("Registering backends to HAProxy")
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

def delete_backends(host, app_name, the_version):
    '''delete backend services from haproxy'''
    print("Using data..", host, app_name, the_version)
    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "keepalive": "close",
                "rules": [],
                "natives": []
                    }

    print("Deleting Haproxy frontend")
    print haproxy_frontend
    response = requests.delete('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
    }
    

    print haproxy_backend
    print("Deleting backends to HAProxy")
    response = requests.delete('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

if __name__ == '__main__':
    #TODO Seperate out script for cutover only and it just prompts for version
    environments = {'dev', 'stg', 'prd'}
    _env = raw_input('What environment are you working in: |dev|stg|prd| ? ' )
    print("You have entered", _env)
    
    if _env not in environments:
        print("You have entered incorrect environment")
        exit
    
    #_env = dev|stg|prd

# To Cutover and Swap out instance nodes if doing A/B Stack deployment, swap values for current_var & test_ver above    
    current_ver = "1.0.0"
    test_ver = "1.1.0"
    appname_ce = "qabrixce"
    appname_ips = "qaips"
    appname_web = "authweb"

    haproxyStackA_ce_zoneb = _env+'-use1b-pu-11-'+appname_ce+'-hapy-0001'
    haproxyStackA_ips_zoneb = _env+'-use1b-pu-11-'+appname_ips+'-hapy-0001'

    haproxyStackA_ce_zonec = _env+'-use1c-pu-11-'+appname_ce+'-hapy-0001'
    haproxyStackA_ips_zonec = _env+'-use1c-pu-11-'+appname_ips+'-hapy-0001'
    
    haproxyStackB_ips_zoneb = _env+'-use1b-pu-11-qaipsb-hapy-0001'
    haproxyStackB_ce_zoneb = _env+'-use1b-pu-11-qabrixceb-hapy-0001'

    haproxyStackB_ips_zonec = _env+'-use1c-pu-11-'+appname_ips+'-hapy-0001'
    haproxyStackB_ce_zonec = _env+'-use1b-pu-11-'+appname_ce+'-hapy-0001'

    haproxyStackA_web_zoneb = _env+'-use1b-pu-11-'+appname_web+'-hapy-0001'
#########################END OF VARIABLES#######################################
    ## TODO - make ce and ips string in haproxy names variable for appname instead? and add +b for bstack?

    register_backends(haproxyStackA_ips_zoneb+'.prv-openclass.com',appname_ips,current_ver)
##    delete_backends(haproxyStackA_ce_zoneb+'.prv-openclass.com',"appname_ips",current_ver)
    register_backends(haproxyStackA_ce_zoneb+'.prv-openclass.com',appname_ce,current_ver)
    #register_backends(haproxyStackA_ce_zonec+'.prv-openclass.com',appname_ce,current_ver)
    #register_backends(haproxyStackA_ips_zonec+'.prv-openclass.com',appname_ips,current_ver)

    register_backends(haproxyStackB_ips_zoneb+'.prv-openclass.com',appname_ips,test_ver)
    register_backends(haproxyStackB_ce_zoneb+'.prv-openclass.com',appname_ce,test_ver)
    #register_backends(haproxyStackB_ips_zonec+'.prv-openclass.com',appname_ips,test_ver)
    #register_backends(haproxyStackB_ce_zonec+'.prv-opeenclass.com',appname_ce,test_ver)

##  Only used where web node is needed..
##    register_backends(haproxyStackA_web_zoneb+'.prv-openclass.com',appname_web,current_ver)

##  for PROD & PQA, this really should done after creating all haproxies - LAST, check if update or create before running

