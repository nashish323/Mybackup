# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 02/03/2014
# modified by rajao for svbrix plain java nodes for redis & nodejs install later

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def createhaproxy(zoneinfo, env, appname, asyncStatus):
    '''Function to create haproxy'''

    print("Zone, env and appname is" , zoneinfo, env, appname, asyncStatus)
    haproxy_def= {
        "_links": {
        "owner": {
        "href": "https://nibiru-prod.prsn.us/api/teams/11",
                 }
                },
        "environment": env,
        "app_name": appname,
        "privacy": "pub",
        "aws": {
           "zone": zoneinfo,
           "size": "t2.small"
                },
        "puppet": {
        "classes": {
            "profiles::web_proxy": {
                "domain": "openclass.com" #stg-openclass.com for stg, #dev-openclass.com for dev
                                }
                   }
                },
        "storage_type": "remote"        
            }

    print("Creating haproxy instance...")
    
    try:
        response = nib.under('applications').under('web_proxy').create(haproxy_def, async=asyncStatus)
    	instance_url = response['_links']['self']['href']
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        return haproxy_def; 

    
################################
########   INSTANCES   ########
################################
# Loop through and create # of nodes specifed with maxnodes and call function to create node for zones needed
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':
    teamtoken = "849dadd1-66af-406d-ad20-b66b4569121c"
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);
    counter = 1   #counter to keep track of how many times I loop


    # variables that get changed depending on # of nodes, version # and environment
    maxnodes = 1  #number haproxies I want per zone
    _env = "prd" # prd, stg or dev
    appbrix = "brixce" 
    appips  = "ips"
    appbrixb = "brixceb" 
    appipsb  = "ipsb"


    #createhaproxy("us-east-1b", _env, appbrix, "True")
    createhaproxy("us-east-1c", _env, appbrix, "True")
    createhaproxy("us-east-1b", _env, appips, "True")
    #createhaproxy("us-east-1c", _env, appips, "True") 
    #createhaproxy("us-east-1b", _env, appbrixb, "True") 
    createhaproxy("us-east-1c", _env, appbrixb, "True")
    createhaproxy("us-east-1b", _env, appipsb, "True")  
    createhaproxy("us-east-1c", _env, appipsb, "True") 
    


    
    
    


