#!bin/env python
# If you don't already have the requests module installed, install it using:
# pip install requests
# pip install argparse
# rajao 1/29/2014 - This script is to register BE servers to SVCORE or cutover stacks
from time import sleep
import logging
import time
import requests
import argparse
import json

def register_backends_with_aclrules(host, app_name, the_version, lasapp):
    '''register backend services to haproxy'''

    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": [
                    {
                "type": "path",
                "operation": "path_beg",
                "value": "/las",
                "backend": lasapp # if rule is met, the backend to route the request to
                    }
                ]
        }
    print("Configuring Haproxy frontend for", host)
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()

    # Need 2 backends here due to redirection rule above

    haproxy_backend1 = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
    }

    print haproxy_backend1
    print("Registering backends to HAProxy for", host)
    response1 = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend1))
    print response1.json()

    haproxy_backend2 = {
                "type" : "dynamic",
                "name" : lasapp,
                "version" : the_version,
                "natives": ["compression algo gzip","compression type text/html text/plain text/css application/javascript"]
    }

    print haproxy_backend2
    print("Registering second backend to HAProxy for", host)
    response2 = requests.put('http://' + host + ':10000/backends/' + lasapp, data=json.dumps(haproxy_backend2))
    print response2.json()
    return

def register_backends(host, app_name, the_version):
    '''register backend services to haproxy'''
    print("data entered is...", host, app_name, the_version)
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": []
        }
    print("Configuring Haproxy frontend for", host)
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()

    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
                "natives": ["compression algo gzip","compression type text/html text/plain"]
                }

    print haproxy_backend
    print("Registering backends to HAProxy for", host)
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return


if __name__ == '__main__':
#TODO Seperate out script for cutover only and it just prompts for version
    environments = {'dev', 'stg', 'prd'}
    _env = raw_input('What environment are you working in: |dev|stg|prd| ? ' )
    print("You have entered", _env)

    if _env not in environments:
        print("You have entered incorrect environment")
        exit

    # VARIABLES TO UPDATE
    #_env = dev|stg|prd
    teamid = "42"
    currentver = "1.1.0"
    testver = "1.0.0"

    ghapp = "greenhorn"
    lasapp = "las"
    ghappb = "greenhornb"
    lasappb = "lasb"
    # END VARIABLES TO UPDATE

    haproxyStackA_gh_zoneb = _env+'-use1b-pu-'+teamid+'-'+ghapp+'-hapy-0001'
    haproxyStackA_las_zoneb = _env+'-use1b-pu-'+teamid+'-'+lasapp+'-hapy-0001'
    haproxyStackA_gh_zonec = _env+'-use1c-pu-'+teamid+'-'+ghapp+'-hapy-0001'
    haproxyStackA_las_zonec = _env+'-use1c-pu-'+teamid+'-'+lasapp+'-hapy-0001'

    haproxyStackB_gh_zoneb = _env+'-use1b-pu-'+teamid+'-'+ghappb+'-hapy-0001'
    haproxyStackB_las_zoneb = _env+'-use1b-pu-'+teamid+'-'+lasappb+'-hapy-0001'
    haproxyStackB_gh_zonec = _env+'-use1c-pu-'+teamid+'-'+ghappb+'-hapy-0001'
    haproxyStackB_las_zonec = _env+'-use1c-pu-'+teamid+'-'+lasappb+'-hapy-0001'

    #With ACL Rules function is for Greenhorn HAproxy only
    print("Registering Backends to Stack A HAPROXY")
    register_backends_with_aclrules(haproxyStackA_gh_zoneb+'.prv-openclass.com',ghapp,currentver,lasapp)
    register_backends_with_aclrules(haproxyStackA_gh_zonec+'.prv-openclass.com',ghapp,currentver,lasapp)
    register_backends(haproxyStackA_las_zoneb+'.prv-openclass.com',lasapp,currentver)
    register_backends(haproxyStackA_las_zonec+'.prv-openclass.com',lasapp,currentver)

    print("Registering Backends to Stack A HAPROXY")
    register_backends_with_aclrules(haproxyStackB_gh_zoneb+'.prv-openclass.com',ghapp,testver, lasapp)
    register_backends_with_aclrules(haproxyStackB_gh_zonec+'.prv-openclass.com',ghapp,testver, lasapp)
    register_backends(haproxyStackB_las_zoneb+'.prv-openclass.com',lasapp,testver)
    register_backends(haproxyStackB_las_zonec+'.prv-openclass.com',lasapp,testver)



