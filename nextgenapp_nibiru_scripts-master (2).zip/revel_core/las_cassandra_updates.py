# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# use for seeding cassandra nodes once the nodes have been created

# UPDATE TEAM ID & TOKEN

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def update_cassandra_110(env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Input is ", env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host)

    cas_info= {
        "_links": {
        "owner": {
        "href": teamid_url
                 }
                },
        "environment": env,
        "app_name": appname,
        "app_type": "cadb",
         "puppet": {
         "classes": {
                "cassandra": {
                    "cluster_name": appname,
                    "version": "2.0.5",
                    "endpoint_snitch": "Ec2Snitch",
                    "rpc_address": "0.0.0.0",
                    "java_max_heap_size": "8192M",
                    "java_heap_newsize": "2048M",
                    "seeds": [
                        seedip1,
                        seedip2,
                        seedip3,
                        seedip4,
                        seedip5
                            ]
                        }
                    }
                },
        "aws": {
            "size": "m1.xlarge",
            "region": _region      #us-east-1
                },
        "storage_type": "local"
                }
    
    print("Data to send...", cas_info)
    print("Updating cassandra instance with seeds...")
    
    try:
        response = nib.under('applications').under('cassandra').update(casdb_host, cas_info)
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        
    return cas_info;

def update_cassandra_100(env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Input is ", env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host)

    cas_info= {
        "_links": {
        "owner": {
        "href": teamid_url
                 }
                },
        "environment": env,
        "app_name": appname,
        "app_type": "cadb",
         "puppet": {
         "classes": {
                "cassandra": {
                    "cluster_name": "las_prod",
                    "version": "2.0.5",
                    "endpoint_snitch": "Ec2Snitch",
                    "rpc_address": "0.0.0.0",
                    "java_max_heap_size": "8192M",
                    "java_heap_newsize": "2048M",
                    "seeds": [
                        seedip1,
                        seedip2,
                        seedip3,
                        seedip4,
                        seedip5
                            ]
                        }
                    }
                },
        "aws": {
            "size": "m1.xlarge",
            "region": _region      #us-east-1
                },
        "storage_type": "local"
                }

    print("Data to send...", cas_info)
    print("Updating cassandra instance with seeds...")

    try:
        response = nib.under('applications').under('cassandra').update(casdb_host, cas_info)
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)

    except NibiruError as err:
        print("There was an error deploying the node! ", err)

    return cas_info;


###############################
########   INSTANCES   ########
###############################
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':

    #UPDATE THIS SECTION FIRST
    _appname = "las"
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/42"
    teamtoken = "9801259f-5e6e-46fa-8e8b-2f5c51f96a72" #42 REVEL
    _env = "stg" # prd, stg or dev
    #NEW SERVER - 10.199.10.142 stg-use1b-pr-55-dragon-cadb-0004
    #  replacing stg-use1b-pr-55-dragon-cadb-0002 - 10.199.0.208
    stg_dbhosts = ["stg-use1b-pr-42-las-cadb-0010","stg-use1b-pr-42-las-cadb-0008","stg-use1c-pr-42-las-cadb-0007","stg-use1c-pr-42-las-cadb-0008","stg-use1d-pr-42-las-cadb-0004"]
    prd_db_110 = ["prd-use1b-pr-42-las-cadb-0009","prd-use1b-pr-42-las-cadb-0010","prd-use1c-pr-42-las-cadb-0009","prd-use1c-pr-42-las-cadb-0012","prd-use1d-pr-42-las-cadb-0005"]
    prd_db_100 = ["prd-use1c-pr-42-las-cadb-0013","prd-use1b-pr-42-las-cadb-0013","prd-use1b-pr-42-las-cadb-0014","prd-use1c-pr-42-las-cadb-0014","prd-use1d-pr-42-las-cadb-0007"]
    ###### end of environment specific vars#########

    #LOOPS THROUGH ENTIRE LIST OF ITEMS IN _HOSTS AND UPDATE BASED ON ANY CHANGES TO JSON ABOVE
    # STAGING
    #env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host
    for i in range(len(stg_dbhosts)):
       update_cassandra_110(_env, _appname, "us-east-1", "10.199.6.215", "10.199.12.186", "10.199.2.42","10.199.2.21","10.199.4.12",'https://nibiru-prod.prsn.us/api/async/instances/'+stg_dbhosts[i])

    # PROD 110 nodes
    #env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host
    #for i in range(len(prd_db_110)):
        #update_cassandra_110(_env, _appname, "us-east-1", "10.198.0.200", "10.198.0.105", "10.198.2.194","10.198.8.58","10.198.4.209",'https://nibiru-prod.prsn.us/api/async/instances/'+prd_db_110[i])

    #PROD 100 nodes
    #env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host
    #for i in range(len(prd_db_100)):
    #    update_cassandra_100(_env, _appname, "us-east-1", "10.198.12.67", "10.198.10.92", "10.198.10.122"," 10.198.12.167","10.198.4.81",'https://nibiru-prod.prsn.us/api/async/instances/'+prd_db_100[i])


    #Standalone update
    #update_cassandra(_env, _appname, "us-east-1", "10.198.0.200", "10.198.0.105", "10.198.2.194","10.198.8.58","10.198.4.209",'https://nibiru-prod.prsn.us/api/async/instances/prd-use1b-pr-42-las-cadb-0009')

