# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# modified by rajao for sanvan core tomcat and cassandra node creation

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def create_tomcat_instance_async(zoneinfo, env, thal_host, appname, version, syncstatus):
    '''Function to create tomcat instance asynchronously'''
    if (env == "prd"):
        env_upper = "PROD"
    if (env == "stg"):
        env_upper = "STG"
    
    print("Zone info and env is" , zoneinfo, env, appname, thal_host, syncstatus)
    if ("qa" in appname or "dev" in env):
        instance_info = {
        "environment": env,
        "app_name": appname,
	    "_links" : {
	    "owner": {
	    "href": teamid_url,
	             },
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "tomcat": {},
                "thalassa::client": {
                      "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  },
                  "storage_type": "remote"
        }

    else:   # for PROD & STAGING ONLY
        instance_info = {
        "environment": env,
        "app_name": appname,
        "_links" : {
        "owner": {
        "href": teamid_url,
            },
                },
            "app_version": version,
        "aws": {
            "size": "m1.xlarge",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "logging::application": {},
                    "appdynamics": {
                        "application_name": "HED_NextGen_"+env_upper+"",
                        "tier_name": "RevelCore_LasJobs"+env_upper+"",
                        "use_tomcat": "true"
                },
                "thalassa::client": {
                    "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                        }
                        }
                        }
                        }
        }

    print("Creating app node instance...")
    try:
        response = nib.under('instances').create(instance_info, async=syncstatus)
        '''while not nib.async_is_ready(response):
            time.sleep(10)'''
        #result = nib.async_get_result(response)
        instance_url = HalResource(response).get_self_link()
        print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


###############################
########   INSTANCES   ########
###############################
# Loop through and create # of nodes specifed with maxnodes and call function to create node for zones needed
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = "9801259f-5e6e-46fa-8e8b-2f5c51f96a72"
    nib = Nibiru(nibiruHost, bearer_token=token);
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/42"
    counter = 1   #counter to keep track of how many times I loop

    # variables that get changed depending on # of nodes, version # and environment
    maxnodes = 1  #number of nodes I want to create per cluster per zone, used to terminate while loop when that value is reached.
    _version = "1.0.0" # instance version tag
    _env = "prd" # prd, stg or dev
    _applas = "lasjobs"

    while True:
        counter +=1
        create_tomcat_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com", _applas,_version, "True")
        create_tomcat_instance_async("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com", _applas,_version, "True")
        if counter > maxnodes:  
             break

    # for PROD & PQA. Dev only needs 1 node per cluster and single zone set maxnodes = 1 there.
    # we have 8 tomcat nodes total now after loop runs twice on each func call, 2 per cluster per app for each zone.
    
    # call func to create bluesky and csg haproxy in each zone, this is not part of while loop..
    # 4 haproxies total for proda nd pqa since dual zone. Only 2 for DEV. 
    #createhaproxy_async("us-east-1b", _env, _appghorn, "True")  # for bstack used lasb, greenhornb for haproxy and casdb
    #createhaproxy_async("us-east-1b", _env, _applas, "True")
    #createhaproxy_async("us-east-1c", _env, "lasb")
    #createhaproxy_async("us-east-1c", _env, "greenhornb")

    #PROD Needed 2 clusters
    #create_cassandra_cluster("use1b", _env, "las", "us-east-1")
    #create_cassandra_cluster("use1c", _env, "las", "us-east-1")

    # for DEV/QA/REV only need single DB
    #create_cassandra_single("stg", _applas, "us-east-1b", "True")
