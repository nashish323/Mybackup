# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# modified by rajao for PXE tomcat and cassandra node creation

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def create_tomcat_instance_async(zoneinfo, env, thal_host, appname, version, syncstatus):
    '''Function to create tomcat instance asynchronously'''
    if (env == "prd"):
       env_upper = "PROD"
    if (env == "stg"):
       env_upper = "STG"
    
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Zone info and env is" , zoneinfo, env, appname, thal_host, version, syncstatus)
    if ("qa" in appname or "dev" in env):
        instance_info = {
        "environment": env,
        "app_name": appname,
        "_links" : {
        "owner": {
        "href": teamid_url,
                 },
           },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "logging::application": {},
                "tomcat": {},
                "thalassa::client": {
                    "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  }
        }

    else:   # for PROD & STAGING ONLY
        instance_info = {
        "environment": env,
        "app_name": appname,
        "_links" : {
        "owner": {
        "href": teamid_url,
                 },
           },
        "app_version": version,
        "aws": {
            "size": "m1.xlarge",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "logging::application": {},
                    "appdynamics": {
                        "application_name": "HED_NextGen_"+env_upper+"",
                        "tier_name": "PXESDK_"+env_upper+"",
                        "use_tomcat": "true"
                },
                "thalassa::client": {
                    "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  }
        }
    print("Creating app node instance...")
    try:
        response = nib.under('instances').create(instance_info, async=syncstatus)
        '''while not nib.async_is_ready(response):
            time.sleep(10)'''
        #result = nib.async_get_result(response)
        instance_url = HalResource(response).get_self_link()
        print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


def createhaproxy_async(zoneinfo, env, appname, syncstatus):
    '''Function to create haproxy'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Parameters" , zoneinfo, env, appname, syncstatus)
    print("env is" , env)

    haproxy_def= {
        "_links": {
        "owner": {
        "href": teamid_url,
                 }
                },
        "environment": env,
        "app_name": appname,
        "privacy": "pub",
        "aws": {
        "zone": zoneinfo
                },
            }

    print("Creating haproxy instance...")
    
    try:
        response = nib.under('applications').under('haproxy').create(haproxy_def, async=syncstatus)
    	instance_url = response['_links']['self']['href']
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        return haproxy_def;


def create_cassandra_cluster(env, _region, appname, syncstatus):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Parameters" , env, appname, syncstatus)
    print("env is" , env)

    cas_info= {
        "_links": {
        "owner": {
        "href": teamid_url,
                 }
                },
        "environment": env,
        "app_name": appname,
        "app_type": "cadb",
         "puppet": {
                    "classes": {
                        "cassandra": {
                             "cluster_name": appname,
                             "version": "2.0.5"
                            }
                        }
                    },
        "aws": {
            "size": "m1.xlarge",
            "region": _region  # - will do multiregion if not specified
                },
        "storage_type": "local"
                }
    print("Data to send...", cas_info)
    print("Creating cassandra instance...")
    
    try:
        response = nib.under('applications').under('cassandra').create(cas_info, async=syncstatus)
        instance_url = response['_links']['self']['href']  # try this instead
        print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        
    return cas_info;


def create_cassandra_single(env, appname, zoneinfo, syncstatus):
    '''Function to create cassandra node''' #create_basic_elasticsearch_cluster(_env, _appname, "us-east-1", "True")
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("env, appname & region is" , env, appname, zoneinfo, syncstatus)

    cas_info={ "_links" : {
        "owner": {
            "href": teamid_url,
            }
        },
        "app_name": appname,
        "app_type": "cadb",
               "aws": {
                   "size": "m1.xlarge",
                   "zone": zoneinfo    #"us-east-1b"
                   },
               "environment": env,
               "privacy": "priv",
               "puppet":
                   {
                       "classes":
                       {
                           "cassandra":
                           {
                                "cluster_name": appname,
                                "version": "2.0.5"
                               }
                           }
                       },
               "storage_type": "local"
               }

    print("Data to send...", cas_info)
    print("Creating single cassandra instance...")
    
    try:
        response = nib.under('instances').create(cas_info, async=syncstatus)
        instance_url = response['_links']['self']['href']  # try this instead
        print("Instance URL is ", instance_url)

    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return cas_info;


###############################
########   INSTANCES   ########
###############################
# Loop through and create # of nodes specifed with maxnodes and call function to create node for zones needed
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':
    nodecounter = 1   #counter to keep track of how many times I loop

    # variables that get changed depending on # of nodes, version # and environment
    maxnodes = 1  #number of nodes I want to create per cluster per zone, used to terminate while loop when that value is reached.
    _version = "1.1.0" # instance version tag
    _env = "dev" # prd, stg or dev
    _appname = "sdk"
    hapybname = "sdkb"
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/53"
    teamtoken = "acd67a0a-c5bb-49b0-a312-dfd05f011a12"

    # for PROD & PQA. Dev only needs 1 node per cluster and single zone set maxnodes = 1 there.
    # we have 4 tomcat nodes total now after loop runs twice on each func call, 2 per cluster per app for each zone.
    while True:
        nodecounter += 1
        create_tomcat_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com",_appname,_version, "True")
        #create_tomcat_instance_async("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com",_appname,_version, "True")
        if nodecounter > maxnodes:
            break

    # Provision CAS DB cluster nodes
    create_cassandra_cluster(_env, "us-east-1", _appname, "True")
    
    # call func to create sdk haproxy in each zone, this is not part of while loop....
    # 2 haproxies total for proda nd pqa since dual zone. Only 1 for DEV.
    #create_cassandra_single(_env, _appname, "us-east-1b", "True")
    # Main HAPROXIES for STACK A
    # createhaproxy_async("us-east-1b", _env, _appname, "True")
    # createhaproxy_async("us-east-1c", _env, _appname, "True")

    # HAPROXY for the STACK B Proxies
    #createhaproxy_async("us-east-1b", _env, _appname, "True")
    #createhaproxy_async("us-east-1c", _env, hapybname, "True")



