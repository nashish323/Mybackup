# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# use for seeding cassandra nodes once the nodes have been created

# UPDATE TEAM ID & TOKEN

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def update_cassandra(env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Input is ", env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host)

    cas_info= {
        "_links": {
        "owner": {
        "href": teamid_url
                 }
                },
        "environment": env,
        "app_name": appname,
        "app_type": "cadb",
         "puppet": {
         "classes": {
                "cassandra": {
                    "cluster_name": "sdk",
                    "version": "2.0.5",
                    "endpoint_snitch": "Ec2Snitch",
                    "rpc_address": "0.0.0.0",
                    "seeds": [
                        seedip1,
                        seedip2,
                        seedip3,
                        seedip4,
                        seedip5
                            ]
                        }
                    }
                },
        "aws": {
            "size": "m1.xlarge",
            "region": _region      #us-east-1
                },
        "storage_type": "local"
                }

    print("Data to send...", cas_info)
    print("Updating cassandra instance with seeds...")

    try:
        response = nib.under('applications').under('cassandra').update(casdb_host, cas_info)
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)

    except NibiruError as err:
        print("There was an error deploying the node! ", err)

    return cas_info;


###############################
########   INSTANCES   ########
###############################
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':

    #UPDATE THIS SECTION FIRST
    _appname = "sdk"
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/53"
    teamtoken = "acd67a0a-c5bb-49b0-a312-dfd05f011a12" # pxe sdk
    _env = "stg" # prd, stg or dev
    #NEW SERVER - 10.199.10.142 stg-use1b-pr-55-dragon-cadb-0004
    #  replacing stg-use1b-pr-55-dragon-cadb-0002 - 10.199.0.208
    stg_dbhosts = ["stg-use1b-pr-53-sdk-cadb-0005","stg-use1b-pr-53-sdk-cadb-0006","stg-use1c-pr-53-sdk-cadb-0004","stg-use1c-pr-53-sdk-cadb-0005",
    "stg-use1d-pr-53-sdk-cadb-0006"]
    prd_dbhosts = ["prd-use1b-pr-53-sdk-cadb-0003","prd-use1b-pr-53-sdk-cadb-0004","prd-use1c-pr-53-sdk-cadb-0003","prd-use1c-pr-53-sdk-cadb-0004",
    "prd-use1d-pr-53-sdk-cadb-0002"]
    ###### end of environment specific vars#########

    #LOOPS THROUGH ENTIRE LIST OF ITEMS IN _HOSTS AND UPDATE BASED ON ANY CHANGES TO JSON ABOVE
    # STAGING
    #env, appname, _region, seedip1, seedip2, seedip3, seedip4, seedip5, casdb_host
    # for i in range(len(stg_dbhosts)):
    #    update_cassandra(_env, _appname, "us-east-1", "10.199.0.42", "10.199.0.141","10.199.2.223","10.199.2.207", "10.199.4.161",
    #     'https://nibiru-prod.prsn.us/api/async/instances/'+stg_dbhosts[i])

    for i in range(len(prd_dbhosts)):
       update_cassandra(_env, _appname, "us-east-1", "10.198.0.86", "10.198.0.199","10.198.2.60","10.198.2.90", "10.198.4.43",
        'https://nibiru-prod.prsn.us/api/async/instances/'+prd_dbhosts[i])
    #Standalone update

