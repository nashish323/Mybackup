# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'puppetmaster' do
  it 'should do something'
end
