
blogs=( "use1a-pub-haproxy-blogs-01.asskickery.us" "use1c-pub-haproxy-blogs-01.asskickery.us" )
follows=( "use1a-pub-haproxy-follows-01.asskickery.us" "use1c-pub-haproxy-follows-01.asskickery.us" )
persona=( "use1a-pub-haproxy-persona-01.asskickery.us" "use1c-pub-haproxy-persona-01.asskickery.us" )
presence=( "use1a-pub-haproxy-presence-01.asskickery.us" "use1c-pub-haproxy-presence-01.asskickery.us" )
share=( "use1a-pub-haproxy-share-01.asskickery.us" "use1c-pub-haproxy-share-01.asskickery.us" )
socialagent=( "use1a-pub-haproxy-socialagent-01.asskickery.us" "use1c-pub-haproxy-socialagent-01.asskickery.us" )
streams=( "use1a-pub-haproxy-streams-01.asskickery.us" "use1c-pub-haproxy-streams-01.asskickery.us" )
uidelegate=( "use1a-pub-haproxy-uidelegate-01.asskickery.us" "use1c-pub-haproxy-uidelegate-01.asskickery.us" )

for server in ${blogs[*]}
do
	curl -v -X PUT -d '{ "type": "spindrift", "role":"blogs", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/blogs
	curl -v -X PUT -d '{ "type": "spindrift", "role":"uidelegate", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/uidelegate
	curl -v -X PUT -d '{ "type": "spindrift", "role":"follows", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/follows
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "blogs", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"},{ "type":"path","operation":"path_beg","value":"/network/","backend":"follows"},{ "type":"path","operation":"path_beg","value":"/delegate/","backend":"uidelegate"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/blogs
done

for server in ${follows[*]}
do
	curl -v -X PUT -d '{ "type": "spindrift", "role":"follows", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/follows
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "follows", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/follows
done

for server in ${persona[*]}
do
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "type": "spindrift", "role":"village", "version":"0.3.0", "natives": ["reqirep ^([^\\ ]*)\\ /Affinity/v1/avatar/([^/]+)/avatar/thumbnail(.*)  \\1\\ /Affinity/v1/avatar/\\2/thumbnail\\3"]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/persona
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "persona", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/persona
done

for server in ${presence[*]}
do
	curl -v -X PUT -d '{ "type": "spindrift", "role":"presence", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/presence
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "presence", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/presence
done

for server in ${share[*]}
do
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "type": "spindrift", "role":"share", "version":"1.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/share
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "share", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/share
done

for server in ${socialagent[*]}
do
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "type": "spindrift", "role":"socialagent", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/socialagent
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "socialagent", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/socialagent
done

for server in ${streams[*]}
do
	curl -v -X PUT -d '{ "type": "spindrift", "role":"streams", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/streams
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "streams", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/streams
done

for server in ${uidelegate[*]}
do
	curl -v -X PUT -d '{ "type": "spindrift", "role":"uidelegate", "version":"0.1.0"}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/uidelegate
	curl -v -X PUT -d '{ "type":"static", "host": "static.ecollege.com", "members":[{"host":"static.ecollege.com","port":80}]}' -H "Content-Type: application/json"  http://${server}:10000/api/backend/ecxd
	curl -v -X PUT -d '{ "bind":"*:80,*:8080", "backend": "uidelegate", "rules":[{ "type":"path","operation":"path_beg","value":"/ecxd/","backend":"ecxd"}] }' -H "Content-Type: application/json"  http://${server}:10000/api/frontend/uidelegate
done
