Before do
  # adjust local configuration like this
  @puppetcfg['confdir']  = '/etc/puppet'
  @puppetcfg['manifest'] = '/etc/puppet/manifests/site.pp'
  @puppetcfg['modulepath']  = '/etc/puppet/modules'

  # adjust facts like this
  @facts['architecture'] = "x86_64"
  @facts['domain'] = "arch.ecollege.com"
  @facts['environment'] = "production"
  @facts['hostname'] = "devops.arch.ecollege.com"
end
