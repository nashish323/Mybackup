Then /^the file named "([^"]*)" should exist$/ do |arg1|
  steps %Q{
	  Then there should be a resource "File[#{arg1}]"
  }
end

Then /^the exec named "([^"]*)" should run$/ do |arg1|
	steps %Q{
		Then there should be a resource "Exec[#{arg1}]"
	}
end
