#!/bin/sh

curl -i -H 'Content-Type: application/json' -d '{"role":"blogs","version":"2.0.0"}' http://10.252.1.69:10000/api/backend/blogs
curl -i -H 'Content-Type: application/json' -d '{"role":"follows","version":"2.0.0"}' http://10.252.1.69:10000/api/backend/follows
curl -i -H 'Content-Type: application/json' -d '{"role":"uidelegate","version":"2.0.0"}' http://10.252.1.69:10000/api/backend/uidelegate
curl -i -H 'Content-Type: application/json' -d '{"role":"follows","version":"2.0.0"}' http://10.252.1.39:10000/api/backend/follows
curl -i -H 'Content-Type: application/json' -d '{"role":"share","version":"2.0.0"}' http://10.252.1.156:10000/api/backend/share
curl -i -H 'Content-Type: application/json' -d '{"role":"socialagent","version":"2.0.0"}' http://10.252.1.9:10000/api/backend/socialagent
curl -i -H 'Content-Type: application/json' -d '{"role":"streams","version":"2.0.0"}' http://10.252.1.8:10000/api/backend/streams
curl -i -H 'Content-Type: application/json' -d '{"role":"uidelegate","version":"2.0.0"}' http://10.252.1.213:10000/api/backend/uidelegate