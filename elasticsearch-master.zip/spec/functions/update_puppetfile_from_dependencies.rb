require 'yaml'
require 'r10k/puppetfile'
require 'git'

module Puppetfile_Dependencies
  config = YAML.load_file('dependencies.yml')
  repopath = config['config']['puppetfile_repo']
  @@branch = config['config']['branch'] || nil
  branch_re = config['config']['branch_re'] || "v([0-9]+\.?[0-9]?)"
  branch_re = Regexp.new branch_re
  repodir = '.puppetfile'

  begin
    repo = Git.clone(repopath,repodir)
    puts "Loaded Puppetfile repository from #{repopath}"
  rescue
    repo = Git.open(repodir)
    repo.fetch
    repo.pull
  end

  local_branches=repo.branches.local

  branches=repo.branches.remote
  # If it's found, this will change it to the actual branch
  # If it's not found, it'll be nil
  @@branch = branches.find{ |i| i.name==@@branch}

  if(@@branch == nil) then
    branches = branches.select{ |i| i.name[branch_re] }
    highest_dev_branch=branches.max_by{|k,v| k.name.gsub(branch_re,'\1').to_f}
    @@branch = highest_dev_branch
  end
  if(@@branch == nil) then
    puts "Unable to find requested Puppetfile branch, or apply the regex."
    exit
  end
  puts "Using Puppetfile #{@@branch.name}"
  local_copy=local_branches.find{|i| i.name==@@branch.name}
  master_copy=local_branches.find{|i| i.name=='master'}
  if(local_copy) then
    puts "Found local branch [#{@@branch.name}]"
    master_copy.checkout()
    puts "Deleting local branch [#{@@branch.name}] so that it can be re-checked out"
    local_copy.delete()
  end

  puts "Checking out remote [#{@@branch.name}]"
  repo.checkout(@@branch)

  def self.get_branchname
    @@branch
  end
end