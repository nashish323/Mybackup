require_relative '../spec_helper'

describe 'elasticsearch::zabbix' do

	it { should contain_package('pyes') }
	it { should contain_zabbix__agent__script('elasticsearch.py') }
	it { should contain_zabbix__agent__userparam('elasticsearch.conf') }

end

