require_relative '../spec_helper'

describe 'elasticsearch::nibiru' do

  context "On Ubuntu OS" do

    let :facts do {
      :operatingsystem => 'Ubuntu',
      :nibiru_environment => 'test',
    } end

    context "With params" do

      let :params do {
        :config => { 'node' => { 'name' => 'test' }  },
        :curator => true,
        :curator_cronjob => {
         'delete_indexes'=> {
           'command'=> '--host localhost -d 90',
           'hour'=> '*'
         },
         'optimize_indexes'=> {
           'command'=> '-t 3600 -o 2 --max_num_segments 1',
           'hour'=> '*',
           'minute'=> '30'
          }
        },
        :datadir => '/data'
      } end

      it { should create_group('elasticsearch').with(:ensure => 'present') }

      it do
        should create_user('elasticsearch').with(
          :ensure => 'present',
          :comment => 'elasticsearch user',
          :password => '!!',
          :shell => '/bin/bash',
          :home => '/home/appuser'
        )
      end

      it { should create_exec('es-base-data-dir').with(:command => '/bin/mkdir -p /data') }

      it do
        should create_file('/data/elasticsearch').with(
          :ensure => 'directory',
          :owner => 'elasticsearch',
          :group => 'elasticsearch'
        )
      end

      it do
        should create_class('elasticsearch').with(
          :ensure => 'present',
          :config => {
            'node'               => {
              'name'             => 'test'
            },
            'cloud'              => {
              'aws'              => {
                'access_key'     => 'AKIAI6QFSDT7PYW4FJWA',
                'secret_key'     => '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'
              }
            },
            'discovery'          => {
              'type'             => 'ec2',
              'ec2'              => {
                'tag'            => {
                  'app_name'     => '',
                  'environment'  => 'test'
                }
              }
            },
            'index'              => {
              'number_of_replicas' => '1',
              'number_of_shards' => '5',
              'translog'           => {
                'flush_threshold_ops' => '50000'
              }
            },
            'indices'                 => {
              'memory'                => {
                'index_buffer_size'   => '50%'
              }
            },
            'path'               => {
              'data'             => '/data/elasticsearch'
            }
          },
          :autoupgrade => false,
          :status => 'enabled',
          :restart_on_change => true,
          :confdir => '/etc/elasticsearch',
          :plugindir => '/usr/share/elasticsearch/plugins',
          :plugintool => '/usr/share/elasticsearch/bin/plugin',
          :plugins => {
            'lukas-vlcek/bigdesk' => { 'module_dir' => 'bigdesk'},
            'mobz/elasticsearch-head' => { 'module_dir' => 'head'},
            'royrusso/elasticsearch-HQ' => { 'module_dir' => 'HQ'},
            'karmi/elasticsearch-paramedic' => { 'module_dir' => 'paramedic'},
          },
          :service_settings => {
            'ES_USER'      => 'elasticsearch',
            'ES_GROUP'     => 'elasticsearch',
            'ES_HEAP_SIZE' => '0k'
          },
          :version => '1.1.0',
          :java_install => true
        )
      end
      
      it { should create_class('elasticsearch::plugins::cloud-aws') }

      it { should create_class('elasticsearch::curator::install') }

      it do
        should create_elasticsearch__curator__cronjob('delete_indexes').with(
          :command => '--host localhost -d 90',
          :hour => '*',
          :minute => '0',
          :month => '*',
          :monthday => '*',
          :user => 'root',
          :weekday => '*'
        )
      end

      it do
        should create_cron('elasticsearch-curator-delete_indexes').with(
          :ensure => 'present',
          :command => '/usr/local/bin/curator --host localhost -d 90',
          :hour => '*',
          :minute => '0',
          :month => '*',
          :monthday => '*',
          :user => 'root',
          :weekday => '*'
        )
      end

      it do
        should create_elasticsearch__curator__cronjob('optimize_indexes').with(
          :command => '-t 3600 -o 2 --max_num_segments 1',
          :hour => '*',
          :minute => '30',
          :month => '*',
          :monthday => '*',
          :user => 'root',
          :weekday => '*'
        )
      end

      it do
        should create_cron('elasticsearch-curator-optimize_indexes').with(
          :ensure => 'present',
          :command => '/usr/local/bin/curator -t 3600 -o 2 --max_num_segments 1',
          :hour => '*',
          :minute => '30',
          :month => '*',
          :monthday => '*',
          :user => 'root',
          :weekday => '*'
        )
      end

    end

  end

end