# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# modified by rajao for bluesky/csg core tomcat and plain java nodes for mysqlDB install later

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def create_tomcat_instance(zoneinfo, env, thal_host, appname, version):	
    '''Function to create tomcat instance'''    

    print("Zone info and env is" , zoneinfo, env)
    instance_info = {
        "environment": env,
        "app_name": appname,
	"_links" : {
	    "owner": {
	     "href": "https://nibiru-prod.prsn.us/api/teams/40",
	             },
	    "network": {
	      "href": 'https://nibiru-prod.prsn.us/api/networks/aws-'+env+'-'+zoneinfo+'-priv'
   			},
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium"
        },
        "puppet": {
            "classes": {
                "tomcat": {},
                "thalassa::client": {
                      "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  },
	"storage_type": "remote"
        }
    print("Creating app node instance...")
    print("Data to send...", instance_info)
    try:
        response = nib.under('instances').create(instance_info)
        #use below to update existing instances only
        #response = nib.under('instances').update("https://nibiru-prod.prsn.us/api/instances/stg-use1c-pr-40-bluesky-01x01x00-0001",instance_info)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


def create_tomcat_instance_async(zoneinfo, env, thal_host, appname, version):
    '''Function to create tomcat instance asynchronously'''
        
    print("Zone info, env and appname is" , zoneinfo, env, appname, version)
    instance_info = {
        "environment": env,
        "app_name": appname,
	"_links" : {
	    "owner": {
	      "href": "https://nibiru-prod.prsn.us/api/teams/40",
	             },
	    "network": {
	      "href": 'https://nibiru-prod.prsn.us/api/networks/aws-'+env+'-'+zoneinfo+'-priv'
		       },
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium"
        },
        "puppet": {
            "classes": {
                "tomcat": {},
                "thalassa::client": {
                      "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  },
	"storage_type": "remote"
        }    

    print("Creating app node instance...")
    #print("Data to send...", instance_info)
    try:
        response = nib.under('instances').create(instance_info, async=True)
        '''while not nib.async_is_ready(response):
            time.sleep(10)'''
        #result = nib.async_get_result(response)
        #print("result is..", result)
        #print('Actually going to update instances....')
        #use below to update existing instances open                                        
        #response = nib.under('instances').update("https://nibiru-prod.prsn.us/api/instances/stg-use1c-pr-40-las-01x00x00-0002",instance_info)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


    try:
        response = nib.under('instances').create(instance_info, async=True)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


def createhaproxy(zoneinfo, env, appname):
    '''Function to create haproxy'''

    print("Zone info is" , zoneinfo)
    print("env is" , env)

    haproxy_def= {
        "_links": {
        "owner": {
          "href": "https://nibiru-prod.prsn.us/api/teams/40",
                 },
	"network": {
          "href": 'https://nibiru-prod.prsn.us/api/networks/aws-'+env+'-'+zoneinfo+'-pub'
		   },
                },
        "environment": env,
        "app_name": appname,
        "privacy": "pub",
        "aws": {
               },
            }

    print("Creating haproxy instance...")
    
    try:
        response = nib.under('applications').under('haproxy').create(haproxy_def)
    	#instance_url = HalResource(response).get_self_link() # not working
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        return haproxy_def;


def createhaproxy_async(zoneinfo, env, appname):
    '''Function to create haproxy'''

    print("Zone info is" , zoneinfo)
    print("env is" , env)

    haproxy_def= {
        "_links": {
        "owner": {
           "href": "https://nibiru-prod.prsn.us/api/teams/40",
                 },
	"network": {
	   "href": 'https://nibiru-prod.prsn.us/api/networks/aws-'+env+'-'+zoneinfo+'-pub'
		   },
                },
        "environment": env,
        "app_name": appname,
        "privacy": "pub",
        "aws": {
                },
            }

    print("Creating haproxy instance...")
    
    try:
        response = nib.under('applications').under('haproxy').create(haproxy_def, async=True)
    	instance_url = response['_links']['self']['href']
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        return haproxy_def;

    
###############################
########   INSTANCES   ########
###############################
# Loop through and create # of nodes specifed with maxnodes and call function to create node for zones needed
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = "24b621ff-9d3a-4012-873d-fe40506f2182"
    nib = Nibiru(nibiruHost, bearer_token=token);
    counter = 1   #counter to keep track of how many times I loop

    # variables that get changed depending on # of nodes, version # and environment
    maxnodes = 2  #number of nodes I want to create per cluster per zone, used to terminate while loop when that value is reached.
    _version = "1.0.0" # instance version tag
    _env = "stg" # prd, stg or dev

    while True:
        counter +=1
        create_tomcat_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com","blueskypqa", _version)
        create_tomcat_instance_async("us-east-1d", _env, _env+"-use1d-thalassa.prv-openclass.com","blueskypqa", _version)
        create_tomcat_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com","csgpqa",_version)
        create_tomcat_instance_async("us-east-1d", _env, _env+"-use1d-thalassa.prv-openclass.com","csgpqa",_version)  
        #create_tomcat_instance("bogus-zone", "stg", "bogus-thalassa","csg","1.0.0") # for testing error return...
        if counter > maxnodes:  
             break

    # for PROD & PQA. Dev only needs 1 node per cluster and single zone set maxnodes = 1 there.
    # we have 8 tomcat nodes total now after loop runs twice on each func call, 2 per cluster per app for each zone.
    
    # call func to create bluesky and csg haproxy in each zone, this is not part of while loop..
    # 4 haproxies total for proda nd pqa since dual zone. Only 2 for DEV. 
#createhaproxy_async("us-east-1b", _env, "blueskypqa")  # for bstack use blueskyb, csgb for haproxy & elb
#createhaproxy_async("us-east-1d", _env, "blueskypqa")
#createhaproxy_async("us-east-1b", _env, "csgpqa") 
#createhaproxy_async("us-east-1d", _env, "csgpqa")
##create_basic_instance_async("us-east-1b", _env, "csgdb", _version)
##create_basic_instance_async("us-east-1c", _env, "csgdb", _version)
