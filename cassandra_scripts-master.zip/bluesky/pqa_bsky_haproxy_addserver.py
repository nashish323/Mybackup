round #!bin/env python
# If you don't already have the requests module installed, install it using:
# pip install requests
# pip install argparse
# rajao 1/29/2014 - This script is to register BE servers to the Bluesky and cutover stacks
# NOTE can be run standlaone with the nibiru imports anywhere
from time import sleep
import logging
import time
import requests
import argparse
import json

def register_backends_with_natives(host, app_name, the_version):
    '''register backend services to haproxy'''
		    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": [],
                "natives": ["option http-server-close", "option forwardfor"]
        }
    print("Configuring Haproxy frontend for", host)
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
                "natives": ["appsession JSESSIONID len 250 timeout 3h request-learn"]
    }
    
    print haproxy_backend
    print("Registering backends to HAProxy for", host)
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

def register_backends(host, app_name, the_version):
    '''register backend services to haproxy'''
		    
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": []
        }
    print("Configuring Haproxy frontend for", host)
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()
    
    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version
                }
    
    print haproxy_backend
    print("Registering backends to HAProxy for", host)
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

# When cutting over stack the currentver and priorver are the only ones that need to be switched out.
# As of 4/25 release tags on live version is 1.1.0
if __name__ == '__main__':
    currentver = "1.0.0"

    haproxyStackA_bsky_zoneb = 'stg-use1b-pu-40-blueskypqa-hapy-0001'
    haproxyStackA_csg_zoneb = 'stg-use1b-pu-40-csgpqa-hapy-0001'
    haproxyStackA_bsky_zoned = 'stg-use1d-pu-40-blueskypqa-hapy-0001'
    haproxyStackA_csg_zoned = 'stg-use1d-pu-40-csgpqa-hapy-0001'
    
    # Registering main zone A nodes
    register_backends_with_natives(haproxyStackA_bsky_zoneb+'.prv-openclass.com','blueskypqa',currentver)
    register_backends_with_natives(haproxyStackA_bsky_zoned+'.prv-openclass.com','blueskypqa',currentver)
    register_backends(haproxyStackA_csg_zoneb+'.prv-openclass.com','csgpqa',currentver)
    register_backends(haproxyStackA_csg_zoned+'.prv-openclass.com','csgpqa',currentver)
