# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 02/03/2014
# modified by rajao for svbrix plain java nodes for redis & nodejs install later

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

#TODO - ADD seperate function for instance update or use same function with extra action string and conditional statement

# NOTE did not incliude node puppet module because brix wanted latest node version so we installed manually after provisioning
def create_appnode(zoneinfo, env, thal_host, appname, version, asyncStatus):
    '''Function to create tomcat instance asynchronously'''
    ## TODO: Later maybe have seperate scripts for brix vs ips as well as haproxy config & elb script
        
    print("Zone info, env and appname is" , zoneinfo, env, appname, version, thal_host, asyncStatus)
    #if ("qa" in appname or "dev" in env):
    #    awssize="m1.medium"
    #if ("brixce" in appname and env == "stg" or env =="prd")
    #    awssize="c3.xlarge"
    #if ("ips" in appname and env == "stg" or env =="prd")
    #    awssize="c3.xlarge"

    instance_info = {
        "environment": env,
        "app_name": appname,
	"_links" : {
	    "owner": {
	    "href": "https://nibiru-prod.prsn.us/api/teams/11",
	             },
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
		        "nodejs":{},  # note this will install default version available on nibiru
                "java": {},
                "thalassa::client": {
                      "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  },
                  "storage_type": "remote"
        }    

    print("Creating app node instance...")
    #print("Data to send....", instance_info)
    try:
        response = nib.under('instances').create(instance_info, async=asyncStatus)
        '''while not nib.async_is_ready(response):
            time.sleep(10)'''
        #result = nib.async_get_result(response)
        #print("result is..", result)                                      
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


def create_redis_instance(zoneinfo, env, appname, version, asyncStatus):
    '''Function to create plain java instance asynchronously'''
    print("Zone info, env and appname is" , zoneinfo, env, appname, version, asyncStatus)
        
    instance_info = {
        "environment": env,
        "app_name": appname,
	"_links" : {
	    "owner": {
	    "href": "https://nibiru-prod.prsn.us/api/teams/11",
	             },
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "redis": {
                    "conf_bind": "0.0.0.0"
                },
                       }
                  },
                  "storage_type": "remote"
        }    

    print("Creating redis node instance...")
    #print("Data to send...", instance_info)
    try:
        response = nib.under('instances').create(instance_info, async=asyncStatus)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;

def create_mongo_instance(zoneinfo, env, appname, version, asyncStatus):
    '''Function to create mongo instance asynchronously'''
    print("Zone info, env and appname is" , zoneinfo, env, appname, version, asyncStatus)
        
    instance_info = {
        "environment": env,
        "app_name": appname,
	"_links" : {
	    "owner": {
	    "href": "https://nibiru-prod.prsn.us/api/teams/11",
	             },
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "java": {},
                "mongodb": {},
                       }
                  },
                  "storage_type": "remote"
        }    

    print("Creating mongo app node instance...")
    #print("Data to send...", instance_info)
    try:
        response = nib.under('instances').create(instance_info, async=asyncStatus)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;



def createhaproxy(zoneinfo, env, appname, asyncStatus):
    '''Function to create haproxy'''

    print("Zone, env and appname is" , zoneinfo, env, appname, asyncStatus)
    haproxy_def= {
        "_links": {
        "owner": {
        "href": "https://nibiru-prod.prsn.us/api/teams/11",
                 }
                },
        "environment": env,
        "app_name": appname,
        "privacy": "pub",
        "aws": {
        "zone": zoneinfo
                },
            }

    print("Creating haproxy instance...")
    
    try:
        response = nib.under('applications').under('haproxy').create(haproxy_def, async=asyncStatus)
    	instance_url = response['_links']['self']['href']
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        return haproxy_def; 

    
################################
########   INSTANCES   ########
################################
# Loop through and create # of nodes specifed with maxnodes and call function to create node for zones needed
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':
    token = "849dadd1-66af-406d-ad20-b66b4569121c"
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);
    counter = 1   #counter to keep track of how many times I loop


    # variables that get changed depending on # of nodes, version # and environment
    maxnodes = 2  #number of nodes I want to create per cluster per zone, used to terminate while loop when that value is reached.
    _version = "1.1.0" # instance version tag
    _env = "stg" # prd, stg or dev
    appname = "qabrixce" #brixce, ips

##TODO Add conditional statement depending on env, DEV, QA vs. STG & PROD

    while True:
        counter +=1
	#create_appnode("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com",appname, _version, "True")
	#create_appnode("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com",appname, _version, "True")
    #create_appnode("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com",appname, _version, "True")
    #create_appnode("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com",appname, _version, "True")
        if counter > maxnodes:  
             break

    # for PROD & PQA. Dev only needs 1 node per cluster and single zone set maxnodes = 1 there.
    # we have 8 tomcat nodes total now after loop runs twice on each func call, 2 per cluster per app for each zone.
    
    # call func to create bhaproxy in each zone, this is not part of while loop....
    # 4 haproxies total for proda nd pqa since dual zone. Only 2 for DEV..
    
##  create_redis_instance("us-east-1b", _env, "redis", _version, "True")
##  create_mongo_instance("us-east-1b", _env, appname, _version, "True")
    
    createhaproxy("us-east-1b", _env, appname, "True") 
    createhaproxy("us-east-1c", _env, appname, "True")  


