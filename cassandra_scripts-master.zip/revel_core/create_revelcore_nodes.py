# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# modified by rajao for sanvan core tomcat and cassandra node creation

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)

def create_tomcat_instance_async(zoneinfo, env, thal_host, appname, version, syncstatus):
    '''Function to create tomcat instance asynchronously'''
    
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Zone info and env is" , zoneinfo, env, appname, thal_host, syncstatus)
    #TODO LATER WHEN USING APPD PUPPET MODULE REPLACE BLOCK WITH PXESDK TYPE CODE
    if ("qa" in appname or "dev" in env):
        awssize="m1.medium"
    if ("las" in appname and env == "stg" or env =="prd")
        awssize="c3.4xlarge"


        instance_info = {
        "environment": env,
        "app_name": appname,
	   "_links" : {
	    "owner": {
	    "href": teamid_url,
	             },
		   },
        "app_version": version,
        "aws": {
            "size": awssize,
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "tomcat": {},
                "thalassa::client": {
                      "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  },
                  "storage_type": "remote"
        }    

    print("Creating app node instance...")
    #print("Data to send...", instance_info)
    try:
        response = nib.under('instances').create(instance_info, async=syncstatus)
        '''while not nib.async_is_ready(response):
            time.sleep(10)'''
        #result = nib.async_get_result(response)
        #print("result is..", result)
        #print('Actually going to update instances....')
        #use below to update existing instances open                                        
        #response = nib.under('instances').update("https://nibiru-prod.prsn.us/api/instances/dev-use1b-pr-42-las-01x00x00-0005",instance_info)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;

def create_nginx_instance_async(zoneinfo, env, thal_host, appname, version, syncstatus):
    '''Function to create tomcat instance asynchronously'''

    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Zone info and env is" , zoneinfo, env, appname, thal_host, syncstatus)
    instance_info = {
        "environment": env,
        "app_name": appname,
	"_links" : {
	    "owner": {
	    "href": teamid_url,
	             },
		   },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "java": {},
                "nginx": {},
                "thalassa::client": {
                      "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  },
                  "storage_type": "remote"
        }

    print("Creating app node instance...")
    #print("Data to send...", instance_info)
    try:
        response = nib.under('instances').create(instance_info, async=syncstatus)
        '''while not nib.async_is_ready(response):
            time.sleep(10)'''
        #result = nib.async_get_result(response)
        #print("result is..", result)
        #print('Actually going to update instances....')
        #use below to update existing instances open
        #response = nib.under('instances').update("https://nibiru-prod.prsn.us/api/instances/dev-use1b-pr-42-las-01x00x00-0005",instance_info)
	instance_url = HalResource(response).get_self_link()
	print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;


def createhaproxy_async(zoneinfo, env, appname, syncstatus):
    '''Function to create haproxy'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Parameters" , zoneinfo, env, appname, syncstatus)
    print("env is" , env)

    haproxy_def= {
        "_links": {
        "owner": {
        "href": teamidurl,
                 }
                },
        "environment": env,
        "app_name": appname,
        "privacy": "pub",
        "aws": {
        "zone": zoneinfo
                },
            }

    print("Creating haproxy instance...")
    
    try:
        response = nib.under('applications').under('haproxy').create(haproxy_def, async=syncstatus)
    	instance_url = response['_links']['self']['href']
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        return haproxy_def;


def create_cassandra_cluster(env, _region, appname, syncstatus):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);

    print("Parameters" , env, appname, syncstatus)
    print("env is" , env)

    cas_info= {
        "_links": {
        "owner": {
        "href": teamid_url,
                 }
                },
        "environment": env,
        "app_name": appname,
        "app_type": "cadb",
         "puppet": {
                    "classes": {
                        "cassandra": {
                             "cluster_name": appname,
                             "version": "2.0.5"
                            }
                        }
                    },
        "aws": {
            "size": "m1.xlarge",
            "region": _region  # - will do multiregion if not specified
                },
        "storage_type": "local"
                }
    print("Data to send...", cas_info)
    print("Creating cassandra instance...")
    
    try:
        response = nib.under('applications').under('cassandra').create(cas_info, async=syncstatus)
        instance_url = response['_links']['self']['href']  # try this instead
        print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        
    return cas_info;


def create_cassandra_single(env, appname, zoneinfo, syncstatus):
    '''Function to create cassandra node'''
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    nib = Nibiru(nibiruHost, bearer_token=teamtoken);
    
    print(nib)

    print("env, appname & region is" , env, appname, zoneinfo, syncstatus)

    cas_info={ "_links" : {
        "owner": {
            "href": teamid_url,
            }
        },
        "app_name": appname,
        "app_type": "cadb",
               "aws": {
                   "size": "m1.xlarge",
                   "zone": zoneinfo    #"us-east-1b"
                   },
               "environment": env,
               "privacy": "priv",
               "puppet":
                   {
                       "classes":
                       {
                           "cassandra":
                           {
                               "cluster_name": appname
                               }
                           }
                       },
               "storage_type": "local"
               }

    print("Data to send...", cas_info)
    print("Creating single cassandra instance...")
    
    try:
        response = nib.under('instances').create(cas_info, async=syncstatus)
    	instance_url = response['_links']['self']['href']  # try this instead
    	print("Instance URL is ", instance_url)
    
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
        
    return cas_info;



###############################
########   INSTANCES   ########
###############################
# Loop through and create # of nodes specifed with maxnodes and call function to create node for zones needed
# envs = dev, stg, prod | zones = (us-east-1b, us-east-1c, us-west-1a, us-west-1b) dev is only us-east
if __name__ == '__main__':
    counter = 1   #counter to keep track of how many times I loop

    # variables that get changed depending on # of nodes, version # and environment
    maxnodes = 1  #number of nodes I want to create per cluster per zone, used to terminate while loop when that value is reached.
    _version = "1.0.0" # instance version tag
    _env = "stg" # prd, stg or dev
    _appghorn = "qaghorn"
    _applas = "qalas"
    teamtoken = "9801259f-5e6e-46fa-8e8b-2f5c51f96a72"
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/42"

    while True:
        counter +=1
        create_nginx_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com", _appghorn,_version, "True")
        create_tomcat_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com", _applas,_version, "True")

        '''create_tomcat_instance_async("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com","greenhorn",_version)
        create_tomcat_instance_async("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com","las",_version)
        create_tomcat_instance_async("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com","greenhorn",_version)
        #create_tomcat_instance("bogus-zone", "stg", "bogus-thalassa","csg","1.0.0") # for testing error return.'''
        if counter > maxnodes:  
             break

    # for PROD & PQA. Dev only needs 1 node per cluster and single zone set maxnodes = 1 there.
    # we have 8 tomcat nodes total now after loop runs twice on each func call, 2 per cluster per app for each zone.
    
    # call func to create las and greenhorn haproxy in each zone, this is not part of while loop..
    # 4 haproxies total for proda nd pqa since dual zone. Only 2 for DEV. 
    createhaproxy_async("us-east-1b", _env, _appghorn, "True")  # for bstack used lasb, greenhornb for haproxy and casdb
    createhaproxy_async("us-east-1b", _env, _applas, "True")
    #createhaproxy_async("us-east-1c", _env, "lasb")
    #createhaproxy_async("us-east-1c", _env, "greenhornb")

    #PROD Needed 2 clusters
    #create_cassandra_cluster(_env, "us-east-1", _appname, "True")

    # for DEV/QA/REV only need single DB
    create_cassandra_single("stg", _applas, "us-east-1b", "True")
