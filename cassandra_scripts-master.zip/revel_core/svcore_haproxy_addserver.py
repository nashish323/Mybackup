#!bin/env python
# If you don't already have the requests module installed, install it using:
# pip install requests
# pip install argparse
# rajao 1/29/2014 - This script is to register BE servers to SVCORE or cutover stacks& also does ELB configuration
from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import time
import requests
import argparse
import json

def register_backends_with_aclrules(host, app_name, the_version, lasapp):
    '''register backend services to haproxy'''

    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": [
                    {
                "type": "path",
                "operation": "path_beg",
                "value": "/las",
                "backend": lasapp # if rule is met, the backend to route the request to
                    }
                ]
        }
    print("Configuring Haproxy frontend for", host)
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()

    # Need 2 backends here due to redirection rule above

    haproxy_backend1 = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
		"natives": ["compression algo gzip","compression type text/html text/plain text/css application/javascript"]
    }

    print haproxy_backend1
    print("Registering backends to HAProxy for", host)
    response1 = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend1))
    print response1.json()

    haproxy_backend2 = {
                "type" : "dynamic",
                "name" : lasapp,
                "version" : the_version,
                "natives": ["compression algo gzip","compression type text/html text/plain text/css application/javascript"]
    }

    print haproxy_backend2
    print("Registering second backend to HAProxy for", host)
    response2 = requests.put('http://' + host + ':10000/backends/' + lasapp, data=json.dumps(haproxy_backend2))
    print response2.json()
    return

def register_backends(host, app_name, the_version):
    '''register backend services to haproxy'''
    print("data entered is...", host, app_name, the_version)
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": []
        }
    print("Configuring Haproxy frontend for", host)
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()

    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version,
                "natives": ["compression algo gzip","compression type text/html text/plain"]
                }

    print haproxy_backend
    print("Registering backends to HAProxy for", host)
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

def create_elb_dualhosts(env, appname, region, haproxyhost1, haproxyhost2, action):
    '''function to create ELB instance and add haproxies to it'''
    print ("Arguments passed..", env, appname, region, haproxyhost1, haproxyhost2, action)
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    elb_data = {
                "environment": env,
                "_links": {
                    "owner": {
                    "href": teamid_url,
                 }
                },
                "app_name": appname,
                "privacy": "pub",
                "aws": {
                    "region": region
                },
                "frontend": {
                "listeners": [
                    {
                        "protocol": "HTTP",
                        "loadbalancer_port": 80,
                        "instance_port": 80
                    },
                    {
                    "instance_port": 443,
                    "loadbalancer_port": 443,
                    "protocol": "TCP"
                    }
                  ]
                },
                "backend": {
                    "health_check": {
                        "path": "/index.html",
                        "protocol": "HTTP",
                        "port": 80
                   }
                },
                "_embedded": {
                "backend_instances": [
                    {
                        "id": haproxyhost1
                    },
                       {
                        "id": haproxyhost2
                        },
                    ]
                   }
                }
    print ("Creating ELB with data passed ", elb_data)

    try:
        if (action == "create"):
            print("Creating ELB...")
            response = nib.under('loadbalancers').create(elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "update"):
            #to update - use this to add 2nd haproxy server as well or any other updates needed to ELB.
            print("Updating ELB resource...")
            response = nib.under('loadbalancers').update('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-42-'+appname+'-0',elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "delete"):
            print("Deleting an ELB resource...")
            response = nib.under('loadbalancers').delete('https://nibiru-prod.prsn.us/api/loadbalancers/stg-42-'+appname+'-0')

    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return elb_data;

def create_elb_single_host(env, appname, region, haproxyhost1, action):
    '''function to create ELB instance and add single haproxy to it'''
    print ("Arguments passed..", env, appname, region, haproxyhost1, action)
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    elb_data = {
                "environment": env,
                "_links": {
                    "owner": {
                    "href": teamid_url,
                 }
                },
                "app_name": appname,
                "privacy": "pub",
                "aws": {
                    "region": region
                },
                "frontend": {
                "listeners": [
                    {
                        "protocol": "HTTP",
                        "loadbalancer_port": 80,
                        "instance_port": 80
                    },
                     {
                        "instance_port": 443,
                        "loadbalancer_port": 443,
                        "protocol": "TCP"
                    }
                  ]
                },
                "backend": {
                    "health_check": {
                        "path": "/index.html",
                        "protocol": "HTTP",
                        "port": 80
                    }
                },
                "_embedded": {
                "backend_instances": [
                    {
                        "id": haproxyhost1
                    },
                    ]
                   }
                }
    print ("Creating ELB with data passed ", elb_data)

    try:
        if (action == "create"):
            print("Creating ELB...")
            response = nib.under('loadbalancers').create(elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "update"):
            #to update - use this to add 2nd haproxy server as well or any other updates needed to ELB.
            print("Updating ELB resource...")
            response = nib.under('loadbalancers').update('https://nibiru-prod.prsn.us/api/async/loadbalancers/'+env+'-42-'+appname+'-2',elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "delete"):
            print("Deleting an ELB resource...")
            response = nib.under('loadbalancers').delete('https://nibiru-prod.prsn.us/api/async/loadbalancers/stg-42-'+appname+'-0')

    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return elb_data;


if __name__ == '__main__':
#TODO Seperate out script for cutover only and it just prompts for version
    environments = {'dev', 'stg', 'prd'}
    _env = raw_input('What environment are you working in: |dev|stg|prd| ? ' )
    print("You have entered", _env)
    
    if _env not in environments:
        print("You have entered incorrect environment")
        exit

    # VARIABLES TO UPDATE
    #_env = dev|stg|prd
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/42"
    teamtoken = "9801259f-5e6e-46fa-8e8b-2f5c51f96a72"
    teamid = "42"
    currentver = "1.0.0"
    testver = "1.1.0"
    
    ghapp = "greenhorn" # for rev #greenhornrev STG & PROD = greenhorn or las
    lasapp = "las"   # for revv #lasrev

    #THIS IS ONLY FOR HAPROXY NAME FOR STACK B, APP NAME STILL SAME AS STACK A. NEVER EDIT
    ghappb = "ghornb"
    lasappb = "lasb"
    # END VARIABLES TO UPDATE

    haproxyStackA_gh_zoneb = _env+'-use1b-pu-'+teamid+'-'+ghapp+'-hapy-0001'
    haproxyStackA_las_zoneb = _env+'-use1b-pu-'+teamid+'-'+lasapp+'-hapy-0001'
    haproxyStackA_gh_zonec = _env+'-use1c-pu-'+teamid+'-'+ghapp+'-hapy-0001'
    haproxyStackA_las_zonec = _env+'-use1c-pu-'+teamid+'-'+lasapp+'-hapy-0001'
    
    haproxyStackB_gh_zoneb = _env+'-use1b-pu-'+teamid+'-'+ghappb+'-hapy-0001'
    haproxyStackB_las_zoneb = _env+'-use1b-pu-'+teamid+'-'+lasappb+'-hapy-0001'
    haproxyStackB_gh_zonec = _env+'-use1c-pu-'+teamid+'-'+ghappb+'-hapy-0001'
    haproxyStackB_las_zonec = _env+'-use1c-pu-'+teamid+'-'+lasappb+'-hapy-0001'

    # Registering main stack nodes
    # With ACL Rules function is for Greenhorn HAproxy only
    register_backends_with_aclrules(haproxyStackA_gh_zoneb+'.prv-openclass.com',ghapp,currentver,lasapp)
    #register_backends_with_aclrules(haproxyStackA_gh_zonec+'.prv-openclass.com',ghapp,currentver,lasapp)
    #register_backends(haproxyStackA_las_zoneb+'.prv-openclass.com',lasapp,currentver)
    #register_backends(haproxyStackA_las_zonec+'.prv-openclass.com',lasapp,currentver)

    #Registering B stack nodes
    
    #register_backends_with_aclrules(haproxyStackB_gh_zoneb+'.prv-openclass.com',ghapp,testver, lasapp)
    #register_backends_with_aclrules(haproxyStackB_gh_zonec+'.prv-openclass.com',ghapp,testver, lasapp)
    #register_backends(haproxyStackB_las_zoneb+'.prv-openclass.com',lasapp,testver)
    #register_backends(haproxyStackB_las_zonec+'.prv-openclass.com',lasapp,testver)

    #Do this should done after creating all haproxies per stack - LAST, check if update or create before running
    #create_elb_single_host(_env, ghapp, "us-east-1", haproxyStackA_gh_zoneb, "create")
    #create_elb_single_host(_env, lasapp, "us-east-1", haproxyStackA_las_zoneb, "create")

    #create_elb(_env, "ghornb", "us-east-1", haproxyStackB_gh_zoneb, haproxyStackB_gh_zonec)
    #create_elb(_env, "lasb", "us-east-1", haproxyStackB_las_zoneb, haproxyStackB_las_zonec)

    # UPDATE ELB'S
    #create_elb_single_host(_env, ghapp, "us-east-1", haproxyStackA_gh_zoneb, "update")
    #create_elb_single_host(_env, lasapp, "us-east-1", haproxyStackA_las_zoneb, "update")

    # ALWAYS USE THIS TO UPDATE GH REV because appname & elb name are not consistent same with staging
    # change hapy name to ghrev if haproxy is ever rebuilt in the future
    #create_elb_single_host(_env, ghapp, "us-east-1", "stg-use1b-pu-42-greenhornrev-hapy-0001", "update")

    #create_elb_dualhosts(_env, lasappb, "us-east-1", haproxyStackB_las_zoneb, haproxyStackB_las_zonec, "update")
    #create_elb_dualhosts(_env, ghappb, "us-east-1", "prd-use1b-pu-42-greenhornb-hapy-0001", "prd-use1c-pu-42-greenhornb-hapy-0001", "update")

