#!bin/env python
# If you don't already have the requests module installed, install it using:
# pip install requests
# pip install argparse
# rajao 1/29/2014 - This script is to register BE servers to nextext/dragonfly or cutover stacks& also does ELB configuration
from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import time
import requests
import argparse
import json

def register_backends(host, app_name, the_version):
    '''register backend services to haproxy'''
    print("data entered is...", host, app_name, the_version)
    haproxy_frontend = {
                "bind": "*:80,*:8080",
                "backend": app_name,
                "rules": []
        }
    print("Configuring Haproxy frontend")
    print haproxy_frontend
    response = requests.put('http://' + host  + ':10000/frontends/' + app_name, data=json.dumps(haproxy_frontend))
    print response.json()

    haproxy_backend = {
                "type" : "dynamic",
                "name" : app_name,
                "version" : the_version
                }

    print haproxy_backend
    print("Registering backends to HAProxy")
    response = requests.put('http://' + host + ':10000/backends/' + app_name, data=json.dumps(haproxy_backend))
    print response.json()
    return

def cutover_backends(host, app_name, the_version):
    '''switch haproxy backeds'''

    data = {
    #"role": app_name,     # app name registered to thalassa
    "version": the_version  # version to route to
        }

    #need header for post
    _headers = {'Content-Type': 'application/json'}

    print ("Cutting over instance versions")
    print ("data to send...", data)
    data = requests.post('http://' + host + ':10000/backends/' + app_name, data=json.dumps(data), headers=_headers)
    print ("Response back is..", data.json())
    return

def create_elb_dualhosts(env, appname, region, haproxyhost1, haproxyhost2, action):
    '''function to create ELB instance and add haproxies to it'''
    print ("Arguments passed..", env, appname, region, haproxyhost1, haproxyhost2, action)
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    elb_data = {
                "environment": env,
                "_links": {
                    "owner": {
                    "href": teamid_url,
                 }
                },
                "app_name": appname,
                "privacy": "pub",
                "aws": {
                    "region": region
                },
                "frontend": {
                "listeners": [
                    {
                        "protocol": "HTTP",
                        "loadbalancer_port": 80,
                        "instance_port": 8080
                    },
                    {
                        "protocol": "TCP",
                        "loadbalancer_port": 443,
                        "instance_port": 443
                    }
                  ]
                },
                "backend": {
                    "health_check": {
                        "path": "/index.html",
                        "protocol": "HTTP",
                        "port": 8080
                }
                },
                "_embedded": {
                "backend_instances": [
                    {
                        "id": haproxyhost1
                    },
                       {
                        "id": haproxyhost2
                        },
                    ]
                   }
                }
    print ("Creating ELB with data passed ", elb_data)

    try:
        if (action == "create"):
            print("Creating ELB...")
            response = nib.under('loadbalancers').create(elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "update" and appname == app):
            #to update - use this to add 2nd haproxy server as well or any other updates needed to ELB..
            print("Updating ELB resource...")
            print("test I would've been doing this if the appname was dragon")
            response = nib.under('loadbalancers').update('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-55-'+appname+'-0',elb_data)

            #added extra checks here because ELB name is dragon3 for PRODB
        if (action == "update" and appname == appb and env == "prd"):
            #to update - use this to add 2nd haproxy server as well or any other updates needed to ELB..
            print("Updating ELB resource...")
            print("test I would've been doing this if the appname was dragonb")
            response = nib.under('loadbalancers').update('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-55-'+appname+'-3',elb_data)

        if (action == "delete"):
            print("Deleting an ELB resource...")
            response = nib.under('loadbalancers').delete('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-55-'+appname+'-0')

    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return elb_data;

def create_elb_single_host(env, appname, region, haproxyhost1, action):
    '''function to create ELB instance and add single haproxy to it'''
    print ("Arguments passed..", env, appname, region, haproxyhost1, action)
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = teamtoken
    nib = Nibiru(nibiruHost, bearer_token=token);

    elb_data = {
                "environment": env,
                "_links": {
                    "owner": {
                    "href": teamid_url,
                 }
                },
                "app_name": appname,
                "privacy": "pub",
                "aws": {
                    "region": region
                },
                "frontend": {
                "listeners": [
                    {
                        "protocol": "HTTP",
                        "loadbalancer_port": 80,
                        "instance_port": 8080
                    },
                    {
                        "protocol": "TCP",
                        "loadbalancer_port": 443,
                        "instance_port": 443
                    }
                  ]
                },
                "backend": {
                    "health_check": {
                        "path": "/index.html",
                        "protocol": "HTTP",
                        "port": 8080
                }
                },
                "_embedded": {
                "backend_instances": [
                    {
                        "id": haproxyhost1
                    },
                    ]
                   }
                }
    print ("Creating ELB with data passed ", elb_data)

    try:
        if (action == "create"):
            print("Creating ELB...")
            response = nib.under('loadbalancers').create(elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "update"):
            #to update - use this to add 2nd haproxy server as well or any other updates needed to ELB.
            print("Updating ELB resource...")
            # -2 for QA
            #response = nib.under('loadbalancers').update('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-55-'+appname+'-2',elb_data)
            response = nib.under('loadbalancers').update('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-55-'+appname+'-0',elb_data)
            instance_url = HalResource(response).get_self_link()
            print("Instance URL is ", instance_url)

        if (action == "delete"):
            print("Deleting an ELB resource...")
            response = nib.under('loadbalancers').delete('https://nibiru-prod.prsn.us/api/loadbalancers/'+env+'-55-'+appname+'-0')

    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return elb_data;


if __name__ == '__main__':
#TODO Seperate out script for cutover only and it just prompts for version
    environments = {'dev', 'stg', 'prd'}
    _env = raw_input('What environment are you working in: |dev|stg|prd| ? ' )
    print("You have entered", _env)
    
    if _env not in environments:
        print("You have entered incorrect environment")
        exit

    # VARIABLES TO UPDATE
    #_env = dev|stg|prd
    teamid_url = "https://nibiru-prod.prsn.us/api/teams/55"
    teamtoken = "fb4ef7b4-7547-4f39-aa4a-133a6ea65430"
    teamid = "55"
    #### END OF GLOBAL VARIABLES###
    currentver = "1.0.0"
    testver = "1.1.0"
    app = "dragon"
    appb = "dragonb"  # FOR ELB B & HAPROXY B only
    # END ENV SPECIFIC VARIABLES TO UPDATE..

    haproxyStackA_zoneb = _env+'-use1b-pu-'+teamid+'-'+app+'-hapy-0001'
    haproxyStackA_zonec = _env+'-use1c-pu-'+teamid+'-'+app+'-hapy-0001'
    haproxyStackB_zoneb = _env+'-use1b-pu-'+teamid+'-'+appb+'-hapy-0001'
    haproxyStackB_zonec = _env+'-use1c-pu-'+teamid+'-'+appb+'-hapy-0001'

    # Registering main stack nodes

    # register_backends(haproxyStackA_zoneb+'.prv-openclass.com',app,currentver)
    # register_backends(haproxyStackA_zonec+'.prv-openclass.com',app,currentver)

    #Registering B stack nodes
    #
    # register_backends(haproxyStackB_zoneb+'.prv-openclass.com',app,testver)
    # register_backends(haproxyStackB_zonec+'.prv-openclass.com',app,testver)

    #Do this should done after creating all haproxies per stack - LAST, check if update or create before running
#   create_elb_single_host(_env, app, "us-east-1",  haproxyStackA_zoneb, "create")
    # create_elb_dualhosts(_env, app, "us-east-1", haproxyStackB_zoneb, haproxyStackB_zonec, "create")
    # create_elb_dualhosts(_env, appb, "us-east-1", haproxyStackB_zoneb, haproxyStackB_zonec, "create")

    ### ELB UPDATES ###
    # TODO note if updating change elb name to dragonb-3 for stack B
    #create_elb_dualhosts(_env, app, "us-east-1", haproxyStackA_zoneb, haproxyStackA_zonec, "update")
    #create_elb_dualhosts(_env, appb, "us-east-1", haproxyStackB_zoneb, haproxyStackB_zonec, "update")

    ## ELB Single host UPDATE ###
    create_elb_single_host(_env, app, "us-east-1",  haproxyStackA_zoneb, "update")

