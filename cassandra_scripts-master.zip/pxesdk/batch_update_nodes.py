# coding: utf-8
#!/usr/bin/python -B

# Description: Nibiru v2 Create Java nodes script
# Date       : 10/03/2013
# modified by rajao to update pxe core app nodes in batch

from nibiru import Nibiru, NibiruError
from time import sleep
from nibiru import HalResource
import logging
import requests
import argparse
import time
import string

logging.basicConfig(level=logging.ERROR)
#logging.basicConfig(level=logging.DEBUG)..

def update_tomcat_instance(zoneinfo, env, thal_host, appname, version, hostname):
    ### The only difference is that appdynamics is not included in the function when updating STG or PRD Instances
    '''Function to create update instance'''    

    if (env == "prd"):
       env_upper = "PROD"
    if (env == "stg" and "qa" not in env):
       env_upper = "STG"

    if ("qa" in appname or "dev" in env):
        instance_info = {
        "environment": env,
        "app_name": appname,
        "_links" : {
        "owner": {
        "href": "https://nibiru-prod.prsn.us/api/teams/53",
                 },
           },
        "app_version": version,
        "aws": {
            "size": "m1.medium",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "logging::application": {},
                "tomcat": {},
                "thalassa::client": {
                    "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  }
        }

    else:   # for PROD & STAGING ONLY
        instance_info = {
        "environment": env,
        "app_name": appname,
        "_links" : {
        "owner": {
        "href": "https://nibiru-prod.prsn.us/api/teams/53",
                 },
           },
        "app_version": version,
        "aws": {
            "size": "m1.xlarge",
            "zone": zoneinfo
        },
        "puppet": {
            "classes": {
                "logging::application": {},
                    "appdynamics": {
                        "application_name": "HED_NextGen_"+env_upper+"",
                        "tier_name": "PXESDK_"+env_upper+"",
                        "use_tomcat": "true"
                },
                "thalassa::client": {
                    "config": {
                    "apiport": 9000,
                    "host": thal_host,
                    "registrations": appname+"@"+version+":8080"
                                }
                                  }
                       }
                  }
        }


    print("Updating the QA or DEV app node instance...")
    print("Data to send...", instance_info)
    try:
        #use below to update existing instances only
        response = nib.under('instances').update("https://nibiru-prod.prsn.us/api/instances/"+hostname,instance_info)
        #for async use below
        #response = nib.under('instances').update("https://nibiru-prod.prsn.us/api/async/instances/"+hostname,instance_info)
        instance_url = HalResource(response).get_self_link()
        print("Instance URL is ", instance_url)
    except NibiruError as err:
        print("There was an error deploying the node! ", err)
    return instance_info;    


    
###############################
########   INSTANCES   ########
################################

if __name__ == '__main__':
    nibiruHost = "https://nibiru-prod.prsn.us/api"
    token = "acd67a0a-c5bb-49b0-a312-dfd05f011a12"
    nib = Nibiru(nibiruHost, bearer_token=token);
    
    environments = {'dev', 'stg', 'prd'}
    _env = raw_input('What environment are you working in: |dev|stg|prd| ? ' )
    print("You have entered", _env)
    
    if _env not in environments:
        print("You have entered incorrect environment")
        exit    

    #_version = "1.1.0" # instance version tag
    #_env = "prd" # prd, stg or dev
    _appname = "sdk"
    stghost100b = ["stg-use1b-pr-53-sdk-01x00x00-0001", "stg-use1b-pr-53-sdk-01x00x00-0002"]
    stghost100c = ["stg-use1c-pr-53-sdk-01x00x00-0001", "stg-use1c-pr-53-sdk-01x00x00-0002"]
    prdhost100b = ["prd-use1b-pr-53-sdk-01x00x00-0001","prd-use1b-pr-53-sdk-01x00x00-0002"]
    prdhost100c = ["prd-use1c-pr-53-sdk-01x00x00-0001","prd-use1c-pr-53-sdk-01x00x00-0002"]
    qahost = "stg-use1b-pr-53-sdkqa-01x00x00-0001"
    devhost = ""
    #LOOPS THROUGH ENTIRE LIST OF ITEMS IN _HOSTS AND UPDATE BASED ON ANY CHANGES TO JSON ABOVE
    #for i in range(len(prdhost100b)):
        #update_tomcat_instance("us-east-1b", _env, _env+"-use1b-thalassa.prv-openclass.com",_appname, "1.0.0", prdhost100b[i])
    
    #for i in range(len(prdhost100c)):
	#   update_tomcat_instance("us-east-1c", _env, _env+"-use1c-thalassa.prv-openclass.com",_appname, "1.0.0", prdhost100c[i])





