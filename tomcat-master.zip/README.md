tomcat

Description
===========

Installs Tomcat and Java. Optionally install tomcat-admin and tomcat-docs.
Creates Staging and webapps directories.  Starts Tomcat Service.  Wraps the
Java class and allows the passing of specific Java version.  The Java version
used is based on /etc/alternatives.

Can use the war.pp defined type to deploy war files.

Requirements
============

Platform
--------
Ubuntu

License
=======

Copyright (C) 2013 Pearson, Inc.
Distributed under the All Rights Reserved License.
