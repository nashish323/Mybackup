# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'tomcat::docs' do

  context 'with osfamily => Debian' do
    let (:facts) { {
      :osfamily => 'Debian',
      :virtual  => 'virtualbox'
    } }

#    it { should contain_class('tomcat').with(
#      :version => '7.0.26-1ubuntu1',
#      :java_vendor => 'oracle',
#      :java_release => '6',
#      :java_version => 'latest',
#      :java_license_seen => true,
#      :java_license_select => true,
#    )}

    it { should contain_package('tomcat7-docs').that_notifies('Service[tomcat]')}
    it { should contain_package('tomcat7-docs').that_requires('Package[tomcat]')}
    it { should contain_package('tomcat7-docs').with(
        :ensure => 'installed',
    )}

  end

end
