# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'tomcat' do

  context 'with osfamily => Debian' do
    let (:facts) { {
      :osfamily => 'Debian',
      :virtual  => 'virtualbox'
    } }
    let (:params) do {
      :version             => '7.0.26-1ubuntu1',
      :java_vendor         => 'oracle',
      :java_release        => '7',
      :java_version        => 'present',
    } end

    it { should contain_class('java').with(
       :vendor         => 'oracle',
       :release        => '7',
       :version        => 'present',
    ) }

    it { should contain_package('tomcat').with(
      :ensure => '7.0.26-1ubuntu1',
      :name   => 'tomcat7'
    ) }
    it { should contain_package('tomcat').that_requires('Class[java]') }
    it { should contain_package('tomcat').that_comes_before('Service[tomcat]') }

    it { should contain_service('tomcat').with(
      :ensure => 'running',
      :enable => 'true',
      :name   => 'tomcat7',
    ) }

    it { should contain_file('/var/lib/tomcat7/webapps').that_requires('Package[tomcat]') }
    it { should contain_file('/var/lib/tomcat7/webapps').with(
      :ensure => 'directory',
      :owner  => 'tomcat7',
      :group  => 'tomcat7',
      :mode   => '0755',
    ) }

    it { should contain_file('/var/lib/tomcat7/staging').that_requires('Package[tomcat]') }
    it { should contain_file('/var/lib/tomcat7/staging').with(
      :ensure => 'directory',
      :owner  => 'tomcat7',
      :group  => 'tomcat7',
      :mode   => '0755',
    ) }

  end

end
