# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'tomcat' do

  describe package('tomcat7') do
    it { should be_installed.by('apt').with_version('7.0.26-1ubuntu1.2') }
  end

  describe file('/var/lib/tomcat7/webapps') do
    it { should be_directory }
    it { should be_mode 755 }
    it { should be_owned_by 'tomcat7' }
    it { should be_grouped_into 'tomcat7' }
  end

  describe file('/var/lib/tomcat7/staging') do
    it { should be_directory }
    it { should be_mode 755 }
    it { should be_owned_by 'tomcat7' }
    it { should be_grouped_into 'tomcat7' }
  end

  describe service('tomcat7') do
    it { should be_enabled }
    it { should be_running }
  end

end
