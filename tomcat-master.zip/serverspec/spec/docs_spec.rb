# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'tomcat::docs' do

  describe package('tomcat7-docs') do
    it { should be_installed.by('apt').with_version('7.0.26-1ubuntu1.2') }
  end

end

