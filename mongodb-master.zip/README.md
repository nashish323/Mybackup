MongoDB
===========

![MongoDB](http://upload.wikimedia.org/wikipedia/commons/e/eb/MongoDB_Logo.png 'MongoDB')


Description
===========

MongoDB (from "humongous") is an open-source document database, and the leading NoSQL database. Written in C++, MongoDB features:

Document-Oriented Storage »
JSON-style documents with dynamic schemas offer simplicity and power.

Full Index Support »
Index on any attribute, just like you're used to.

Replication & High Availability »
Mirror across LANs and WANs for scale and peace of mind.

Auto-Sharding »
Scale horizontally without compromising functionality.

Querying »
Rich, document-based queries.

Fast In-Place Updates »
Atomic modifiers for contention-free performance.

Map/Reduce »
Flexible aggregation and data processing.

GridFS »
Store files of any size without complicating your stack.

Professional Support by MongoDB »
Enterprise class support, training, and consulting available.

* [More Info...](http://docs.mongodb.org/manual/)

Puppet Module Description
=========================

This module provides the main mongodb Puppet classes (mongodb, mongodb::initiate) which set up either a standalone instance or cluster of MongoDB servers. Multiple versions of MongoDB are available in the apt-repos and are compatible with the puppet module.

The mongodb class includes install, config, and service subclasses which ensure MongoDB is installed, configured, and started.

The mongodb::initiate class allows the replica set to properly initiate, by taking the servers and priorities of the servers, from parameters.

See the content of each Puppet class within the module for more details about implementation and parameters.

Puppet Module Notes/Limitations
===============================

* This module configures, but does not initiate the replica set. This means that whether provisioning a standalone instance or a cluster the replicaset will still need to be initiated with the mongodb::initiate class. For clusters, include mongodb::initiate on one instance (not each instance of the replica set).

Requirements
============

Platform
--------

* Ubuntu 12.x

License
=======

Copyright (C) 2014 Pearson, Inc.
Distributed under the All Rights Reserved License.
