require 'beaker-rspec/spec_helper'
require 'beaker-rspec/helpers/serverspec'

hosts.each do |host|
  # Install Puppet
  install_puppet
  on host, "mkdir -p #{host['distmoduledir']}"
end

RSpec.configure do |c|
  # Project root
  proj_root = File.expand_path(File.join(File.dirname(__FILE__), '..'))

  # Readable test descriptions
  c.formatter = :documentation
  # Configure all nodes in nodeset
  c.before :suite do
    # Install module and dependencies

    hosts.each do |host|
      #We assume that all of your modules and dependencies are placed in the
      # spec/fixtures/modules folder, per other build steps, so we are dropping
      # them in as specified
      scp_to(host, proj_root+'/spec/fixtures/modules', '/etc/puppet/', {:ignore_list => PUPPET_MODULE_INSTALL_IGNORE})

      #on host, puppet('module', 'install', 'puppetlabs-stdlib'), { :acceptable_exit_codes => [0,1] }
    end
  end
end
