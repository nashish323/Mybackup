# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'mongodb' do

#  it 'should include mongodb::repo' do
#    should contain_class('mongodb::repo')
#  end

  context 'in default params mode' do

    it do
      should contain_file('etc-mongodb-conf').with(
        'path'    => '/etc/mongodb.conf',
        'content' => /nojournal = false/,
        'content' => /dbpath = \/data\/db.1\//,
      )
    end

    it do
      should create_class('mongodb::install').with({
        'version' => '2.4.10'
      })
    end

    it do
      should create_class('mongodb::config').with({
        'base_data_directory' => '/data',
        'mongodb_directory' => '/data/mongodb',
        'snapshot_directory' => '/data/snapshot',
        'db_directory' => '/data/db.1/',
        'no_journal' => false,
        'shard' => 'mongo',
      })
    end
  end

  context 'in provided params mode' do
    let :params do
      {
        :key => 'testkey',
        :auth => true,
        :base_data_directory => '/datadir',
        :version => '2.4.1',
        :no_journal => false,
        :servers => ['10.199.201.50'],
        :priorities => ['1'],
        :shard => 'mongo01',
      }
    end

    it do
      should contain_file('etc-mongodb-conf').with(
        'path'    => '/etc/mongodb.conf',
        'content' => /nojournal = false/,
        'content' => /dbpath = \/datadir\/db.1\//,
        'content' => /keyFile = \/etc\/mongokey/,
      )
    end

    it do
      should create_class('mongodb::install').with({
        'version' => '2.4.1'
      })
    end

    it do
      should create_class('mongodb::config').with({
        'base_data_directory' => '/datadir',
        'mongodb_directory' => '/datadir/mongodb',
        'snapshot_directory' => '/datadir/snapshot',
        'db_directory' => '/datadir/db.1/',
        'key' => 'testkey',
        'no_journal' => false,
        'shard' => 'mongo01',
      })
    end
  end

  it { should contain_class('mongodb::service') }
  it { should contain_class('mongodb::backup') }

end