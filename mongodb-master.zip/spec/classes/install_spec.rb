# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'mongodb::install' do

  it do
    should contain_package("gnupg").with(
      'ensure' => 'present',
    )
  end

  it do
    should contain_package("ruby-ldap").with(
      'ensure' => 'present', 
    )
  end

  context 'in default params mode' do

    it do
      should contain_file("install-base").with(
        'ensure' => 'directory',
        'path' => '/opt/mongodb',
      )
    end
    
    it do
      should contain_package("mongodb-10gen").with(
        'ensure' => '2.4.10',
      )
    end
  end

  context 'in provided params mode' do

    let :params do
      {
        :version => '2.4.10',
        :install_base => '/var/lib/mongodb'
      }
    end

    it do
      should contain_file("install-base").with(
        'ensure' => 'directory',
        'path' => '/var/lib/mongodb',
      )
    end
    
    it do
      should contain_package("mongodb-10gen").with(
        'ensure' => '2.4.10',
      )
    end
  end
end