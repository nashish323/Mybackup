# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'mongodb::backup' do

  it do
    should contain_file('/opt/mongodb/scripts/backup.js').with(
      'ensure' => 'present',
      'mode' => '0644',
    )
  end

  context 'with facts' do
    let :facts do
      {
        :nibiru_app_name => 'sstest',
        :nibiru_app_type => 'test',
        :nibiru_environment => 'dev',
      }
    end

    it do
      should contain_backup__job('sstest-test-dev').with(
        'ensure' => 'present',
        'source_dir' => '/data/dbbackup',
        'exclude' => ['**/db.1/local*', '**/db.1/journal'],
      )
    end
  end
end
