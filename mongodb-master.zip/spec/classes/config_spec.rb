# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'mongodb::config' do

  it do
    should contain_file("mongodb-log-dir").with(
      'ensure' => 'directory',
      'path' => '/var/log/mongodb/',
    )
  end

  it do
    should contain_file("mongodb-log-file").with(
      'ensure' => 'present',
      'path' => '/var/log/mongodb/mongodb.log',
    )
  end

  it do
    should contain_file("mongodb-scripts-dir").with(
      'ensure' => 'directory',
      'path' => '/opt/mongodb/scripts'
    )
  end

  it do
    should contain_logrotate__rule("mongodb").with(
      'path' => '/var/log/mongodb/*.log',
      'rotate_every' => 'day',
      'rotate' => 7,
      'compress' => true,
      'missingok' => true,
      'ifempty' => false,
      'sharedscripts' => true,
      'create' => true,
      'create_mode' => '0640',
      'create_owner' => 'mongodb',
      'create_group' => 'mongodb',
      'copytruncate' => true,
    )
  end

  context 'in default params mode' do
    it do
      should contain_file("mongodb-base-mongodb-dir").with(
        'ensure' => 'directory',
        'path' => '/data/mongodb',
      )
    end

    it do
      should contain_file("mongodb-snapshot-dir").with(
        'ensure' => 'directory',
        'path' => '/data/snapshot',
      )
    end

    it do
      should contain_file("mongodb-data-dir").with(
        'ensure' => 'directory',
        'path' => '/data/db.1/',
      )
    end
  end

  context 'in provided params mode' do
  let :params do
    {
      :base_data_directory => '/datadir',
      :no_journal => false,
      :mongodb_directory => '/datadir/mongodb',
      :snapshot_directory => '/datadir/snapshot',
      :db_directory => '/datadir/db.1/',
      :shard => 'mongo',
    }
  end

  it do
      should contain_file("mongodb-base-mongodb-dir").with(
        'ensure' => 'directory',
        'path' => '/datadir/mongodb',
      )
    end

    it do
      should contain_file("mongodb-snapshot-dir").with(
        'ensure' => 'directory',
        'path' => '/datadir/snapshot',
      )
    end

    it do
      should contain_file("mongodb-data-dir").with(
        'ensure' => 'directory',
        'path' => '/datadir/db.1/',
      )
    end
  end
end