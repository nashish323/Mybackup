# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'mongodb::initiate' do

  it do
    should contain_exec('mongodb-kill-replicaset-init').with(
      'command' => 'ps -ef | grep /tmp/replicaset.sh | grep -v grep | awk \'{print $2}\' | xargs kill -9',
      'onlyif'  => 'ps -ef | grep /tmp/replicaset.sh | grep -v grep',
    )
  end

  it do
    should contain_file('mongodb-status-check').with(
      'path'    => '/tmp/checkstatus.js',
      'source'  => 'puppet:///modules/mongodb/checkstatus.js',
    )
  end

  it do
    should contain_exec('mongodb-initiate').with(
      'command'   => 'bash /tmp/replicaset.sh',
      'unless'    => 'mongo /tmp/checkstatus.js  | grep "PRIMARY"',
      'timeout'   => '1000',
      'logoutput' => true,
    )
  end

  context 'in passed params mode' do
    let(:pre_condition) { 'class mongodb { $servers = ["10.199.201.50"] }' }
    let(:pre_condition) { 'class mongodb { $shard = "mo1234" }' }

    it do
      should contain_file('mongodb-replicaset-file').with(
        'path'    => '/tmp/replicaset.sh',
        'content' => /10.199.201.50/,
        'content' => /mo1234/,
      )
    end
  end
end