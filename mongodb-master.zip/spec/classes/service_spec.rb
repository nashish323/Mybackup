# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'mongodb::service' do

  it do
    should contain_service("mongodb").with(
      'ensure' => 'running',
    )
  end
end