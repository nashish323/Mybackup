conf = db.isMaster()
backup = (conf.slaveDelay != 0 && conf.passive && conf.hidden) ? "true" : "false"
print(backup)

