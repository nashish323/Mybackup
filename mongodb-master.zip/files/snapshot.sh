#!/bin/bash
#######################################################################################
# This file is managed by Puppet                                                      #
# Any changes to this file will be overwritten every 30 minutes                       #
# For more details please see https://hub.pearson.com/confluence/display/eSAT/Puppet  #
#######################################################################################

## Set some variables.

export snapshotname="mongosnapshot"
export snapdir="/data/snapshot"
export filerdir="/data/mongobackup"

export curdate=`/bin/date +%m%d%y`
export host=`hostname -s`

export mongovg=`lvs --noheadings -o vg_name,lv_name | awk -F " " '/datavg/ {;print $1}'| grep -v journal | head -1`
echo $mongovg
export mongolv=`lvs --noheadings -o vg_name,lv_name | awk -F " " '/datavg/ {;print $2}'| grep -v journal | grep -v mongosnapshot | head -1`
echo $mongolv

## Define functions

createsnapshot () {

lvcreate -L8GB -s -n $snapshotname /dev/$mongovg/$mongolv
mount /dev/$mongovg/$snapshotname $snapdir

}

## Loop here to specify date and keep 14 snapshots, and remove old snapshots.

copysnapshot () {

mkdir -p $filerdir/$host/$curdate

tar czvf $filerdir/$host/$curdate/snapshot-data$curdate.tar.gz $snapdir/db.1
gpg --yes --trust-model always --homedir /opt/mongodb/keys/ --encrypt --recipient 'jessicab@ecollege.com' $filerdir/$host/$curdate/snapshot-data$curdate.tar.gz
rm -f $filerdir/$host/$curdate/snapshot-data$curdate.tar.gz
}

## Remove snapshot.

removesnapshot () {

umount /data/snapshot
lvremove -f /dev/$mongovg/mongosnapshot

}

awssnapshot () {
## Do not remove, this is what keeps AWS snapshots cooking.

AWSKEYPATH=/opt/mongodb/keys/awsmongosnap
EC2_INSTANCE_ID="`wget -q -O - http://169.254.169.254/latest/meta-data/instance-id || die \"wget instance-id has failed: $?\"`"
test -n "$EC2_INSTANCE_ID" || die 'cannot obtain instance-id'
EC2_AVAIL_ZONE="`wget -q -O - http://169.254.169.254/latest/meta-data/placement/availability-zone || die \"wget availability-zone has failed: $?\"`"
test -n "$EC2_AVAIL_ZONE" || die 'cannot obtain availability-zone'
EC2_REGION="`echo \"$EC2_AVAIL_ZONE\" | sed -e 's:\([0-9][0-9]*\)[a-z]*\$:\\1:'`"

ls -la $filerdir/$host/$curdate
RESID="`ec2-describe-volumes -K $AWSKEYPATH/awsmongosnap.key -C $AWSKEYPATH/awsmongosnap.crt -F attachment.instance-id=$EC2_INSTANCE_ID -F tag-key=mongosnap --hide-tags | awk '{print$2}' | head -1 | xargs -i ec2-create-snapshot {} -K $AWSKEYPATH/awsmongosnap.key -C $AWSKEYPATH/awsmongosnap.crt | awk '{print$2}'`" 


ec2-create-tags $RESID -K $AWSKEYPATH/awsmongosnap.key -C $AWSKEYPATH/awsmongosnap.crt --tag mongobackup --tag hostname=$host

}

snapmaint () {

     /usr/bin/find $filerdir -maxdepth 1 -ctime +3 -type d | xargs rm -rf

}

cleanup () {

        unset snapshotname
        unset snapdir
        unset filerdirdir

        unset curdate
        unset host

        unset mongovg
        unset mongolv

        unset SNAPRESULTS
        unset EC2_INSTANCE_ID
        unset EC2_AVAIL_ZONE
        unset EC2_REGION

}


## Here is where we actually start doing stuff...
## First, run maintenence. This is run first, to prevent problems later.
snapmaint

## Check to make sure we are not already running.
[ -e $snapdir/unset_done.sem ] && rm -f /tmp/unset_done.sem
echo $$ > /tmp/unset_running.sem

createsnapshot
copysnapshot
removesnapshot
awssnapshot
cleanup
