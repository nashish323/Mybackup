#!/bin/bash
#
# MongoDB Backup
#
# This script checks if the current server is a delayed secondary, and
# if it is, flushes the journal, stops mongo, creates and mounts an
# lvm snapshot, restarts mongo, uses duply to backup the files from the 
# lvm snapshot into the Amazon S3 bucket dedicated to mongo backups in a 
# folder created for each appname, then unmounts and deletes the lvm 
# snapshot.
#
# Requires:
# duply (standard ubuntu package)
# /etc/mongodb/backup.js (checks for delayed secondary)
# /home/ubuntu/.duply/mongodb_backup/conf (duply config)
# /home/ubuntu/.duply/mongodb_backup/excludes (files to exclude)
#
################################################################################

# Cleanup funciton
function cleanup() {
  /bin/umount /data/dbbackup
  /bin/rmdir /data/dbbackup
  /sbin/lvremove -f /dev/datavg/dbbackup
}

# Check for required files
backup_conf_dir='/home/ubuntu/.duply/mongodb_backup'
required_files="/opt/mongodb/scripts/backup.js ${backup_conf_dir}/conf ${backup_conf_dir}/excludes"

for file in $required_files
do
	if [ ! -f /etc/mongodb/backup.js ]
	then
		echo "Missing ${file}. Exiting."
		exit 1 
	fi
done

# Flush the journal and create the snapshot
echo "db.fsyncLock()" | /usr/bin/mongo | grep '"ok" : 1'
if [ $? -eq 1 ]
then
	echo "Error on db.fsyncLock(); Exiting"
	exit 1
fi

/sbin/lvcreate -L30G -s -n dbbackup /dev/datavg/datalv
if [ $? -eq 1 ]
then
	echo "Error creating lvm snapshot; Exiting"
	exit 1
fi
echo "db.fsyncUnlock()" | /usr/bin/mongo

# Create mount point and mount snapshot
/bin/mkdir /data/dbbackup
if [ $? -eq 1 ]
then
	echo "Error creating /data/dbbackup; Exiting"
	cleanup
	exit 1
fi
/bin/mount /dev/datavg/datalv /data/dbbackup
if [ $? -eq 1 ]
then
	echo "Error mounting lvm snapshot; Exiting"
	cleanup
	exit 1
fi

# Run the backup
/usr/bin/duply mongodb_backup backup
if [ $? -eq 1 ]
then
	echo "Error running backup; Exiting"
	cleanup
	exit 1
fi

# Cleanup
cleanup

