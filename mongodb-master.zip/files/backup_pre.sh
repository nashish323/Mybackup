#!/bin/bash
#
# This script tests to see if the current node should be backed up, and,
# if so, creates the lvm snapshot for the backup

# Test for javascript file
echo "Test for javascript file."
if [ ! -f /opt/mongodb/scripts/backup.js ]
then
	echo "  Missing /opt/mongodb/scripts/backup.js. Exiting."
	exit 1
else
  echo "  Found /opt/mongodb/scripts/backup.js"
fi

# Test if the current node should be backed up
echo "Test if the current node should be backed up."
secondary_master=`/usr/bin/mongo --quiet /opt/mongodb/scripts/backup.js`
if [ "$secondary_master" != "true" ]
then
	echo "  This node is not a secondary master. Exiting."
	exit 1
else
	echo "  This node is a secondary master. Backup will proceed."
fi

# Flush the journal and create the snapshot
echo "Flush the journal and create the snapshot"
echo "  mongodb lock"
echo "db.fsyncLock()" | /usr/bin/mongo | grep '"ok" : 1'
if [ $? -eq 1 ]
then
	echo "    Error on db.fsyncLock(); Exiting."
	exit 1
else
  echo "    mongodb locked."
fi

# Create 'dbbackup' snapshot
echo "  Create 'dbbackup' snapshot"
/sbin/lvcreate -L30G -s -n dbbackup /dev/datavg/datalv
if [ $? -eq 1 ]
then
	echo "    Error creating lvm snapshot; Exiting."
	exit 1
else
  echo "  Snapshot created"
fi
echo "mongodb unlock"
echo "db.fsyncUnlock()" | /usr/bin/mongo

# Create mount point
echo "Create mount point"
echo "  Create directory /data/dbbackup"
/bin/mkdir /data/dbbackup
if [ $? -eq 1 ]
then
	echo "    Error creating /data/dbbackup; Exiting."
	exit 1
else
  echo  "    Directory /data/dbbackup created"
fi

# Mount the 'dbbackup' snapshot
echo "  Mount the 'dbbackup' snapshot"
/bin/mount /dev/datavg/dbbackup /data/dbbackup
if [ $? -eq 1 ]
then
	echo "    Error mounting lvm snapshot; Exiting."
	exit 1
else
  echo "    'dbbackup' snapshot mounted"
fi
