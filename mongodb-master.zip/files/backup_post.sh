#!/bin/bash
#
# This script cleans up after a mongodb backup has completed

# Unmount lvm snapshot
echo "Unmount lvm snapshot"
/bin/umount /data/dbbackup

# Remove snapshot mount point
echo "Remove snapshot mount point"
/bin/rmdir /data/dbbackup

# Remove lvm snapshot
echo "Remove lvm snapshot"
/sbin/lvremove -f /dev/datavg/dbbackup

