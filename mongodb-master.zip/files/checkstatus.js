db = db.getSiblingDB("admin")
stat = rs.status()
printjson(stat)

