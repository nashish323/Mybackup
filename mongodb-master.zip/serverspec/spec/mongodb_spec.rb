# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

packages = ['gnupg','ruby-ldap','mongodb-10gen']

dirs = ['/var/log/mongodb','/data/db.1',
        '/data/snapshot','/data/mongodb']

root_files = ['/etc/profile.d/mongodb.sh','/etc/mongodb.conf',
              '/etc/logrotate.d/mongodb']

mongo_files = ['/var/log/mongodb/mongodb.log']

describe 'mongodb' do
 
  packages.each do |package|
    describe package("#{package}") do
      it { should be_installed }
    end
  end

  dirs.each do |dir|
    describe file("#{dir}") do
      it { should be_directory }
      it { should be_owned_by 'mongodb' }
      it { should be_grouped_into 'mongodb' }
    end
  end

  root_files.each do |file|
    describe file("#{file}") do
      it { should be_file }
      it { should be_owned_by 'root' }
      it { should be_grouped_into 'root' }
    end
  end

  mongo_files.each do |file|
    describe file("#{file}") do
      it { should be_file }
      it { should be_owned_by 'mongodb' }
      it { should be_grouped_into 'mongodb' }
    end
  end

  describe service("mongodb") do
    it { should be_running }
  end
end