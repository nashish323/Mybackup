haproxy

Description
===========

HAProxy is a free, very fast and reliable solution offering high availability, load balancing, and proxying for TCP and HTTP-based applications. It is particularly suited for web sites crawling under very high loads while needing persistence or Layer7 processing. Supporting tens of thousands of connections is clearly realistic with today's hardware. Its mode of operation makes its integration into existing architectures very easy and riskless, while still offering the possibility not to expose fragile web servers to the Net.

Requirements
============
init-system-helpers
http://security.ubuntu.com/ubuntu/pool/main/i/init-system-helpers/


Platform
--------
Ubuntu 12.04LTS

Packages
========
## HAProxy 1.5 ##
https://launchpad.net/~vbernat/+archive/haproxy-1.5

## init-system-helpers ##
http://security.ubuntu.com/ubuntu/pool/main/i/init-system-helpers/

Links
=====
http://www.haproxy.org

Copyright (C) 2014 Pearson, Inc.
Distributed under the All Rights Reserved License.
