# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'haproxy::config' do

  describe group('haproxy') do
    it { should exist }
    it { should have_gid 750 }
  end

  describe user('haproxy') do
    it { should exist }
    it { should have_uid 750 }
    it { should belong_to_group 'haproxy' }
    it { should have_home_directory '/home/haproxy' }
    it { should have_login_shell '/bin/bash' }
  end

  describe file('/home/haproxy') do
    it { should be_directory }
    it { should be_owned_by 'haproxy' }
  end

  describe package('haproxy') do
    it { should be_installed.by('apt').with_version('1.5.1-1') }
  end

end
