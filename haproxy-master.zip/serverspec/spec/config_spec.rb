# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'haproxy::config' do

  describe file('/etc/default/haproxy') do
    it { should be_mode 644 }
    it { should be_owned_by 'root' }
    its(:content) { should match /ENABLED=1/ }
  end

  describe file('/home/haproxy/templates') do
    it { should be_directory }
    it { should be_mode 755 }
    it { should be_owned_by 'haproxy' }
  end

  describe file('/home/haproxy/templates/haproxy.cfg.tpml') do
    it { should be_mode 644 }
    it { should be_owned_by 'haproxy' }
    its(:content) { should match /user haproxy/ }
  end

  describe file('/etc/haproxy/haproxy.cfg') do
    it { should be_mode 777 }
    it { should be_owned_by 'root' }
  end

end
