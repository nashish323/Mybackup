# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'haproxy::config' do

  describe service('haproxy') do
    it { should be_enabled }
    #haproxy service shouldn't be running because this is managed by Thalassa Aqueduct
    #it { should be_running }
  end

end
