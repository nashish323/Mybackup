require 'yaml'
require 'r10k/puppetfile'
require 'git'
require 'fileutils'

require 'functions/update_puppetfile_from_dependencies'
config = YAML.load_file('dependencies.yml')
repodir = '.puppetfile'
branch = Puppetfile_Dependencies.get_branchname()

puts "Extracting hiera defaults from [#{branch.name}]"
rootdir = File.expand_path(File.join(__FILE__, '..','..'))
FileUtils.cp(File.join(rootdir,'.puppetfile','hieradata','nibiru_defaults.yaml'),File.join(rootdir,'tests','nibiru_defaults.yaml'))
puts "Wrote new defaults to 'tests/nibiru_defaults.yaml'"