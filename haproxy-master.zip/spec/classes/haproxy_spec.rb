# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'haproxy' do

  let (:facts) { {
    :osfamily => 'Debian',
    :virtual  => 'virtualbox'
  } }

  let (:params) { {
    :version => '1.5.1-1',
    :uid     => '0750',
    :gid     => '0750',
  } }

  it { should contain_class('haproxy::config')}
  it { should contain_class('haproxy::install').with(
     :uid  => '0750',
     :gid => '0750',
  ) }

end
