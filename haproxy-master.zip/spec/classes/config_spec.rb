# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'haproxy::config' do

    it { should contain_file('/etc/default/haproxy').with(
      :owner  => 'root',
      :group  => 'root',
      :source => 'puppet:///modules/haproxy/haproxy',
    ) }

    it { should contain_file('/home/haproxy/templates').with(
      :ensure => 'directory',
    ) }

    it { should contain_file('/home/haproxy/templates/haproxy.cfg.tpml') }
    it { should contain_file('/home/haproxy/templates/haproxy.cfg.tpml').that_requires('File[/home/haproxy/templates]') }

    it { should contain_file('/etc/haproxy/haproxy.cfg').with(
      :mode  => '0777',
      :owner => 'root',
      :group => 'root',
    ) }

end
