# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'haproxy::service' do

  let (:facts) { {
    :osfamily => 'Debian',
    :virtual  => 'virtualbox'
  } }

  it { should contain_service('haproxy').with(
    :ensure => 'running',
    :enable => 'true',
  ) }

  #I couldn't get this test to work. Getting error:
  #Failures:
  #1) haproxy::service should contain Service[haproxy]
  #  Failure/Error: { should contain_service('haproxy').that_subscribes_to('Class["haproxy::config"]')
  #   NoMethodError
  #     undefined method `[]' for nil:NilClass
  #     # ./spec/classes/service_spec.rb:17:in `block (2 levels) in <top (required)>'

  #it { should contain_service('haproxy').that_subscribes_to('Class[haproxy::config]') }

end
