# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'haproxy::install' do

  let (:facts) { {
    :osfamily => 'Debian',
    :virtual  => 'virtualbox'
  } }

  let (:params) { {
    :uid => '0750',
    :gid => '0750',
  } }

  #it { should contain_class('haproxy')}

  it { should contain_group('haproxy').with(
    :ensure => 'present',
    :gid    => '0750',
  ) }

  it { should contain_user('haproxy').with(
    :ensure   => 'present',
    :comment  => 'haproxy user',
    :password => '!!',
    :uid      => '0750',
    :gid      => '0750',
    :shell    => '/bin/bash',
    :home     => '/home/haproxy',
  ) }

  it { should contain_user('haproxy').that_requires('Group[haproxy]') }

  it { should contain_file('/home/haproxy').with(
    :ensure => 'directory',
    :owner  => 'haproxy',
    :group  => 'haproxy',
  ) }

  it { should contain_file('/home/haproxy').that_requires('User[haproxy]') }

  it { should contain_package('haproxy').with(
    :ensure => '1.5.1-1',
  ) }

  it { should contain_package('haproxy').that_requires('User[haproxy]') }

end
