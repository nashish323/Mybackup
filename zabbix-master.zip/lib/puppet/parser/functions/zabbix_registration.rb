#/* vim: se ts=2:sts=2:sw=2:noet */

# monkey patching String to have truncate method
class String
  def truncate(length = 64, ellipsis = '...')
    text = self
    if text.length > length
      text.to_s[0..length].gsub(/[^\w]\w+\s*$/, ellipsis)
    else
      text
    end
  end
end

require 'rubygems'
require 'rest_client'
require 'json'
require 'pp'

class Zabbix

  RestClient.log = 'stdout'
  
  def initialize(options = {})
    @options = options
    @auth_hash = auth['result']
    @debug = options[:debug] ||= false
  end

  def auth
    api_request(
      :method => :post,
      :payload => {
        :method => 'user.authenticate',
        :params => {
          :user      => @options[:user],
          :password  => @options[:password],
        }
      }
    )
  end

  def api_request(message)
    request_defaults = {
      :url => "http://#{@options[:host]}/zabbix/api_jsonrpc.php",
      :timeout => @options[:timeout] ||= 60,
      :open_timeout => @options[:open_timeout] ||= 60,
      :headers => { :content_type => 'application/json'}
    }

    payload_defaults = {
      :jsonrpc => "2.0",
      :id => 1
    }

    message[:payload].merge!(payload_defaults)
    request = request_defaults.merge(message)
    request[:payload] = request[:payload].to_json
    response = JSON.parse(RestClient::Request.new(request).execute)
    if response.has_key?('error')
      error = response['error']
      raise "ERROR: code => #{error['code']}, message => #{error['message']}, data => #{error['data']}, request => #{request}"
    else
      response
    end
  end

  def hostgroup_create(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'hostgroup.create',
          :params => params,
          :auth => @auth_hash
        }
      )
      request['result']['groupids'][0]
    rescue => exception
      err exception.backtrace.inspect if @debug
      raise "hostgroup_create() #{exception.to_s}"
    end
  end

  def hostgroup_delete(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'hostgroup.delete',
          :params => params,
          :auth => @auth_hash
        }
      )
      request['result']['groupids']
    rescue => exception
      err exception.backtrace.inspect if @debug
      raise "hostgroup_delete() #{exception.to_s}"
    end
  end

  def hostgroup_get_id(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'hostgroup.get',
          :params => {
            :output => :shorten,
            :filter => {
              :name => params[:name],
              :sortfield => 'groupid'
            }
          },
          :auth => @auth_hash
        }
      )
      if request['result'].length == 1
        return request['result'][0]['groupid']
      elsif request['result'].length == 0
        return nil
      else
        notice 'hostgroup.get returned more than one result.  deleting' if @debug
        delete_set = (1..request['result'].length-1).map { |id| request['result'][id]['hostgroup'] }
        hostgroup_delete(delete_set)
        return request['result'][0]['hostgroup']
      end
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "hostgroup_get_id() #{exception.to_s}"
    end
  end

  def host_get_id(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'host.get',
          :params => {
            :output => :shorten,
            :filter => params
          },
          :auth => @auth_hash
        }
      )
      if request['result'].length == 1 
        return request['result'][0]['hostid']
      else
        return nil
      end
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "host_get_id() #{exception.to_s}"
    end
  end

  def hostgroup_get_or_create(params)
    begin
      hostgroup_id = hostgroup_get_id(params)
      if hostgroup_id.class == NilClass
        hostgroup_create(params)
        return hostgroup_get_id(params)
      end
      return hostgroup_id
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "hostgroup_get_or_create() #{exception.to_s}"
    end
  end

  def template_create(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'template.create',
          :params => {
            :host => params[:host],
            :groups => {
              :groupid => hostgroup_get_id(:name => 'Templates')
            }
          },
          :auth => @auth_hash
        }
      )
      request['result']['templateids'][0]
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "template_create() #{exception.to_s}"
    end
  end

  def template_delete(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'template.delete',
          :params => params,
          :auth => @auth_hash
        }
      )
      request['result']['templateids']
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "template_delete() #{exception.to_s}"
    end
  end

  def template_update(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'template.update',
          :params => params,
          :auth => @auth_hash
        }
      )
      request['result']['templateids'][0]
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "template_update() #{exception.to_s}"
    end
  end

  def template_get_id(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'template.get',
          :params => {
            :output => :shorten,
            :filter => { 
              :host => params[:host],
              :sortfield => 'templateid'
            }
          },
          :auth => @auth_hash
        }
      )
      if request['result'].length == 1
        return request['result'][0]['templateid']
      elsif request['result'].length == 0
        return nil
      else
        notice 'template.get returned more than one result.  deleting' if @debug
        delete_set = (1..request['result'].length-1).map { |id| request['result'][id]['templateid'] }
        template_delete(delete_set)
        return request['result'][0]['templateid']
      end
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "template_get_id() #{exception.to_s}"
    end
  end

  def template_get_or_create(params)
    begin
      template_id = template_get_id(params)
      if template_id.class == NilClass
        template_create(params)
        return template_get_id(params)
      end
      return template_id
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "template_get_or_create() #{exception.to_s}"
    end
  end

  def template_create_or_update(params)
    begin
      template_id = template_get_id(params)
      if template_id.class == NilClass
        return template_create(params)
      end
      return template_update(params.merge({:templateid => template_id}))
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "template_create_or_update() #{exception.to_s}"
    end
  end

  def host_create(params)
    begin
      request = api_request(
        :method => :post,
        :payload => {
          :method => 'host.create',
          :params => params,
          :auth => @auth_hash
        }
      )
      request['result']['hostids'][0]
    rescue => exception
      notice exception.backtrace.inspect if @debug
      raise "host_create() #{exception.to_s}"
    end
  end
end

Puppet::Parser::Functions.newfunction(:zabbix_registration) do |args|
  @options = args[0] ||= {}
  @host = @options['hostname'] ||= lookupvar('zabbix::agent::hostname')
  @zbx_host = @options['server_host'] ||= lookupvar('zabbix::agent::server_host')
  @base_os_template = @options['base_os_template'] ||= lookupvar('zabbix::agent::base_os_template')
  @team_id = lookupvar('::nibiru_team_id')
  @app = lookupvar('::nibiru_app_name').downcase
  @app_type = lookupvar('::nibiru_app_type').nil? ? "" : lookupvar('::nibiru_app_type')
  @fqdn = lookupvar('fqdn')
  @request_timeout = @options['request_timeout'] ||= lookupvar('zabbix::agent::request_timeout').to_i
  @enable_registration = @options['enable_registration'] ||= lookupvar('zabbix::agent::enable_registration')
  @debug = @options['debug'] ||= lookupvar('zabbix::agent::debug_registration')

  notice "starting zabbix registration" if @debug

  if !@enable_registration
    notice "zabbix registration disabled for host #{@host}"
    return
  end

  RestClient.log = 'stdout' if @debug

  def establish_hostgroup (hostgroup)
    notice "zabbix: establishing hostgroup => #{hostgroup}" if @debug
    hostgroup_id = @zbx.hostgroup_get_or_create(:name => hostgroup)
    @instance_groups << { :groupid => hostgroup_id }
    hostgroup_id
  end

  def establish_template (template)
    notice "zabbix: establishing template => #{template}"
    template_id = @zbx.template_create_or_update(:host => template, :groups => [ {:groupid => @default_hostgroup_id}, {:groupid => @teams_hostgroup_id}, {:groupid => @team_hostgroup_id} ])
    @instance_templates << { :templateid => template_id }
    template_id
  end

  @instance_groups = []
  @instance_templates = []

  begin
    notice "connecting to zabbix server: #{@zbx_host}" if @debug
    @zbx = Zabbix.new(
      :host => @zbx_host,
      :user => 'Admin',
      :password => 'zabbix',
      :timeout => @request_timeout,
      :open_timeout => @request_timeout,
      :debug => @debug
    )
    notice @zbx.inspect if @debug
  rescue => exception
    err "unable to connect to zabbix host #{@zbx_host}"
    err "exception reason: #{exception}"
    err exception.backtrace.inspect if @debug
    return "[error] unable to connect to zabbix host #{@zbx_host}"
  end

  notice "zabbix: checking if #{@host} exists" if @debug
  if @zbx.host_get_id(:host => "#{@host}")
    notice "#{@host} already registered no need to continue zabbix registration process" if @debug
  else
    apps = Hash.new
    apps['apac'] = 'Apache'
    apps['cadb'] = 'Cassandra'
    apps['codb'] = 'Couch'
    apps['esrc'] = 'Elastic Search'
    apps['glfs'] = 'GlusterFS'
    apps['gpht'] = 'Graphite'
    apps['gtwy'] = 'NAT Gateway'
    apps['hadp'] = 'Hadoop'
    apps['hapy'] = 'HA Proxy'
    apps['kamq'] = 'Kafka'
    apps['kbna'] = 'Kibina'
    apps['modb'] = 'Mongo'
    apps['mydb'] = 'MySQL'
    apps['ordb'] = 'Oracle'
    apps['pupp'] = 'Puppet'
    apps['ramq'] = 'RabbitMQ'
    apps['redb'] = 'Redis'
    apps['repo'] = 'System Package Repository'
    apps['strm'] = 'Storm'
    apps['thal'] = 'Thalassa Server'
    apps['tidb'] = 'Titan'
    apps['zabx'] = 'Zabbix'
    apps['zook'] = 'Zookeeper'

    team_hostgroup = "#{@team_id}".truncate(64)
    team_template = "Template Team #{@team_id}".truncate(64)
    team_app_hostgroup = "#{@team_id} #{@app}".truncate(64)
    team_app_template = "Template Team #{team_app_hostgroup}".truncate(64)
    if apps.has_key?(@app_type[0,4])
      app_service = apps[@app_type[0,4]]
      app_service_hostgroup = "#{app_service}".truncate(64)
      app_service_template = "Template App #{app_service}".truncate(64)
      team_service_hostgroup = "#{team_app_hostgroup} - #{app_service}".truncate(64)
      team_service_template = "Template Team #{team_service_hostgroup}".truncate(64)
    end

    notice "zabbix registration information for #{@host}:"
    notice "                 team id: #{@team_id}"
    notice "          team hostgroup: #{team_hostgroup}"
    notice "           team template: #{team_template}"
    notice "                     app: #{@app}"
    notice "      team app hostgroup: #{team_app_hostgroup}"
    notice "       team app template: #{team_app_template}"

    if app_service
      notice "             app service: #{app_service}"
      notice "   app service hostgroup: #{app_service_hostgroup}"
      notice "    app service template: #{app_service_template}"
      notice "  team service hostgroup: #{team_service_hostgroup}"
      notice "   team service template: #{team_service_template}"
    end

    begin
      notice "zabbix: getting zabbix 'Templates' hostgroup id" if @debug
      @default_hostgroup_id = @zbx.hostgroup_get_or_create(:name => 'Templates')

      notice "zabbix: getting zabbix 'Teams' hostgroup id" if @debug
      @teams_hostgroup_id = @zbx.hostgroup_get_or_create(:name => 'Teams')

      notice "zabbix: getting zabbix template id '#{@base_os_template}' for base os template" if @debug
      @instance_templates << { :templateid => @zbx.template_get_or_create(:host => @base_os_template)}

      @team_hostgroup_id = establish_hostgroup(team_hostgroup)
      @team_template_id = establish_template(team_template)

      @team_app_hostgroup_id = establish_hostgroup(team_app_hostgroup)
      @team_app_template_id = establish_template(team_app_template)

      if app_service
        @app_service_hostgroup_id = establish_hostgroup(app_service_hostgroup)
        @app_service_template_id = establish_template(app_service_template)

        @team_service_hostgroup_id = establish_hostgroup(team_service_hostgroup)
        @team_service_template_id = establish_template(team_service_template)
      end
    rescue => exception
      err "error creating required templates and hostgroups"
      err "exception reason: #{exception}"
      err exception.backtrace.inspect if @debug
      return
    end

    begin
      host = {
        :host => @host,
        :interfaces => [
          {
            :type => 1,
            :main => 1,
            :ip => lookupvar('::ipaddress'),
            :dns => @fqdn,
            :port => 10050,
            :useip => 0
          }
        ],
        :groups => @instance_groups,
        :templates => @instance_templates
      }

      notice "zabbix: creating host => #{host.inspect}"

      host_id = @zbx.host_create( host )

      notice "finished registering #{@host} with host id #{host_id}"
    rescue => exception
      err "error creating host #{@host}"
      err "exception reason: #{exception}"
      err exception.backtrace.inspect if @debug
      return
    end

  end
end
