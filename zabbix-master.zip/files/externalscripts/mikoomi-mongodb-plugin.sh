#!/bin/bash
#######################################################################################
# This file is managed by Puppet                                                      #
# Any changes to this file will be overwritten every 30 minutes                       #
# For more details please see https://hub.pearson.com/confluence/display/eSAT/Puppet  #
#######################################################################################
BASE_DIR=$(dirname $0)

if [ $# -gt 2 ]
then
  if [ "$3" != "{}" ] && [ "$4" != "{}" ]
  then
    /usr/bin/php $BASE_DIR/mikoomi-mongodb-plugin.php -h $2 -p 27017 -z $1 -u $3 -x $4
    exit 0
  else
    /usr/bin/php $BASE_DIR/mikoomi-mongodb-plugin.php -h $2 -p 27017 -z $1
    exit 0
  fi
else
  /usr/bin/php $BASE_DIR/mikoomi-mongodb-plugin.php -h $2 -p 27017 -z $1
  exit 0
fi