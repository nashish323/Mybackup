# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'zabbix::server' do
  let :params do {
    :database_user     => 'root',
    :database_password => ''
  } end


  # server.pp
  it { should contain_file('/usr/lib/zabbix/alertscripts').with(
    'mode'    => '0755',
    'recurse' => true
    )
  }
  context "In Nibiru Dev" do
    let(:facts) {
      {:nibiru_environment => 'dev' }
    }
    #Given the nibiru environment of dev, it should make a script that says as much
    it { should contain_file('/usr/lib/zabbix/alertscripts/zabbix_hipchat_alert').with(
      'mode'    => '0755',
      'content' => /Zabbix - dev/
      )
    }
  end
  context "In Nibiru Prod" do
    let(:facts) {
      {:nibiru_environment => 'prod' }
    }
    #Given the nibiru environment of dev, it should make a script that says as much
    it { should contain_file('/usr/lib/zabbix/alertscripts/zabbix_hipchat_alert').with(
      'mode'    => '0755',
      'content' => /Zabbix - prod/
      )
    }
  end
  context "In Nibiru Dev" do
    let(:facts) {
      {:nibiru_environment => 'dev' }
    }
    #Given the nibiru environment of dev, it should make a script that
    #says as much
    it { should contain_file('pd-zabbix').with(

    'path'    => '/usr/lib/zabbix/alertscripts/pd-zabbix',
    'ensure'  => 'link',
    'target'  => '/usr/share/pdagent-integrations/bin/pd-zabbix',
     )
    }
  end
end