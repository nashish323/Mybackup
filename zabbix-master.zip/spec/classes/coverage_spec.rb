# Current gem doesn't support the coverage report
#at_exit { RSpec::Puppet::Coverage.report! }