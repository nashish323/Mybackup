# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'zabbix::agent::userparam' do

    let(:facts) { { :virtual => 'virtualbox' } }
		let(:title) { 'elasticsearch.conf' }
		let(:params) {{
		 	:ensure => 'present',
			:source => 'puppet:///modules/elasticsearch/elasticsearch.conf'
	 	}}

		it do
		 	should contain_file('/etc/zabbix/zabbix_agentd.d/elasticsearch.conf').with({
			  'ensure'  => 'present',
			  'owner'   => 'zabbix',
			  'group'   => 'zabbix',
			  'mode'    => '0644',
				'source'  => 'puppet:///modules/elasticsearch/elasticsearch.conf',
		  })
		end

end
