# for rspec-puppet documentation - see http://rspec-puppet.com/tutorial/
require_relative '../spec_helper'

describe 'zabbix::agent::script' do

    let(:facts) { { :virtual => 'virtualbox' } }
		let(:title) { 'elasticsearch.py' }
		let(:params) {{
		 	:ensure => 'present',
			:source => 'puppet:///modules/elasticsearch/elasticsearch.py'
	 	}}

		it do
		 	should contain_file('/etc/zabbix/scripts/elasticsearch.py').with({
			  'ensure' => 'present',
			  'owner'  => 'zabbix',
			  'group'  => 'zabbix',
			  'mode'   => '0700',
				'source' => 'puppet:///modules/elasticsearch/elasticsearch.py',
		  })
		end

end
