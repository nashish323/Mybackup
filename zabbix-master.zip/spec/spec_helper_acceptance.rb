require 'beaker-rspec/spec_helper'
require 'beaker-rspec/helpers/serverspec'
require 'Rsync'

hosts.each do |host|
  # Install Puppet - Not necessary with our current image
  # install_puppet
  on host, "mkdir -p #{host['distmoduledir']}"
end

RSpec.configure do |c|
  # Project root
  proj_root = File.expand_path(File.join(File.dirname(__FILE__), '..'))

  # Readable test descriptions
  c.formatter = :documentation
  # Configure all nodes in nodeset
  c.before :suite do
    # Install module and dependencies

    # Create a temporary SSH key for rsync communciation
    key_dir = Dir.mktmpdir("keys")
    priv_key = key_dir + '/tempkey'
    pub_key = key_dir + '/tempkey.pub'
    begin # Allows us to tidy up the folder afterwards
      # Actual creation of the SSH key
      # Can't do this with ruby directly because of limitations of the OpenSSL class
      #  (requires a password, or prompts users)
      %x( echo -e 'y\n' |  ssh-keygen -t rsa -N '' -f #{priv_key})

      # Install module and dependencies
      hosts.each do |host|
        # Put the public key on the server so that we can use the keypair:
        scp_to(host, pub_key, '/root/.ssh/authorized_keys')

        #We assume that all of your modules and dependencies are placed in the
        # spec/fixtures/modules folder, per other build steps, so we are dropping
        # them in as specified
        from_path = proj_root+'/spec/fixtures/modules/' # Trailing slash needed for rsync
        to_path = '/etc/puppet/modules'
        hostname_with_user = "#{host[:ssh][:user]}@#{host[:ip]}"
        rsync_args = "-e \"ssh -p #{host[:ssh][:port]} -i #{priv_key}\" -avL"
        Rsync.host = hostname_with_user
        # logger comes from beaker
        logger.notify "rsync: localhost:#{from_path} to #{hostname_with_user}:#{to_path}"
        Rsync.run(from_path, to_path, rsync_args)

        # Copies over the tests and hiera data
        from_path = proj_root+'/tests/' # Trailing slash needed for rsync
        to_path = '/etc/puppet/tests'
        logger.notify "rsync: localhost:#{from_path} to #{hostname_with_user}:#{to_path}"
        Rsync.run(from_path, to_path, rsync_args)

        # Copy over the hiera config
        scp_to(host, proj_root+'/spec/unit_test_hiera.yaml', '/etc/puppet/hiera.yaml')
        # We have to convert the local pathing to absolute, or hiera doesn't smile
        on(host, 'sed -i "s:./:/etc/puppet/:" /etc/puppet/hiera.yaml')

        # Alternative method (very slow):
        # scp_to(host, proj_root+'/spec/fixtures/modules', '/etc/puppet/', {:ignore_list => PUPPET_MODULE_INSTALL_IGNORE})

        #on host, puppet('module', 'install', 'puppetlabs-stdlib'), { :acceptable_exit_codes => [0,1] }
      end
    ensure
      FileUtils.remove_entry_secure key_dir
    end
  end
end


