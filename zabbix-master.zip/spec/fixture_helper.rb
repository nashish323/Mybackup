require 'yaml'
require 'r10k/puppetfile'
require 'git'

require 'functions/update_puppetfile_from_dependencies'
config = YAML.load_file('dependencies.yml')
repodir = '.puppetfile'
branch = Puppetfile_Dependencies.get_branchname()
requested_dependencies=config['dependencies'].sort_by { |key|
  if key.class == Hash then
    result=key.keys[0]
  else
    result=key
  end
}

puppet_mods = R10K::Puppetfile.new(repodir)
puppet_mods = puppet_mods.load()
available_mods = {}
puppet_mods.each do |i|
  available_mods[i.name]={
    'repo'=>i.instance_variable_get("@remote").to_s,
    'ref'=>i.instance_variable_get("@ref").to_s
  };
  # This logic is flawed
  #if (available_mods[i.name]['ref'] =~ /[A-z]/)
  #  available_mods[i.name]['ref']="origin/"+available_mods[i.name]['ref']
  #end
end


actual_dependencies = {}

requested_dependencies.each do |i|
  if i.class == Hash then
    actual_dependencies[i.keys[0]]=i.values[0]
  else
    if available_mods.has_key?(i) then
      actual_dependencies[i]=available_mods[i]
    else
      puts "Unable to provide '#{i}' module from #{branch.name}"
    end
  end
end

fixtures = {
  "fixtures" => {
    "repositories" => actual_dependencies,
    "symlinks" => config['symlinks']
  }
}
File.open('.fixtures.yml','w') { |file|
  file.write("# For puppetlabs_spec_helper documentation - see http://github.com/puppetlabs/puppetlabs_spec_helper\n")
  file.write(fixtures.to_yaml)
}
puts "Fixtures updated"
