require 'spec_helper_acceptance'

describe 'zabbix class' do

  context 'default parameters' do
    # Using puppet_apply as a helper


    it 'should work idempotently with no errors' do
      # Use this if you don't want to use the tests/init.pp
      # Using this block is not recommended
      #pp = <<-EOS
      #class { 'zabbix':

      #}
      #EOS
      pp = ""
      pp_file = File.expand_path(File.join(File.dirname(__FILE__), '../../tests/init.pp'))
      File.open(pp_file, "r") do |f|
        f.each_line do |line|
          pp << line
        end
      end

      # Run it twice and test for idempotency
      apply_manifest(pp, :catch_failures => true)
      apply_manifest(pp, :catch_changes  => true)
    end

    # Place your tests here

    #describe package('zabbix') do
    #  it { should be_installed }
    #end

    #describe service('zabbix') do
    #  it { should be_enabled }
    #  it { should be_running }
    #end
  end
end
