# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

pkgs = ['make', 'python-boto', 'php-pear', 'php5-dev', 'zabbix-frontend-php']

apache_configs = ['php_value max_execution_time 300',
                  'php_value memory_limit 256M',
                  'php_value post_max_size 16M',
                  'php_value upload_max_filesize 2M',
                  'php_value max_input_time 300',
                  'php_value date.timezone']

pkgs.each do |pkg|
  describe package("#{pkg}") do
    it { should be_installed }
  end
end

describe service('apache2') do
  it { should be_enabled }
  it { should be_running }
end

describe file('/etc/zabbix/apache.conf') do
  it { should be_file }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '644' }

  apache_configs.each do |apache_config|
    it { should contain "#{apache_config}" }
  end

end

describe file('/etc/zabbix/web') do
  it { should be_directory }
  it { should be_owned_by 'www-data' }
  it { should be_grouped_into 'root' }
  it { should be_mode '755' }
end
