# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

pkgs = ['zabbix-server-mysql', 'make', 'python-boto',
         'php-pear', 'php5-dev', 'zabbix-frontend-php']

cache_configs = ['CacheSize=128M', 'CacheUpdateFrequency=60', 'HistoryCacheSize=64M',
                 'TrendCacheSize=64M', 'HistoryTextCacheSize=16M']

pkgs.each do |pkg|
  describe package("#{pkg}") do
    it { should be_installed }
  end
end

describe service('zabbix-server') do
  it { should be_enabled }
  it { should be_running }
end

describe file('/etc/zabbix/zabbix_server.conf') do
  it { should be_file }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '644' }

  cache_configs.each do |cache_config|
    it { should contain "#{cache_config}" }
  end
end

describe file('/usr/lib/zabbix/externalscripts') do
  it { should be_directory }
  it { should be_owned_by 'vagrant' }
  it { should be_grouped_into 'vagrant' }
  it { should be_mode '755' }
end

describe service('apache2') do
  it { should be_enabled }
  it { should be_running }
end

describe file('/etc/zabbix/web') do
  it { should be_directory }
  it { should be_owned_by 'www-data' }
  it { should be_grouped_into 'root' }
  it { should be_mode '755' }
end

describe file('/etc/zabbix/apache.conf') do
  it { should be_file }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '644' }
end

describe command('zabbix_server --version') do
  it { should return_exit_status 255 }
  it { should return_stdout /^Zabbix server.*/ }
end

describe linux_kernel_parameter('kernel.shmmax') do
  it "should have a value" do
    subject.value.should eq 268435456
  end
end

describe command('pecl list | grep mongo') do
  it { should return_exit_status 0 }
end

describe file('/usr/lib/zabbix/alertscripts') do
  it { should be_directory }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '755' }
end
describe file('/usr/lib/zabbix/alertscripts/hipchat_room_message') do
  it { should be_file }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '755' }
end
describe file('/usr/lib/zabbix/alertscripts/zabbix_hipchat_alert') do
  it { should be_file }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '755' }
end
describe file('/usr/lib/zabbix/alertscripts/pd-zabbix') do
  it { should be_linked_to '/usr/share/pdagent-integrations/bin/pd-zabbix' }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
end