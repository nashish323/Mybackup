# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

describe 'zabbix' do
  it 'itself does nothing'
end
