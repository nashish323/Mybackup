# For serverspec documentation - see http://serverspec.org/tutorial.html
require_relative '../spec_helper'

pkgs = ['zabbix-java-gateway']

pkgs.each do |pkg|
  describe package("#{pkg}") do
    it { should be_installed }
  end
end

describe service('zabbix-java-gateway') do
  it { should be_enabled }
  it { should be_running }
end

describe file('/etc/zabbix/zabbix_java_gateway.conf') do
  it { should be_file }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '644' }

end
